import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  ArrowUpTrayIcon,
  XMarkIcon,
  EyeIcon,
  ShieldExclamationIcon,
  XCircleIcon,
  SparklesIcon,
  CheckCircleIcon,
} from "@heroicons/react/24/outline";
import { motion, AnimatePresence } from "framer-motion";

/* ─────────────────────────────
   📄 PDF Sidopanel
───────────────────────────── */
function PdfSidePanel({ fileUrl, onClose }) {
  if (!fileUrl) return null;
  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 bg-black/30 backdrop-blur-sm z-[9999] flex justify-end"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.div
          className="bg-white w-[480px] h-full shadow-2xl border-l border-slate-200 flex flex-col"
          initial={{ x: "100%" }}
          animate={{ x: 0 }}
          exit={{ x: "100%" }}
          transition={{ type: "spring", damping: 25, stiffness: 300 }}
        >
          <div className="flex items-center justify-between px-5 py-3 border-b">
            <h2 className="font-semibold text-slate-700">Förhandsgranskning</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-100 rounded-full"
            >
              <XMarkIcon className="w-5 h-5 text-slate-600" />
            </button>
          </div>
          <iframe
            src={fileUrl}
            title="PDF Preview"
            className="flex-1 w-full h-full"
          />
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

/* ─────────────────────────────
   🤖 AI-insiktspanel
───────────────────────────── */
function AiInsightPanel({ invoice, onClose, onFeedback }) {
  if (!invoice) return null;

  const riskLevel =
    invoice.riskScore > 70
      ? "high"
      : invoice.riskScore > 40
      ? "medium"
      : "low";

  const colors = {
    high: "border-red-400 bg-red-50 text-red-700",
    medium: "border-yellow-400 bg-yellow-50 text-yellow-700",
    low: "border-green-400 bg-green-50 text-green-700",
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 bg-black/40 z-[9998] flex justify-start backdrop-blur-sm"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.div
          className="w-[420px] bg-white shadow-2xl border-r border-slate-200 flex flex-col"
          initial={{ x: "-100%" }}
          animate={{ x: 0 }}
          exit={{ x: "-100%" }}
          transition={{ type: "spring", damping: 25, stiffness: 300 }}
        >
          <div className="flex items-center justify-between px-5 py-3 border-b">
            <h2 className="font-semibold text-slate-800">
              AI-insikter — {invoice.invoiceId || "Faktura"}
            </h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-100 rounded-full"
            >
              <XMarkIcon className="w-5 h-5 text-slate-600" />
            </button>
          </div>

          <div className={`p-4 border-b ${colors[riskLevel]} bg-opacity-20`}>
            <div className="flex items-center gap-2 mb-1">
              <ShieldExclamationIcon className="w-5 h-5" />
              <h3 className="font-medium">
                {riskLevel === "high"
                  ? "🚨 Hög risk"
                  : riskLevel === "medium"
                  ? "⚠️ Osäker faktura"
                  : "✅ Låg risk"}
              </h3>
            </div>
            <p className="text-sm opacity-80">
              {invoice.aiSummary || "Ingen AI-förklaring tillgänglig."}
            </p>
          </div>

          <div className="flex-1 p-5 space-y-4 overflow-y-auto">
            <div>
              <p className="text-xs text-slate-500 uppercase mb-1">
                AI-förtroende
              </p>
              <div className="flex items-center gap-2">
                <div className="w-20 bg-slate-100 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-blue-500 h-2 rounded-full"
                    style={{ width: `${invoice.aiConfidence || 0}%` }}
                  />
                </div>
                <span className="text-sm font-medium">
                  {invoice.aiConfidence || 0}%
                </span>
              </div>
            </div>

            <div>
              <p className="text-xs text-slate-500 uppercase mb-1">Kundnamn</p>
              <p className="text-sm">{invoice.customerName || "Okänd"}</p>
            </div>

            <div>
              <p className="text-xs text-slate-500 uppercase mb-1">
                AI-analys
              </p>
              <div className="p-3 bg-slate-50 border rounded-md text-sm text-slate-700">
                {invoice.aiParsed?.explanations?.total ||
                  "Ingen detaljerad analys tillgänglig."}
              </div>
            </div>
          </div>

          {riskLevel !== "low" && (
            <div className="border-t p-4 bg-slate-50 flex gap-3">
              <button
                onClick={() => onFeedback("approve_anyway", invoice)}
                className="flex-1 bg-green-500 text-white py-2 rounded-lg hover:bg-green-600 transition"
              >
                ✅ Godkänn ändå
              </button>
              <button
                onClick={() => onFeedback("confirm_risk", invoice)}
                className="flex-1 bg-red-500 text-white py-2 rounded-lg hover:bg-red-600 transition"
              >
                🚫 Bekräfta risk
              </button>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

/* ─────────────────────────────
   💱 Belopp Formatter
───────────────────────────── */
function CurrencyDisplay({ total, currency }) {
  if (!total) return "–";
  const formatted = new Intl.NumberFormat("sv-SE", {
    style: "currency",
    currency: currency || "SEK",
  }).format(total);
  return <span>{formatted}</span>;
}

/* ─────────────────────────────
   🧠 Statuschip (inkl. Valiflow AI)
───────────────────────────── */
function StatusDisplay({ risk }) {
  let label = "Validerad av Valiflow AI";
  let color = "bg-green-100 text-green-700";
  let Icon = SparklesIcon;

  if (risk > 70) {
    label = "Hög risk";
    color = "bg-red-100 text-red-700 animate-pulse";
    Icon = XCircleIcon;
  } else if (risk > 40) {
    label = "AI osäker";
    color = "bg-yellow-100 text-yellow-700";
    Icon = ShieldExclamationIcon;
  }

  return (
    <div
      className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${color}`}
    >
      <Icon className="w-4 h-4" />
      <span>{label}</span>
    </div>
  );
}

/* ─────────────────────────────
   💼 Fakturasidan
───────────────────────────── */
export default function CompanyInvoices() {
  const API = import.meta.env.VITE_API_URL || "http://localhost:4000";
  const [invoices, setInvoices] = useState([]);
  const [file, setFile] = useState(null);
  const [pdfUrl, setPdfUrl] = useState(null);
  const [insightInvoice, setInsightInvoice] = useState(null);
  const [loading, setLoading] = useState(false);
  const [aiAssist, setAiAssist] = useState(true);

  useEffect(() => {
    fetch(`${API}/api/invoices`, { credentials: "include" })
      .then((r) => r.json())
      .then((data) => setInvoices(data.invoices || []))
      .catch(() => setInvoices([]));
  }, []);

  const handleUpload = async () => {
    if (!file) return toast.error("Välj en fil först!");
    const formData = new FormData();
    formData.append("file", file);
    formData.append("aiAssist", aiAssist ? "true" : "false");
    setLoading(true);
    toast.loading("📤 Skickar faktura för analys...");

    try {
      const res = await fetch(`${API}/api/invoices/scan`, {
        method: "POST",
        body: formData,
      });

      // ⚠️ Hantera dubblett (409)
      if (res.status === 409) {
        const existing = await res.json();
        toast.dismiss();
        toast.warning("⚠️ Fakturan finns redan – visar befintlig version.");
        const existingInvoice = existing.invoice || existing.data || existing;
        setInvoices((prev) => [existingInvoice, ...prev]);
        setPdfUrl(existingInvoice.pdfUrl || null);
        return;
      }

      const data = await res.json();
      toast.dismiss();

      const newInvoice = data?.invoice || data || {};
      const merged = {
        ...newInvoice,
        invoiceId:
          newInvoice.invoiceId ||
          newInvoice.data?.invoiceId ||
          newInvoice.aiParsed?.data?.invoiceId ||
          "–",
        customerName:
          newInvoice.customerName ||
          newInvoice.data?.customerName ||
          newInvoice.aiParsed?.data?.customerName ||
          "Okänd leverantör",
        total:
          newInvoice.total ||
          newInvoice.data?.total ||
          newInvoice.aiParsed?.data?.total ||
          0,
        currency:
          newInvoice.currency ||
          newInvoice.data?.currency ||
          newInvoice.aiParsed?.data?.currency ||
          "SEK",
      };

      if (merged.riskScore > 70)
        toast.error("🚨 AI flaggade fakturan som högrisk!");
      else if (merged.riskScore > 40)
        toast.warning("⚠️ AI är osäker – manuell granskning rekommenderas.");
      else toast.success("✅ AI bedömde fakturan som säker.");

      setInvoices((prev) => [merged, ...prev]);
    } catch (err) {
      console.error(err);
      toast.dismiss();
      toast.error("Fel vid scanning.");
    } finally {
      setLoading(false);
    }
  };

  const handleFeedback = async (action, inv) => {
    try {
      await fetch(`${API}/api/invoices/${inv.id}/feedback`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      toast.success(
        action === "approve_anyway"
          ? "✅ Faktura godkänd — AI lär sig av beslutet."
          : "🚫 Faktura bekräftad som risk."
      );
      setInsightInvoice(null);
    } catch {
      toast.error("Kunde inte spara feedback.");
    }
  };

  return (
    <div className="relative p-8 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-start mb-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-800">Fakturor</h1>
          <p className="text-slate-500 text-sm mt-1">
            Hantera, analysera och granska företagets fakturor med AI-insikter.
          </p>
        </div>

        {/* Upload */}
        <div className="flex items-center gap-3">
          <label className="cursor-pointer bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded-lg text-sm font-medium transition">
            <ArrowUpTrayIcon className="w-4 h-4 inline mr-1" />
            Välj fil
            <input
              type="file"
              accept="application/pdf"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files[0];
                setFile(f);
                if (f) toast.success(`📄 ${f.name} har valts.`);
              }}
            />
          </label>
          <button
            onClick={handleUpload}
            disabled={!file || loading}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-sm"
          >
            {loading ? "Analyserar..." : "Skanna faktura"}
          </button>
        </div>
      </div>

      {/* Visa att filen laddats */}
      {file && (
        <div className="mt-2 text-sm text-slate-600 flex items-center gap-2">
          <CheckCircleIcon className="w-4 h-4 text-green-500" />
          <span>{file.name}</span>
        </div>
      )}

      {/* Table */}
      <div className="bg-white border rounded-2xl shadow-md overflow-hidden mt-6">
        <table className="min-w-full text-sm text-left text-slate-700">
          <thead className="bg-slate-50 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3">Faktura-ID</th>
              <th className="px-4 py-3">Kund</th>
              <th className="px-4 py-3">Belopp</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">AI-förklaring</th>
              <th className="px-4 py-3 text-right">Insikter</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((inv, i) => (
              <motion.tr
                key={inv.id || i}
                className="border-b hover:bg-slate-50 transition"
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.03 }}
              >
                <td className="px-4 py-3 text-xs text-slate-500">
                  {inv.invoiceId || "–"}
                </td>
                <td className="px-4 py-3 font-medium">
                  {inv.customerName || "–"}
                </td>
                <td className="px-4 py-3">
                  <CurrencyDisplay total={inv.total} currency={inv.currency} />
                </td>
                <td className="px-4 py-3">
                  <StatusDisplay risk={inv.riskScore} />
                </td>
                <td className="px-4 py-3 text-xs text-slate-600 truncate">
                  {inv.aiSummary || "–"}
                </td>
                <td className="px-4 py-3 text-right">
                  {inv.riskScore > 40 ? (
                    <ShieldExclamationIcon
                      onClick={() => setInsightInvoice(inv)}
                      className="w-5 h-5 text-red-500 hover:text-red-600 cursor-pointer inline"
                    />
                  ) : (
                    <EyeIcon
                      onClick={() => setPdfUrl(inv.pdfUrl)}
                      className="w-5 h-5 text-slate-400 hover:text-blue-600 cursor-pointer inline"
                    />
                  )}
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* PDF & AI-insiktspaneler */}
      {pdfUrl && (
        <PdfSidePanel fileUrl={pdfUrl} onClose={() => setPdfUrl(null)} />
      )}
      {insightInvoice && (
        <AiInsightPanel
          invoice={insightInvoice}
          onClose={() => setInsightInvoice(null)}
          onFeedback={handleFeedback}
        />
      )}
    </div>
  );
}
