import React, { useState } from "react";
import {
  HomeIcon,
  ChartBarIcon,
  UserGroupIcon,
  BellIcon,
  DocumentArrowDownIcon,
  Cog6ToothIcon,
  UsersIcon,
  ArrowRightOnRectangleIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
} from "@heroicons/react/24/outline";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

export default function BureauLayout() {
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  const navLinks = [
    { name: "Dashboard", to: "/bureau", icon: HomeIcon },
    { name: "Kundöversikt", to: "/bureau/customers", icon: UsersIcon },
    { name: "Analys", to: "/bureau/insights", icon: ChartBarIcon },
    { name: "Team & Roller", to: "/bureau/team", icon: UserGroupIcon },
    { name: "Notifikationer", to: "/bureau/notifications", icon: BellIcon },
    { name: "Rapporter", to: "/bureau/reports", icon: DocumentArrowDownIcon },
  ];

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-gray-100 via-gray-50 to-gray-200 text-gray-800">
      {/* 🧭 Sidebar */}
      <motion.aside
        animate={{ width: collapsed ? 80 : 260 }}
        transition={{ duration: 0.25 }}
        className="bg-gradient-to-b from-gray-200 via-gray-300 to-gray-200 border-r border-gray-300 flex flex-col justify-between shadow-md"
      >
        <div>
          {/* Logo & collapse */}
          <div className="p-5 flex items-center justify-between border-b border-gray-300">
            <div className="flex items-center gap-3">
              <img src="/valiflow-logo.png" alt="Valiflow" className="w-8 h-8" />
              {!collapsed && (
                <h1 className="text-lg font-semibold text-gray-700">
                  Valiflow Byrå
                </h1>
              )}
            </div>
            <button
              onClick={() => setCollapsed(!collapsed)}
              className="p-1 rounded-md hover:bg-gray-200 text-gray-600 transition"
            >
              {collapsed ? (
                <ChevronRightIcon className="w-5 h-5" />
              ) : (
                <ChevronLeftIcon className="w-5 h-5" />
              )}
            </button>
          </div>

          {/* Navigation */}
          <nav className="mt-5 space-y-1 px-3">
            {navLinks.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === "/bureau"}
                className={({ isActive }) =>
                  [
                    "flex items-center gap-3 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200",
                    isActive
                      ? "bg-gradient-to-r from-emerald-500 to-cyan-400 text-white shadow-sm"
                      : "text-gray-700 hover:bg-gray-100 hover:text-gray-900",
                  ].join(" ")
                }
              >
                <link.icon className="w-5 h-5 shrink-0" />
                {!collapsed && <span>{link.name}</span>}
              </NavLink>
            ))}
          </nav>
        </div>

        {/* ⚙️ Footer actions */}
        <div className="p-4 border-t border-gray-300 space-y-2">
          <button
            onClick={() => navigate("/bureau/settings")}
            className="flex items-center gap-2 w-full text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900 px-3 py-2 rounded-lg transition"
          >
            <Cog6ToothIcon className="w-5 h-5 shrink-0" />
            {!collapsed && <span>Inställningar</span>}
          </button>

          <button
            onClick={handleLogout}
            className="flex items-center gap-2 w-full text-sm text-gray-700 hover:bg-gray-100 hover:text-red-500 px-3 py-2 rounded-lg transition"
          >
            <ArrowRightOnRectangleIcon className="w-5 h-5 shrink-0" />
            {!collapsed && <span>Logga ut</span>}
          </button>
        </div>
      </motion.aside>

      {/* 📄 Main content */}
      <main className="flex-1 overflow-y-auto bg-gradient-to-br from-gray-50 via-white to-gray-100">
        <div className="p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
