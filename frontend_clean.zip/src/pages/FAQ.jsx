import React, { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";

const faqs = [
  {
    question: "Vad är Valiflow?",
    answer:
      "Valiflow är en AI-driven plattform som upptäcker och stoppar falska eller manipulerade fakturor innan de betalas.",
  },
  {
    question: "Behöver jag byta mitt nuvarande system?",
    answer:
      "Nej. Valiflow fungerar ovanpå dina befintliga processer och kräver ingen systemmigration.",
  },
  {
    question: "Hur säkra är mina data?",
    answer:
      "All data krypteras och lagras inom EU enligt GDPR och ISO 27001-standard.",
  },
];

export default function FAQPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-slate-900 text-slate-900 dark:text-white">
      <header className="text-center py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/10 via-cyan-400/10 to-indigo-500/10" />
        <div className="relative max-w-4xl mx-auto px-6">
          <h1 className="text-4xl font-bold sm:text-5xl mb-4">Vanliga frågor</h1>
          <p className="text-lg text-slate-600 dark:text-slate-300">
            Här hittar du svar på de vanligaste frågorna om Valiflow.
          </p>
        </div>
      </header>

      <section className="max-w-3xl mx-auto px-6 py-20 space-y-4">
        {faqs.map((faq, i) => (
          <FAQItem key={i} {...faq} />
        ))}
      </section>
    </div>
  );
}

function FAQItem({ question, answer }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="border border-slate-200 dark:border-slate-800 rounded-xl bg-white/70 dark:bg-slate-900/60 p-5 shadow-sm backdrop-blur-sm transition">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex justify-between items-center text-left font-medium text-slate-800 dark:text-white"
      >
        {question}
        {open ? (
          <ChevronUp className="h-5 w-5 text-emerald-600" />
        ) : (
          <ChevronDown className="h-5 w-5 text-emerald-600" />
        )}
      </button>
      {open && (
        <p className="mt-3 text-sm text-slate-600 dark:text-slate-300">{answer}</p>
      )}
    </div>
  );
}
