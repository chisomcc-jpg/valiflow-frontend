// src/components/ProtectedRoute.jsx
import React, { useEffect } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function ProtectedRoute({ children, allowedRoles }) {
  const { token, user, loading } = useAuth();
  const location = useLocation();

  // 🧩 Debug (optional – comment out later)
  console.count("ProtectedRoute render");
  console.log("ProtectedRoute state:", {
    pathname: location.pathname,
    token: !!token,
    role: user?.role,
    loading,
  });

  // 🕐 Wait for AuthContext to finish initializing
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen text-slate-600 dark:text-slate-300">
        Checking session...
      </div>
    );
  }

  // 🚪 Not logged in → redirect to login (avoid loop if already on /login)
  if (!token) {
    if (location.pathname === "/login") {
      return children || null; // allow login page to show
    }
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  // 🛡️ Role-based restriction
  if (allowedRoles && user?.role && !allowedRoles.includes(user.role)) {
    // avoid redirect loop if already on /unauthorized
    if (location.pathname === "/unauthorized") {
      return children || null;
    }
    return <Navigate to="/unauthorized" replace />;
  }

  // ✅ Everything OK → render protected content
  return children;
}
