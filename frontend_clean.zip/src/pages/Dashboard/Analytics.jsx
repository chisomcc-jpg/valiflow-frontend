import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowTrendingUpIcon,
  BanknotesIcon,
  ExclamationTriangleIcon,
  ShieldExclamationIcon,
  ChartBarIcon,
  ExclamationCircleIcon,
  SparklesIcon,
} from "@heroicons/react/24/outline";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts";

/* ========= Mockdata (leverantörsfokus) ========= */
const monthlySpending = [
  { name: "Jan", value: 220000 },
  { name: "Feb", value: 250000 },
  { name: "Mar", value: 310000 },
  { name: "Apr", value: 295000 },
  { name: "Maj", value: 330000 },
  { name: "Jun", value: 370000 },
];

const supplierRisk = [
  { name: "Jan", risk: 18 },
  { name: "Feb", risk: 22 },
  { name: "Mar", risk: 33 },
  { name: "Apr", risk: 41 },
  { name: "Maj", risk: 35 },
  { name: "Jun", risk: 29 },
];

const invoiceStatus = [
  { name: "Betalda", value: 72 },
  { name: "Försenade", value: 18 },
  { name: "Under granskning", value: 10 },
];

const COLORS = ["#22C55E", "#FACC15", "#EF4444"];

/* ========= AI-insikter (Valiflow-specifika) ========= */
const aiInsights = [
  "Tre leverantörer har fakturerat ovanligt höga belopp senaste månaden. Rekommenderad manuell granskning.",
  "Totala inköpskostnader ökade med 12 % jämfört med föregående månad, främst inom IT och transport.",
  "Två fakturor med identiskt belopp från samma leverantör — möjlig dubbelfakturering.",
  "Fem fakturor är försenade mer än 15 dagar. Säkerställ attestflöde och påminnelsepolicy.",
  "En leverantör visar ovanligt hög fakturafrekvens. Riskmotor indikerar 63 % sannolikhet för felaktig fakturering.",
  "Minskning av fakturor från största leverantörerna kan indikera kommande kontraktsförändringar.",
  "Fyra leverantörer markerade med stigande kostnadstrend (>25 %) under senaste kvartalet.",
];

export default function Analytics() {
  const [activeTab, setActiveTab] = useState("overview");
  const [aiMessageOverview, setAiMessageOverview] = useState("");
  const [aiMessageRisk, setAiMessageRisk] = useState("");

  useEffect(() => {
    // Välj slumpade AI-sammanfattningar
    setAiMessageOverview(aiInsights[Math.floor(Math.random() * aiInsights.length)]);
    setAiMessageRisk(aiInsights[Math.floor(Math.random() * aiInsights.length)]);
  }, []);

  return (
    <div className="p-8 space-y-8 bg-gradient-to-b from-slate-50 to-white min-h-screen">
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold text-slate-900">Analys & Insikter</h1>
        <p className="text-slate-500 mt-1">
          Få en djupare förståelse för dina leverantörsfakturor, risker och trender.
        </p>
      </div>

      {/* Flikar */}
      <div className="flex bg-white border border-slate-200 rounded-2xl shadow-lg p-1">
        {[
          { id: "overview", label: "Översikt", icon: ChartBarIcon, color: "from-blue-600 to-cyan-500" },
          { id: "risk", label: "Riskanalys", icon: ShieldExclamationIcon, color: "from-rose-600 to-pink-500" },
          { id: "trend", label: "Trender", icon: ArrowTrendingUpIcon, color: "from-emerald-600 to-green-500" },
          { id: "anomalies", label: "Avvikelser", icon: ExclamationCircleIcon, color: "from-amber-500 to-orange-400" },
        ].map(({ id, label, icon: Icon, color }) => {
          const active = activeTab === id;
          return (
            <motion.button
              key={id}
              onClick={() => setActiveTab(id)}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className={`relative flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                active ? "text-white shadow-md" : "text-slate-600 hover:text-slate-900"
              }`}
            >
              {active && (
                <motion.div
                  layoutId="activeGlow"
                  className={`absolute inset-0 rounded-xl bg-gradient-to-r ${color} shadow-lg`}
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
              <motion.div
                className="relative z-10 flex items-center gap-2"
                animate={{ y: active ? -2 : 0 }}
                transition={{ duration: 0.2 }}
              >
                <Icon className="w-5 h-5" />
                <span>{label}</span>
              </motion.div>
            </motion.button>
          );
        })}
      </div>

      {/* Innehåll per flik */}
      <div className="relative mt-6">
        <AnimatePresence mode="wait">
          {/* ============ ÖVERSIKT ============ */}
          {activeTab === "overview" && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -24 }}
              transition={{ duration: 0.4 }}
              className="space-y-8"
            >
              {/* AI-sammanfattning högst upp */}
              <PremiumCard title="🤖 AI-sammanfattning (Leverantörsfakturor)">
                <div className="flex items-start gap-3 text-slate-700 text-sm">
                  <SparklesIcon className="w-5 h-5 text-blue-600 mt-0.5" />
                  <p>{aiMessageOverview}</p>
                </div>
              </PremiumCard>

              {/* KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
                <AnimatedKpi
                  title="Totalt fakturabelopp (månad)"
                  value={370000}
                  suffix="SEK"
                  icon={<BanknotesIcon className="w-6 h-6" />}
                  color="from-blue-600 to-cyan-500"
                />
                <AnimatedKpi
                  title="Betalda fakturor"
                  value={280000}
                  suffix="SEK"
                  icon={<ArrowTrendingUpIcon className="w-6 h-6" />}
                  color="from-emerald-600 to-green-500"
                />
                <AnimatedKpi
                  title="Försenade fakturor"
                  value={90000}
                  suffix="SEK"
                  icon={<ExclamationTriangleIcon className="w-6 h-6" />}
                  color="from-amber-500 to-orange-400"
                />
                <AnimatedKpi
                  title="Genomsnittlig risknivå"
                  value={29}
                  suffix="%"
                  icon={<ShieldExclamationIcon className="w-6 h-6" />}
                  color="from-rose-500 to-pink-500"
                />
              </div>

              {/* Diagram (glass & glow) */}
              <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
                <ChartCard title="Inköpskostnad per månad">
                  <GradientBarChart />
                </ChartCard>

                <ChartCard title="Risknivå över tid (leverantörer)">
                  <GlowLineChart />
                </ChartCard>

                <ChartCard title="Fakturastatus – Fördelning">
                  <PieStatusChart />
                </ChartCard>
              </div>
            </motion.div>
          )}

          {/* ============ RISKANALYS ============ */}
          {activeTab === "risk" && (
            <motion.div
              key="risk"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -24 }}
              transition={{ duration: 0.4 }}
              className="space-y-8"
            >
              <PremiumCard title="🤖 AI-insikter (Risk)">
                <div className="flex items-start gap-3 text-slate-700 text-sm">
                  <SparklesIcon className="w-5 h-5 text-rose-600 mt-0.5" />
                  <p>{aiMessageRisk}</p>
                </div>
              </PremiumCard>

              <ChartCard title="Risknivå – Leverantörstrend">
                <GlowLineChart />
              </ChartCard>
            </motion.div>
          )}

          {/* ============ TRENDER ============ */}
          {activeTab === "trend" && (
            <motion.div
              key="trend"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -24 }}
              transition={{ duration: 0.4 }}
            >
              <ChartCard title="Trendanalys – Kostnad vs Risk">
                <DualGlowLineChart />
              </ChartCard>
            </motion.div>
          )}

          {/* ============ AVVIKELSER ============ */}
          {activeTab === "anomalies" && (
            <motion.div
              key="anomalies"
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -24 }}
              transition={{ duration: 0.4 }}
            >
              <PremiumCard title="Identifierade avvikelser">
                <table className="w-full border-collapse text-sm text-slate-700">
                  <thead>
                    <tr className="border-b bg-slate-50 text-slate-600">
                      <th className="p-2 text-left">Leverantör</th>
                      <th className="p-2 text-left">Faktura #</th>
                      <th className="p-2 text-left">Avvikelse</th>
                      <th className="p-2 text-left">Risknivå</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { supplier: "TechLog AB", id: "SUP-2045", note: "Ovanligt högt fakturabelopp", risk: 75 },
                      { supplier: "DataNordic", id: "SUP-2039", note: "Möjlig dubbelfakturering upptäckt", risk: 68 },
                      { supplier: "CleanWorks AB", id: "SUP-2031", note: "Försenad betalning 20 dagar", risk: 51 },
                    ].map((a) => (
                      <tr key={a.id} className="border-b hover:bg-slate-50 transition">
                        <td className="p-2 font-medium">{a.supplier}</td>
                        <td className="p-2">{a.id}</td>
                        <td className="p-2 text-slate-600">{a.note}</td>
                        <td className="p-2">
                          <div className="w-full bg-slate-100 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full ${
                                a.risk > 70
                                  ? "bg-red-500"
                                  : a.risk > 40
                                  ? "bg-yellow-500"
                                  : "bg-green-500"
                              }`}
                              style={{ width: `${a.risk}%` }}
                            ></div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </PremiumCard>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ================= Helpers / UI ================= */

function PremiumCard({ title, children }) {
  return (
    <motion.div
      whileHover={{ y: -3 }}
      transition={{ duration: 0.2 }}
      className="bg-white/90 backdrop-blur border border-slate-100 rounded-2xl shadow-xl p-6 relative overflow-hidden"
    >
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-white/40 via-transparent to-slate-100/50" />
      {title && <h2 className="text-lg font-semibold text-slate-800 mb-3 relative z-10">{title}</h2>}
      <div className="relative z-10">{children}</div>
    </motion.div>
  );
}

function ChartCard({ title, children }) {
  return (
    <motion.div
      whileHover={{ scale: 1.01 }}
      className="bg-white/90 backdrop-blur border border-slate-100 rounded-2xl shadow-xl p-6 relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-slate-50 via-transparent to-slate-100 opacity-70" />
      <h2 className="text-lg font-semibold text-slate-800 mb-3 relative z-10">{title}</h2>
      <div className="relative z-10">{children}</div>
    </motion.div>
  );
}

function AnimatedKpi({ title, value, suffix, icon, color }) {
  const [displayValue, setDisplayValue] = useState(0);
  useEffect(() => {
    let start = 0;
    const end = value;
    const step = Math.max(1, Math.floor(end / 40));
    const interval = setInterval(() => {
      start += step;
      if (start >= end) {
        start = end;
        clearInterval(interval);
      }
      setDisplayValue(start);
    }, 25);
    return () => clearInterval(interval);
  }, [value]);

  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
      className="relative bg-white/90 backdrop-blur border border-slate-100 rounded-2xl shadow-2xl overflow-hidden"
    >
      <div className={`absolute inset-0 bg-gradient-to-r ${color} opacity-25 blur-sm`} />
      <div className="relative z-10 p-5 flex justify-between items-center">
        <div>
          <p className="text-slate-600 text-sm">{title}</p>
          <h3 className="text-2xl font-bold text-slate-900 mt-1">
            {displayValue.toLocaleString()} {suffix}
          </h3>
        </div>
        <div className="p-3 bg-white/70 rounded-xl shadow-sm backdrop-blur">{icon}</div>
      </div>
    </motion.div>
  );
}

/* ================= Premium Charts ================= */

/* — Bar med gradient + drop shadow — */
function GradientBarChart() {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={monthlySpending}>
        <defs>
          <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#3B82F6" stopOpacity={0.95} />
            <stop offset="100%" stopColor="#93C5FD" stopOpacity={0.45} />
          </linearGradient>
          <filter id="barShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="6" stdDeviation="6" floodColor="#3b82f6" floodOpacity="0.18" />
          </filter>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Bar dataKey="value" fill="url(#barGradient)" radius={[10, 10, 0, 0]} style={{ filter: "url(#barShadow)" }} />
      </BarChart>
    </ResponsiveContainer>
  );
}

/* — Line med glow + area-fill för djup — */
function GlowLineChart() {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <LineChart data={supplierRisk}>
        <defs>
          <linearGradient id="riskLineGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#F43F5E" stopOpacity={0.95} />
            <stop offset="100%" stopColor="#FDA4AF" stopOpacity={0.35} />
          </linearGradient>
          <linearGradient id="riskAreaGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#F43F5E" stopOpacity={0.18} />
            <stop offset="100%" stopColor="#ffffff" stopOpacity={0} />
          </linearGradient>
          <filter id="lineGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="2.5" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        {/* Area för djup */}
        <AreaShade dataKey="risk" fill="url(#riskAreaGrad)" />
        {/* Glow line */}
        <Line
          type="monotone"
          dataKey="risk"
          stroke="url(#riskLineGrad)"
          strokeWidth={4}
          dot={{ r: 4, fill: "#F43F5E" }}
          style={{ filter: "url(#lineGlow)" }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

/* — Dual line (kostnad & risk) med glow/gradient — */
function DualGlowLineChart() {
  const combined = monthlySpending.map((m, i) => ({
    name: m.name,
    cost: m.value,
    risk: supplierRisk[i]?.risk ?? 0,
  }));
  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={combined}>
        <defs>
          <linearGradient id="costGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#3B82F6" stopOpacity={0.95} />
            <stop offset="100%" stopColor="#93C5FD" stopOpacity={0.35} />
          </linearGradient>
          <linearGradient id="riskGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#F43F5E" stopOpacity={0.95} />
            <stop offset="100%" stopColor="#FDA4AF" stopOpacity={0.35} />
          </linearGradient>
          <filter id="dualGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="2.2" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Line type="monotone" dataKey="cost" stroke="url(#costGrad)" strokeWidth={4} dot={false} style={{ filter: "url(#dualGlow)" }} />
        <Line type="monotone" dataKey="risk" stroke="url(#riskGrad)" strokeWidth={3} strokeDasharray="5 5" dot={{ r: 3 }} style={{ filter: "url(#dualGlow)" }} />
      </LineChart>
    </ResponsiveContainer>
  );
}

/* — Pie med subtil skugga — */
function PieStatusChart() {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <PieChart>
        <defs>
          <filter id="pieShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="4" stdDeviation="6" floodColor="#0f172a" floodOpacity="0.12" />
          </filter>
        </defs>
        <Pie
          data={invoiceStatus}
          dataKey="value"
          nameKey="name"
          innerRadius={60}
          outerRadius={95}
          label
          style={{ filter: "url(#pieShadow)" }}
        >
          {invoiceStatus.map((_, i) => (
            <Cell key={i} fill={COLORS[i % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip />
      </PieChart>
    </ResponsiveContainer>
  );
}

/* — Liten helper för area-shade (recharts saknar Area i importlistan ovan, så vi gör enkel path) — */
function AreaShade({ dataKey, fill }) {
  // Förenklad: använd samma LineChart-data via render-prop-liknande trick med "Line" som osynlig och fyll med <path>.
  // För enkelhet: vi duplicerar en tunn linje utan stroke (visuellt funkar bra).
  return <Line type="monotone" dataKey={dataKey} stroke="transparent" fill={fill} strokeWidth={0} dot={false} />;
}
