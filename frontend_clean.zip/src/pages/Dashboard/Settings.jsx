import React, { useState } from "react";
import {
  BuildingOffice2Icon,
  DocumentTextIcon,
  ShieldCheckIcon,
  LinkIcon,
  CreditCardIcon,
  Cog6ToothIcon,
  AdjustmentsHorizontalIcon,
  ArrowPathIcon,
  PlusIcon,
} from "@heroicons/react/24/outline";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { motion, AnimatePresence } from "framer-motion";

export default function CompanySettings() {
  const [tab, setTab] = useState("general");

  const tabs = [
    { id: "general", name: "Företagsinformation", icon: BuildingOffice2Icon },
    { id: "ai", name: "Fakturahantering & AI", icon: DocumentTextIcon },
    { id: "integrations", name: "Integrationer", icon: LinkIcon },
    { id: "security", name: "Säkerhet & Åtkomst", icon: ShieldCheckIcon },
    { id: "billing", name: "Plan & Fakturering", icon: CreditCardIcon },
  ];

  const [aiSettings, setAiSettings] = useState({
    aiReview: true,
    aiSummary: true,
    autoSync: false,
    riskThreshold: 0.7,
  });

  const [notifications, setNotifications] = useState({
    riskAlert: true,
    newInvoice: false,
    aiReport: true,
  });

  const [integrations, setIntegrations] = useState([
    { name: "Fortnox", status: "Ansluten", color: "text-emerald-600" },
    { name: "Visma", status: "Ej ansluten", color: "text-slate-400" },
    { name: "Microsoft 365", status: "Ansluten", color: "text-emerald-600" },
  ]);

  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 via-white to-slate-100 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-2">
            <Cog6ToothIcon className="w-7 h-7 text-emerald-600" />
            Företagsinställningar
          </h1>
          <p className="text-slate-500 mt-1 text-sm">
            Hantera företagets fakturahantering, AI-inställningar och säkerhet.
          </p>
        </div>
        <Button className="bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-2">
          <ArrowPathIcon className="w-5 h-5" />
          Spara ändringar
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-6 border-b border-slate-200 mb-8 sticky top-0 bg-gradient-to-br from-slate-50 via-white to-slate-100 z-10">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`pb-3 flex items-center gap-2 font-medium text-sm transition-all ${
              tab === t.id
                ? "text-emerald-600 border-b-2 border-emerald-600"
                : "text-slate-500 hover:text-slate-700"
            }`}
          >
            <t.icon className="w-4 h-4" />
            {t.name}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.25 }}
        >
          {/* 🏢 Företagsinformation */}
          {tab === "general" && (
            <Card className="border border-slate-200 bg-white shadow-sm p-6">
              <h2 className="text-lg font-semibold text-slate-800 mb-6 flex items-center gap-2">
                <BuildingOffice2Icon className="w-5 h-5 text-emerald-600" />
                Företagsinformation
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm text-slate-600">Företagsnamn</label>
                  <input
                    type="text"
                    placeholder="Valiflow AB"
                    className="w-full mt-1 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-600">Organisationsnummer</label>
                  <input
                    type="text"
                    placeholder="559000-1234"
                    className="w-full mt-1 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-600">Kontaktperson</label>
                  <input
                    type="text"
                    placeholder="Anna Svensson"
                    className="w-full mt-1 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-600">Kontakt-Epost</label>
                  <input
                    type="email"
                    placeholder="anna@företag.se"
                    className="w-full mt-1 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>
                <div className="col-span-2">
                  <label className="text-sm text-slate-600">Logotyp</label>
                  <div className="flex items-center gap-3 mt-1">
                    <div className="h-12 w-12 bg-slate-100 rounded-lg flex items-center justify-center text-slate-400">
                      LOGO
                    </div>
                    <Button variant="outline" size="sm">
                      Ladda upp
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          )}

          {/* 🤖 Fakturahantering & AI */}
          {tab === "ai" && (
            <Card className="border border-slate-200 bg-white shadow-sm p-6 space-y-6">
              <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                <DocumentTextIcon className="w-5 h-5 text-emerald-600" />
                Fakturahantering & AI
              </h2>

              <div className="space-y-3">
                {[
                  ["Aktivera AI-granskning", "aiReview"],
                  ["Visa AI-sammanfattningar", "aiSummary"],
                  ["Automatisk synk vid uppladdning", "autoSync"],
                ].map(([label, key]) => (
                  <div key={key} className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">{label}</span>
                    <Switch
                      checked={aiSettings[key]}
                      onCheckedChange={() =>
                        setAiSettings((prev) => ({ ...prev, [key]: !prev[key] }))
                      }
                    />
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-slate-100">
                <label className="text-sm text-slate-600 mb-2 block">
                  Risknivå-tröskel (AI flaggar fakturor över denna nivå)
                </label>
                <select
                  value={aiSettings.riskThreshold}
                  onChange={(e) =>
                    setAiSettings({ ...aiSettings, riskThreshold: parseFloat(e.target.value) })
                  }
                  className="border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500"
                >
                  <option value={0.5}>0.5 (medelrisk)</option>
                  <option value={0.7}>0.7 (hög risk)</option>
                  <option value={0.9}>0.9 (mycket hög risk)</option>
                </select>
              </div>
            </Card>
          )}

          {/* 🔗 Integrationer */}
          {tab === "integrations" && (
            <Card className="border border-slate-200 bg-white shadow-sm p-6">
              <h2 className="text-lg font-semibold text-slate-800 mb-6 flex items-center gap-2">
                <LinkIcon className="w-5 h-5 text-emerald-600" />
                Integrationer
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {integrations.map((app, i) => (
                  <motion.div
                    key={i}
                    whileHover={{ scale: 1.02 }}
                    className="p-4 border border-slate-200 rounded-xl shadow-sm bg-white hover:shadow-md transition-all"
                  >
                    <h3 className="font-medium text-slate-800 mb-1">{app.name}</h3>
                    <p className={`${app.color} text-sm mb-3`}>{app.status}</p>
                    <Button
                      size="sm"
                      variant={app.status === "Ansluten" ? "outline" : "default"}
                      className={
                        app.status === "Ansluten"
                          ? "text-slate-600 border-slate-200"
                          : "bg-emerald-600 text-white hover:bg-emerald-700"
                      }
                    >
                      {app.status === "Ansluten" ? "Koppla bort" : "Koppla"}
                    </Button>
                  </motion.div>
                ))}
              </div>
            </Card>
          )}

          {/* 🔒 Säkerhet & Åtkomst */}
          {tab === "security" && (
            <Card className="border border-slate-200 bg-white shadow-sm p-6 space-y-6">
              <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                <ShieldCheckIcon className="w-5 h-5 text-emerald-600" />
                Säkerhet & Åtkomst
              </h2>

              <div className="space-y-3">
                {Object.entries(notifications).map(([key, value]) => (
                  <div key={key} className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">
                      {key === "riskAlert"
                        ? "Notifiera vid hög riskfaktura"
                        : key === "newInvoice"
                        ? "Notifiera vid ny faktura"
                        : "Notifiera vid AI-granskning"}
                    </span>
                    <Switch
                      checked={value}
                      onCheckedChange={() =>
                        setNotifications((prev) => ({
                          ...prev,
                          [key]: !prev[key],
                        }))
                      }
                    />
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t border-slate-100">
                <Button
                  variant="outline"
                  className="text-slate-600 border-slate-200 hover:bg-slate-50 text-sm flex items-center gap-1"
                >
                  <ShieldCheckIcon className="w-4 h-4" /> Aktivera BankID / 2FA
                </Button>
              </div>
            </Card>
          )}

          {/* 💳 Plan & Fakturering */}
          {tab === "billing" && (
            <Card className="border border-slate-200 bg-white shadow-sm p-6 flex justify-between items-center">
              <div>
                <h2 className="text-lg font-semibold text-slate-800 mb-1 flex items-center gap-2">
                  <CreditCardIcon className="w-5 h-5 text-emerald-600" />
                  Plan & Fakturering
                </h2>
                <p className="text-slate-500 text-sm">
                  Plan: <span className="font-medium text-slate-700">Företag Pro</span> • 1490 kr/mån
                </p>
                <p className="text-slate-500 text-sm">Nästa fakturering: 25 november 2025</p>
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="text-slate-600 border-slate-200 hover:bg-slate-50">
                  Visa fakturor
                </Button>
                <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
                  Uppgradera plan
                </Button>
              </div>
            </Card>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
