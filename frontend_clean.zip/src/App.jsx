import React, { Suspense, lazy } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Loader from "./components/Loader.jsx";

// 🌍 Public pages
import Home from "./pages/Home.jsx";
import Product from "./pages/Product.jsx";
import PricingPage from "./pages/Pricing.jsx";
import FAQPage from "./pages/FAQ.jsx";
import CompliancePage from "./pages/CompliancePage.jsx";
import MainLayout from "./layouts/MainLayout.jsx";

// 🔐 Auth pages
import Login from "./pages/Auth/Login.jsx";
import Register from "./pages/Register.jsx";
import VerifyBankID from "./pages/VerifyBankID.jsx";
import BankIDLogin from "./pages/Auth/BankIDLogin.jsx";

// 🔒 Route protection
import ProtectedRoute from "./components/ProtectedRoute.jsx";
import AdminRoute from "./components/AdminRoute.jsx";

// 🚫 System Pages
import NotFound from "./pages/NotFound.jsx";
import Unauthorized from "./pages/Unauthorized.jsx";

/* --------------------------------------------
   ⚙️ Lazy-loaded dashboards (CFA / Admin / Byrå)
---------------------------------------------*/
const DashboardLayout = lazy(() => import("./layouts/DashboardLayout.jsx"));
const Dashboard = lazy(() => import("./pages/Dashboard/Overview.jsx"));
const Customers = lazy(() => import("./pages/Dashboard/Customers.jsx"));
const Invoices = lazy(() => import("./pages/Dashboard/Invoices.jsx"));
const Email = lazy(() => import("./pages/Dashboard/Email.js"));
const FraudOverview = lazy(() => import("./pages/Dashboard/FraudOverview.jsx"));
const FraudLogs = lazy(() => import("./pages/Dashboard/FraudLogs.jsx"));
const Settings = lazy(() => import("./pages/Dashboard/Settings.jsx"));
const Analytics = lazy(() => import("./pages/Dashboard/Analytics.jsx"));
const Integrations = lazy(() => import("./pages/Dashboard/Integrations.jsx"));
const Company = lazy(() => import("./pages/Dashboard/Company.jsx"));
const AuditLog = lazy(() => import("./pages/Dashboard/AuditLog.jsx"));

// 🛡️ Admin Dashboard
const AdminLayout = lazy(() => import("./layouts/AdminLayout.jsx"));
const Overview = lazy(() => import("./pages/AdminDashboard/Overview.jsx"));
const Firms = lazy(() => import("./pages/AdminDashboard/Firms.jsx"));
const FirmDetails = lazy(() => import("./pages/AdminDashboard/FirmDetails.jsx"));
const Clients = lazy(() => import("./pages/AdminDashboard/Clients.jsx"));
const InvoicesAdmin = lazy(() => import("./pages/AdminDashboard/Invoices.jsx"));
const InvoiceDetails = lazy(() => import("./pages/AdminDashboard/InvoiceDetails.jsx"));
const Fraud = lazy(() => import("./pages/AdminDashboard/Fraud.jsx"));
const Rules = lazy(() => import("./pages/AdminDashboard/Rules.jsx"));
const Users = lazy(() => import("./pages/AdminDashboard/Users.jsx"));
const Logs = lazy(() => import("./pages/AdminDashboard/Logs.jsx"));
const AdminSettings = lazy(() => import("./pages/AdminDashboard/Settings.jsx"));

// 🧮 Byrå Dashboard
const BureauLayout = lazy(() => import("./layouts/BureauLayout.jsx"));
const BureauDashboard = lazy(() => import("./pages/BureauDashboard/BureauDashboard.jsx"));
const BureauCustomers = lazy(() => import("./pages/BureauDashboard/BureauCustomers.jsx"));
const BureauInsights = lazy(() => import("./pages/BureauDashboard/BureauInsights.jsx"));
const BureauTeam = lazy(() => import("./pages/BureauDashboard/BureauTeam.jsx"));
const BureauNotifications = lazy(() => import("./pages/BureauDashboard/BureauNotifications.jsx"));
const BureauReports = lazy(() => import("./pages/BureauDashboard/BureauReports.jsx"));
const BureauSettings = lazy(() => import("./pages/BureauDashboard/BureauSettings.jsx"));

export default function App() {
  return (
    <Suspense fallback={<Loader />}>
      <Routes>
        {/* 🌍 Public Website Pages */}
        <Route element={<MainLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/product" element={<Product />} />
          <Route path="/pricing" element={<PricingPage />} />
          <Route path="/faq" element={<FAQPage />} />
          <Route path="/compliance" element={<CompliancePage />} />
        </Route>

        {/* 🔐 Auth Pages */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/verify-bankid" element={<VerifyBankID />} />
        <Route path="/bankid-login" element={<BankIDLogin />} />

        {/* 🧭 CFA Dashboard (företagsanvändare) */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Dashboard />} />
          <Route path="customers" element={<Customers />} />
          <Route path="invoices" element={<Invoices />} />
          <Route path="email" element={<Email />} />
          <Route path="fraud" element={<FraudOverview />} />
          <Route path="fraud-logs" element={<FraudLogs />} />
          <Route path="analytics" element={<Analytics />} />
          <Route path="audit-log" element={<AuditLog />} />
          <Route path="integrations" element={<Integrations />} />
          <Route path="company" element={<Company />} />
          <Route path="settings" element={<Settings />} />
        </Route>

        {/* 🛡️ Valiflow Admin Dashboard */}
        <Route
          path="/admin"
          element={
            <AdminRoute>
              <AdminLayout />
            </AdminRoute>
          }
        >
          <Route index element={<Navigate to="overview" replace />} />
          <Route path="overview" element={<Overview />} />
          <Route path="firms" element={<Firms />} />
          <Route path="firms/:id" element={<FirmDetails />} />
          <Route path="clients" element={<Clients />} />
          <Route path="invoices" element={<InvoicesAdmin />} />
          <Route path="invoices/:id" element={<InvoiceDetails />} />
          <Route path="fraud" element={<Fraud />} />
          <Route path="rules" element={<Rules />} />
          <Route path="users" element={<Users />} />
          <Route path="logs" element={<Logs />} />
          <Route path="settings" element={<AdminSettings />} />
        </Route>

        {/* 🧮 Byrå Dashboard */}
        <Route
          path="/bureau"
          element={
            <ProtectedRoute>
              <BureauLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<BureauDashboard />} />
          <Route path="customers" element={<BureauCustomers />} />
          <Route path="insights" element={<BureauInsights />} />
          <Route path="team" element={<BureauTeam />} />
          <Route path="notifications" element={<BureauNotifications />} />
          <Route path="reports" element={<BureauReports />} />
          <Route path="settings" element={<BureauSettings />} />
        </Route>

        {/* 🚫 System Pages */}
        <Route path="/unauthorized" element={<Unauthorized />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}
