import React from "react";
import { ShieldCheck, Lock, Globe2, CheckCircle2 } from "lucide-react";

// ✅ Main component (default export)
export default function CompliancePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-slate-900 text-slate-900 dark:text-white">
      {/* HEADER */}
      <header className="relative overflow-hidden text-center py-24">
        <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/10 via-cyan-400/10 to-indigo-500/10" />
        <div className="relative mx-auto max-w-5xl px-6">
          <h1 className="text-4xl font-bold sm:text-5xl lg:text-6xl mb-4">
            Säkerhet & regelefterlevnad
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
            Vi tar datasäkerhet, integritet och svensk lagstiftning på största allvar.
            Valiflow är byggt med full transparens, kryptering och GDPR-efterlevnad från grunden.
          </p>
        </div>
      </header>

      {/* SECURITY PRINCIPLES */}
      <section className="max-w-6xl mx-auto px-6 py-20 grid gap-12 md:grid-cols-3 text-center">
        <SecurityCard
          icon={<Lock className="h-10 w-10 mx-auto mb-4 text-emerald-600" />}
          title="Kryptering & säker lagring"
          desc="All data krypteras i transit (TLS 1.3) och i vila med AES-256. Våra servrar är lokaliserade inom EU."
        />
        <SecurityCard
          icon={<ShieldCheck className="h-10 w-10 mx-auto mb-4 text-emerald-600" />}
          title="GDPR & ISO 27001"
          desc="Valiflow uppfyller GDPR och hanterar kunddata enligt ISO 27001-certifierade processer."
        />
        <SecurityCard
          icon={<Globe2 className="h-10 w-10 mx-auto mb-4 text-emerald-600" />}
          title="Europeisk datainfrastruktur"
          desc="All lagring och drift sker inom EES för att säkerställa regelefterlevnad med svensk och europeisk lag."
        />
      </section>

      {/* POLICIES SECTION */}
      <section className="bg-slate-100 dark:bg-slate-900 py-24">
        <div className="max-w-5xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-semibold mb-8">Våra principer för dataskydd</h2>
          <ul className="text-left max-w-3xl mx-auto space-y-4">
            <Policy text="Ingen data säljs eller delas med tredje part utan uttryckligt godkännande." />
            <Policy text="Alla åtkomster till kunddata loggas och granskas regelbundet." />
            <Policy text="Säkerhetskopior skapas dagligen och lagras krypterat." />
            <Policy text="Vi genomför årliga penetrationstester via oberoende säkerhetsföretag." />
            <Policy text="Databehandling sker endast i syfte att förbättra tjänsten och säkerheten." />
          </ul>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 text-center">
        <div className="max-w-3xl mx-auto">
          <h3 className="text-3xl font-semibold mb-4">
            Läs mer om hur vi skyddar din data
          </h3>
          <p className="text-slate-600 dark:text-slate-300 mb-6">
            Kontakta oss för att få vår fullständiga säkerhetspolicy, DPIA-dokumentation
            eller databehandlaravtal (DPA).
          </p>
          <a
            href="mailto:security@valiflow.com"
            className="inline-flex items-center gap-2 bg-gradient-to-tr from-emerald-600 to-cyan-600 text-white font-medium px-6 py-3 rounded-xl shadow hover:shadow-emerald-600/30 transition"
          >
            Kontakta säkerhetsteamet
          </a>
        </div>
      </section>
    </div>
  );
}

// ✅ Local helper components (not exported)
function SecurityCard({ icon, title, desc }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/70 p-6 shadow-md backdrop-blur-sm dark:border-slate-800 dark:bg-slate-900/60 transition hover:-translate-y-1 hover:shadow-lg">
      {icon}
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-sm text-slate-600 dark:text-slate-300">{desc}</p>
    </div>
  );
}

function Policy({ text }) {
  return (
    <li className="flex items-start gap-3 text-slate-700 dark:text-slate-300">
      <CheckCircle2 className="h-5 w-5 text-emerald-500 flex-shrink-0 mt-1" />
      <span>{text}</span>
    </li>
  );
}
