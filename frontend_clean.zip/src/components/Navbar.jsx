import React, { useState } from "react";
import { NavLink, Link } from "react-router-dom";
import { Menu, X, ChevronDown, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [showProducts, setShowProducts] = useState(false);
  const [showSolutions, setShowSolutions] = useState(false);

  // ✅ Bara befintliga sidor
  const navItems = [
    { name: "Priser", path: "/pricing" },
    { name: "FAQ", path: "/faq" },
    { name: "Om oss", path: "/compliance" },
  ];

  const products = [
    {
      title: "Fakturaskanning",
      desc: "Automatiserad tolkning och validering av leverantörsfakturor.",
      icon: "📄",
      link: "/product",
    },
    {
      title: "AI-bedrägerikontroll",
      desc: "Upptäck riskfaktorer innan du betalar.",
      icon: "🧠",
      link: "/product",
    },
    {
      title: "ERP-integrationer",
      desc: "Synka med Fortnox, Visma, Business Central m.fl.",
      icon: "🔗",
      link: "/product",
    },
  ];

  const solutions = [
    { title: "Ekonomiavdelningar", link: "/faq", icon: "🏢" },
    { title: "Redovisningsbyråer", link: "/faq", icon: "📊" },
    { title: "Enterprise", link: "/faq", icon: "🏦" },
  ];

  return (
<header className="fixed top-0 left-0 w-full bg-white border-b border-slate-200 z-[9999] shadow-sm">
  <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* ✅ Logo */}
        <Link to="/" className="flex items-center gap-3 group">
          <img src="/valiflow-logo.png" alt="Valiflow logo" className="h-10 w-auto" />
        </Link>

        {/* ✅ Main Nav */}
        <nav className="hidden lg:flex items-center gap-8 text-[15px] font-medium relative z-50">
          {/* Products Dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setShowProducts(true)}
            onMouseLeave={() => setShowProducts(false)}
          >
            <button className="flex items-center gap-1 text-slate-700 hover:text-blue-600 transition">
              Produkter
              <ChevronDown
                className={`h-4 w-4 transition-transform ${
                  showProducts ? "rotate-180" : ""
                }`}
              />
            </button>

            <AnimatePresence>
              {showProducts && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  transition={{ duration: 0.2 }}
                  className="absolute left-0 mt-4 w-[480px] bg-white rounded-2xl shadow-lg border border-slate-200 p-6 grid grid-cols-1 sm:grid-cols-2 gap-4"
                >
                  {products.map((p) => (
                    <Link
                      key={p.link + p.title}
                      to={p.link}
                      className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-50 transition"
                    >
                      <div className="text-2xl">{p.icon}</div>
                      <div className="text-left">
                        <p className="font-semibold text-slate-900">{p.title}</p>
                        <p className="text-sm text-slate-600">{p.desc}</p>
                      </div>
                    </Link>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Solutions Dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setShowSolutions(true)}
            onMouseLeave={() => setShowSolutions(false)}
          >
            <button className="flex items-center gap-1 text-slate-700 hover:text-blue-600 transition">
              Lösningar
              <ChevronDown
                className={`h-4 w-4 transition-transform ${
                  showSolutions ? "rotate-180" : ""
                }`}
              />
            </button>

            <AnimatePresence>
              {showSolutions && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  transition={{ duration: 0.2 }}
                  className="absolute left-0 mt-4 w-60 bg-white rounded-2xl shadow-lg border border-slate-200 p-4"
                >
                  {solutions.map((s) => (
                    <Link
                      key={s.link + s.title}
                      to={s.link}
                      className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 transition"
                    >
                      <div className="text-lg">{s.icon}</div>
                      <p className="text-sm font-medium text-slate-700">{s.title}</p>
                    </Link>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Other Nav Items */}
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `transition-colors duration-200 ${
                  isActive
                    ? "text-blue-600 font-semibold border-b-2 border-blue-600 pb-1"
                    : "text-slate-600 hover:text-blue-600"
                }`
              }
            >
              {item.name}
            </NavLink>
          ))}
        </nav>

        {/* ✅ Right Section */}
        <div className="flex items-center gap-4">
          <Link
            to="/login"
            className="hidden md:inline-flex text-slate-700 font-medium hover:text-blue-600 transition-colors"
          >
            Logga in
          </Link>
          <Link
            to="/register"
            className="hidden md:inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-blue-600 to-emerald-400 text-white font-semibold px-5 py-2.5 shadow-sm hover:shadow-md hover:opacity-95 transition"
          >
            Testa gratis
            <ArrowRight className="h-4 w-4" />
          </Link>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden p-2 text-slate-600" onClick={() => setOpen(!open)}>
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* ✅ Mobile Menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="lg:hidden bg-white border-t border-slate-200 px-6 py-4 space-y-4 shadow-md pointer-events-auto"
          >
            <details>
              <summary className="text-slate-700 font-semibold cursor-pointer">
                Produkter
              </summary>
              <div className="mt-2 pl-3 space-y-2">
                {products.map((p) => (
                  <Link
                    key={p.link}
                    to={p.link}
                    className="block text-sm text-slate-600 hover:text-blue-600 transition"
                    onClick={() => setOpen(false)}
                  >
                    {p.title}
                  </Link>
                ))}
              </div>
            </details>

            <details>
              <summary className="text-slate-700 font-semibold cursor-pointer">
                Lösningar
              </summary>
              <div className="mt-2 pl-3 space-y-2">
                {solutions.map((s) => (
                  <Link
                    key={s.link}
                    to={s.link}
                    className="block text-sm text-slate-600 hover:text-blue-600 transition"
                    onClick={() => setOpen(false)}
                  >
                    {s.title}
                  </Link>
                ))}
              </div>
            </details>

            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `block text-[15px] font-medium ${
                    isActive
                      ? "text-blue-600"
                      : "text-slate-700 hover:text-blue-600"
                  } transition-colors`
                }
              >
                {item.name}
              </NavLink>
            ))}

            <div className="pt-3 border-t border-slate-100 flex flex-col gap-3">
              <Link
                to="/login"
                className="block text-center text-slate-700 font-medium hover:text-blue-600 transition"
                onClick={() => setOpen(false)}
              >
                Logga in
              </Link>
              <Link
                to="/register"
                className="block text-center rounded-full bg-gradient-to-r from-blue-600 to-emerald-400 text-white font-semibold px-5 py-2 shadow-sm hover:shadow-md transition"
                onClick={() => setOpen(false)}
              >
                Testa gratis
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
