import React, { useMemo } from "react";
import {
  ChartBarIcon,
  BuildingOfficeIcon,
  DocumentTextIcon,
  ShieldExclamationIcon,
  ServerStackIcon,
  ArrowTrendingUpIcon,
  CpuChipIcon,
  BellAlertIcon,
} from "@heroicons/react/24/outline";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
  ResponsiveContainer,
} from "recharts";

// Dummy data
const activityData = [
  { name: "Mån", invoices: 1420 },
  { name: "Tis", invoices: 1600 },
  { name: "Ons", invoices: 1530 },
  { name: "Tor", invoices: 1710 },
  { name: "Fre", invoices: 1480 },
  { name: "Lör", invoices: 900 },
  { name: "Sön", invoices: 620 },
];

const fraudData = [
  { name: "Jan", flagged: 37, cleared: 210 },
  { name: "Feb", flagged: 41, cleared: 225 },
  { name: "Mar", flagged: 29, cleared: 240 },
  { name: "Apr", flagged: 50, cleared: 210 },
  { name: "Maj", flagged: 33, cleared: 260 },
  { name: "Jun", flagged: 28, cleared: 285 },
];

export default function Overview() {
  const currentHour = new Date().getHours();
  const greeting =
    currentHour < 12
      ? "God morgon ☀️"
      : currentHour < 18
      ? "God eftermiddag 👋"
      : "God kväll 🌙";

  // KPI cards data
  const kpis = useMemo(
    () => [
      {
        label: "Byråer anslutna",
        value: 28,
        change: "+7%",
        icon: BuildingOfficeIcon,
        color: "bg-emerald-100 text-emerald-700",
      },
      {
        label: "Företag & kunder",
        value: 312,
        change: "+12%",
        icon: ChartBarIcon,
        color: "bg-blue-100 text-blue-700",
      },
      {
        label: "Fakturor inskannade",
        value: "18 942",
        change: "+4%",
        icon: DocumentTextIcon,
        color: "bg-cyan-100 text-cyan-700",
      },
      {
        label: "Flaggade (AI)",
        value: 121,
        change: "-2%",
        icon: ShieldExclamationIcon,
        color: "bg-red-100 text-red-700",
      },
      {
        label: "AI-accuracy",
        value: "94.2%",
        change: "+1.1%",
        icon: CpuChipIcon,
        color: "bg-violet-100 text-violet-700",
      },
      {
        label: "API-uptime",
        value: "99.98%",
        change: "stable",
        icon: ServerStackIcon,
        color: "bg-gray-100 text-gray-700",
      },
    ],
    []
  );

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-slate-800">
          {greeting}, Chidi
        </h1>
        <p className="text-slate-500">
          Här är en överblick över Valiflow-plattformens läge just nu.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
        {kpis.map((kpi, i) => (
          <div
            key={i}
            className="bg-white border rounded-2xl shadow-sm p-5 flex items-center justify-between hover:shadow-md transition"
          >
            <div>
              <p className="text-sm text-gray-500">{kpi.label}</p>
              <p className="text-2xl font-semibold text-slate-800 mt-1">
                {kpi.value}
              </p>
              <span
                className={`text-xs font-medium ${
                  kpi.change.startsWith("+")
                    ? "text-emerald-600"
                    : kpi.change.startsWith("-")
                    ? "text-red-600"
                    : "text-slate-500"
                }`}
              >
                {kpi.change} sedan föregående period
              </span>
            </div>
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center ${kpi.color}`}
            >
              <kpi.icon className="w-5 h-5" />
            </div>
          </div>
        ))}
      </div>

      {/* Graphs Section */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="bg-white border rounded-2xl p-6 shadow-sm">
          <h2 className="font-semibold text-slate-800 mb-3">
            Fakturavolym (senaste veckan)
          </h2>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={activityData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip />
              <Line
                type="monotone"
                dataKey="invoices"
                stroke="#10b981"
                strokeWidth={2}
                dot={{ r: 3 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white border rounded-2xl p-6 shadow-sm">
          <h2 className="font-semibold text-slate-800 mb-3">
            Flaggade vs Godkända fakturor (6 mån)
          </h2>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={fraudData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip />
              <Bar dataKey="cleared" fill="#10b981" name="Godkända" />
              <Bar dataKey="flagged" fill="#ef4444" name="Flaggade" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* AI & Insights */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="bg-white border rounded-2xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-slate-800">AI & Rule Insights</h2>
            <ArrowTrendingUpIcon className="w-5 h-5 text-emerald-600" />
          </div>
          <ul className="text-sm text-slate-600 space-y-2">
            <li>🤖 Vanligaste flaggningsorsak: <b>Dublettfaktura</b></li>
            <li>💡 Senast tränad AI-modell: <b>3 timmar sedan</b></li>
            <li>⚙️ Mest aktiva regel: <b>IBAN mismatch</b></li>
            <li>📊 AI bedömningsprecision: <b>94.2%</b></li>
          </ul>
          <button className="mt-4 px-4 py-2 text-sm bg-emerald-50 text-emerald-700 rounded-lg hover:bg-emerald-100 transition">
            Se AI-analys i detalj
          </button>
        </div>

        {/* Alerts */}
        <div className="bg-white border rounded-2xl shadow-sm p-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-slate-800">Aktuella händelser</h2>
            <BellAlertIcon className="w-5 h-5 text-orange-500" />
          </div>
          <ul className="text-sm text-slate-600 space-y-2">
            <li>🔔 Ny byrå <b>EkonomiPartner AB</b> ansluten</li>
            <li>🚨 Regel <b>VAT mismatch</b> triggad 7 gånger idag</li>
            <li>🧩 AI retraining lyckades utan fel</li>
            <li>📥 182 nya fakturor importerade senaste timmen</li>
          </ul>
          <button className="mt-4 px-4 py-2 text-sm bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition">
            Visa hela loggen
          </button>
        </div>
      </div>
    </div>
  );
}
      {/* AI Summary Panel */}
      <div className="bg-gradient-to-br from-emerald-50 to-white border rounded-2xl shadow-sm p-6 mt-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-slate-800 flex items-center gap-2">
            <CpuChipIcon className="w-5 h-5 text-emerald-600" />
            Valiflow AI-sammanfattning
          </h2>
          <span className="text-xs text-slate-500">
            Uppdaterad {new Date().toLocaleTimeString("sv-SE", { hour: "2-digit", minute: "2-digit" })}
          </span>
        </div>

        <p className="text-slate-700 leading-relaxed text-sm">
          Systemet körs stabilt med en genomsnittlig upptid på{" "}
          <b>99.98 %</b>. AI-modellen identifierar främst{" "}
          <b>dublettfakturor</b> och <b>IBAN-fel</b> den senaste timmen.
          Flaggningar ligger på en normal nivå (<b>121</b> fall totalt) och
          precisionen är hög (<b>94.2 %</b>). Inga större driftavvikelser
          har rapporterats, och nya byråer fortsätter att tillkomma i
          stadig takt. Rekommenderad åtgärd:{" "}
          <b>fortsätt övervaka regel #3 (IBAN mismatch)</b> eftersom den
          triggas ovanligt ofta.
        </p>

        <div className="mt-4 flex gap-3">
          <button className="px-4 py-2 bg-emerald-600 text-white text-sm rounded-lg hover:bg-emerald-700 transition">
            Se full AI-rapport
          </button>
          <button className="px-4 py-2 bg-gray-100 text-slate-700 text-sm rounded-lg hover:bg-gray-200 transition">
            Uppdatera sammanfattning
          </button>
        </div>
      </div>
