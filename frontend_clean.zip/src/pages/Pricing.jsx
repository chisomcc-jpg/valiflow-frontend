import React, { useState } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, XCircle, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function PricingPage() {
  const [billingCycle, setBillingCycle] = useState("monthly");

  const plans = [
    { name: "Basic", monthly: 1500, yearly: 1050, desc: "För mindre företag" },
    {
      name: "Pro",
      monthly: 3700,
      yearly: 2590,
      desc: "För växande team",
      highlight: true,
    },
    { name: "Enterprise", monthly: null, yearly: null, desc: "För större organisationer" },
  ];

  const features = [
    ["Antal fakturor / månad", "Upp till 300", "Upp till 1 000", "Obegränsat"],
    ["Egen fakturamail", "✅", "✅", "✅"],
    ["Automatisk fakturaskanning & validering", "✅", "✅", "✅"],
    ["AI-bedrägerikontroll", "✅ (grund)", "✅ (avancerad)", "✅ (anpassad)"],
    ["Rapportering & dashboard", "Standard", "Anpassningsbar", "Skräddarsydd"],
    ["ERP-integration (Fortnox, Visma m.fl.)", "❌", "✅", "✅ (special)"],
    ["Antal användare", "1", "Upp till 5", "Obegränsat"],
    ["Anpassade integrationer (API, CRM)", "❌", "❌", "✅"],
    ["Säkerhets- & compliance-anpassning", "❌", "❌", "✅"],
    ["Beta-funktioner & API-prioritet", "❌", "❌", "✅"],
    ["Support", "E-post", "Prioriterad", "Dedikerad kontaktperson"],
    ["Onboarding / Utbildning", "❌", "Delvis", "✅ Fullständig"],
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 via-emerald-50 to-white text-slate-900">
      {/* ===== Header ===== */}
      <motion.header
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center py-24 relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-tr from-blue-100 via-emerald-100 to-cyan-100" />
        <div className="relative z-10 max-w-3xl mx-auto px-6">
          <h1 className="text-5xl font-bold mb-4">Valiflow – Priser</h1>
          <p className="text-lg text-slate-600 mb-8">
            Flexibel prissättning för företag i alla storlekar.
          </p>

          {/* Toggle */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <div className="inline-flex items-center bg-white border border-slate-200 rounded-full shadow-sm overflow-hidden">
              <button
                onClick={() => setBillingCycle("monthly")}
                className={`px-5 py-2 text-sm font-medium transition ${
                  billingCycle === "monthly"
                    ? "bg-gradient-to-r from-blue-600 to-emerald-400 text-white"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                Månadsvis
              </button>
              <button
                onClick={() => setBillingCycle("yearly")}
                className={`px-5 py-2 text-sm font-medium transition ${
                  billingCycle === "yearly"
                    ? "bg-gradient-to-r from-blue-600 to-emerald-400 text-white"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                Årsvis (-30 %)
              </button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* ===== Plan Cards (aligned perfectly under toggle) ===== */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="relative z-20 -mt-20 pb-16"
      >
        <div className="max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-3 gap-6 px-6 justify-center">
          {plans.map((plan, idx) => (
            <div
              key={idx}
              className={`relative rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm transition-all duration-300 hover:shadow-lg ${
                plan.highlight
                  ? "bg-gradient-to-r from-blue-600 to-emerald-400 text-white scale-105 shadow-xl"
                  : "bg-white"
              }`}
            >
              {plan.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-xs px-4 py-1 rounded-full shadow-md z-20">
                  Mest populär
                </div>
              )}
              <h3
                className={`text-xl font-semibold ${
                  plan.highlight ? "text-white" : "text-slate-800"
                }`}
              >
                {plan.name}
              </h3>
              <p
                className={`text-4xl font-bold my-3 ${
                  plan.highlight ? "text-white" : "text-slate-900"
                }`}
              >
                {plan.monthly
                  ? `${billingCycle === "monthly" ? plan.monthly : plan.yearly} kr`
                  : "Offert"}
              </p>
              <p
                className={`text-sm mb-6 ${
                  plan.highlight ? "text-white/90" : "text-slate-500"
                }`}
              >
                {plan.desc}
              </p>
              <Link
                to="/signup"
                className={`inline-flex items-center justify-center w-full py-2 rounded-lg font-semibold transition ${
                  plan.highlight
                    ? "bg-white text-blue-600 hover:opacity-90"
                    : "border border-slate-300 hover:bg-slate-50 text-slate-700"
                }`}
              >
                Kom igång
                <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            </div>
          ))}
        </div>
      </motion.section>

      {/* ===== Feature Comparison Table ===== */}
      <motion.section
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="relative z-10 max-w-6xl mx-auto px-4 pb-24"
      >
        <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-md">
          <div className="min-w-[900px] grid grid-cols-4 text-center">
            <div className="py-6 px-6 text-left font-semibold text-slate-700 border-b border-slate-200 bg-slate-50 text-lg">
              Funktion / Förmån
            </div>

            {plans.map((plan, idx) => (
              <div
                key={idx}
                className={`py-6 px-4 border-b border-slate-200 font-semibold text-lg ${
                  plan.highlight ? "text-blue-600" : "text-slate-700"
                }`}
              >
                {plan.name}
              </div>
            ))}

            {features.map(([label, ...vals], i) => (
              <React.Fragment key={i}>
                <div className="py-4 px-6 text-left text-sm font-medium text-slate-800 border-b border-slate-100 bg-white">
                  {label}
                </div>
                {vals.map((v, j) => (
                  <div
                    key={j}
                    className="py-4 border-b border-slate-100 flex items-center justify-center"
                  >
                    {v.includes("✅") ? (
                      <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                    ) : v.includes("❌") ? (
                      <XCircle className="h-5 w-5 text-slate-300" />
                    ) : (
                      <span className="text-slate-700 text-sm">{v}</span>
                    )}
                  </div>
                ))}
              </React.Fragment>
            ))}
          </div>
        </div>
      </motion.section>

      {/* ===== CTA Section ===== */}
      <motion.section
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="text-center py-20 bg-gradient-to-b from-blue-50 to-emerald-50"
      >
        <h2 className="text-3xl font-bold mb-4">
          Börja automatisera dina fakturor med Valiflow idag
        </h2>
        <p className="text-slate-600 mb-8">
          Testa gratis i 14 dagar – ingen bindningstid.
        </p>
        <Link
          to="/signup"
          className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-blue-600 to-emerald-400 text-white font-semibold px-8 py-3 shadow-md hover:shadow-lg hover:opacity-95 transition"
        >
          Kom igång gratis
          <ArrowRight className="h-5 w-5" />
        </Link>
      </motion.section>
    </div>
  );
}

