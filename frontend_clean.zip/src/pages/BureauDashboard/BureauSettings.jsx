import React, { useState } from "react";
import {
  BuildingOfficeIcon,
  UserGroupIcon,
  ShieldCheckIcon,
  Cog6ToothIcon,
  CreditCardIcon,
  PlusIcon,
  ArrowPathIcon,
  LinkIcon,
  SparklesIcon,
  AdjustmentsHorizontalIcon,
  ScaleIcon,
} from "@heroicons/react/24/outline";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { motion, AnimatePresence } from "framer-motion";

export default function BureauSettings() {
  const [tab, setTab] = useState("general");

  const tabs = [
    { id: "general", name: "Allmänt", icon: BuildingOfficeIcon },
    { id: "clients", name: "Klienthantering", icon: ScaleIcon },
    { id: "automation", name: "Automatisering", icon: AdjustmentsHorizontalIcon },
    { id: "team", name: "Team & Roller", icon: UserGroupIcon },
    { id: "integrations", name: "Integrationer", icon: LinkIcon },
    { id: "policy", name: "Policy & Säkerhet", icon: ShieldCheckIcon },
    { id: "billing", name: "Plan & Fakturering", icon: CreditCardIcon },
    { id: "ai", name: "AI & Insights", icon: SparklesIcon },
  ];

  const [notifications, setNotifications] = useState({
    riskAlerts: true,
    newInvoice: false,
    weeklySummary: true,
  });

  const [integrations, setIntegrations] = useState([
    { name: "Fortnox", status: "Ansluten", color: "text-emerald-600" },
    { name: "Visma", status: "Ej ansluten", color: "text-slate-400" },
    { name: "Microsoft 365", status: "Ansluten", color: "text-emerald-600" },
  ]);

  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 via-white to-slate-100 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-2">
            <Cog6ToothIcon className="w-7 h-7 text-emerald-600" />
            Byråinställningar
          </h1>
          <p className="text-slate-500 mt-1 text-sm">
            Hantera byråns information, klienter, automation, team, policy och mer.
          </p>
        </div>
        <Button className="bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-2">
          <ArrowPathIcon className="w-5 h-5" />
          Spara ändringar
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-4 border-b border-slate-200 mb-8 sticky top-0 bg-gradient-to-br from-slate-50 via-white to-slate-100 z-10">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`pb-3 flex items-center gap-2 font-medium text-sm transition-all ${
              tab === t.id
                ? "text-emerald-600 border-b-2 border-emerald-600"
                : "text-slate-500 hover:text-slate-700"
            }`}
          >
            <t.icon className="w-4 h-4" />
            {t.name}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.25 }}
        >
          {/* 🏢 Allmänt */}
          {tab === "general" && (
            <Card className="border border-slate-200 bg-white shadow-sm p-6 space-y-6">
              <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                <BuildingOfficeIcon className="w-5 h-5 text-emerald-600" />
                Byråinformation & Identitet
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="text-sm text-slate-600">Byrånamn</label>
                  <input
                    type="text"
                    placeholder="Valiflow Redovisning AB"
                    className="w-full mt-1 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-600">Organisationsnummer</label>
                  <input
                    type="text"
                    placeholder="556000-0000"
                    className="w-full mt-1 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-600">Kontakt-Epost</label>
                  <input
                    type="email"
                    placeholder="info@valiflow.se"
                    className="w-full mt-1 border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-600">Branding-färg</label>
                  <input
                    type="color"
                    defaultValue="#059669"
                    className="w-full mt-1 h-10 rounded-lg cursor-pointer border border-slate-200"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100">
                <h3 className="text-sm font-medium text-slate-700 mb-2">API-nycklar</h3>
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    placeholder="•••••••••••••••••••"
                    className="border border-slate-200 rounded-lg px-3 py-2 text-sm w-1/2 focus:ring-emerald-500 focus:border-emerald-500"
                  />
                  <Button variant="outline" size="sm">
                    Visa / Kopiera
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {/* 🧾 Klienthantering */}
          {tab === "clients" && (
            <Card className="border border-slate-200 bg-white shadow-sm p-6">
              <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <ScaleIcon className="w-5 h-5 text-emerald-600" />
                Klienthantering & Roller
              </h2>
              <div className="flex justify-between items-center mb-4">
                <p className="text-sm text-slate-500">
                  Hantera kundbolag, kopplingar och status.
                </p>
                <div className="flex gap-2">
                  <Button size="sm" className="bg-emerald-600 text-white flex items-center gap-1">
                    <PlusIcon className="w-4 h-4" /> Lägg till klient
                  </Button>
                  <Button variant="outline" size="sm">
                    Bjud in klient
                  </Button>
                </div>
              </div>

              <div className="border rounded-lg divide-y divide-slate-100">
                {[
                  { name: "Nordic Consulting AB", status: "Aktiv", risk: "Låg" },
                  { name: "FinSolve AB", status: "Inaktiv", risk: "Hög" },
                ].map((client, i) => (
                  <div
                    key={i}
                    className="flex justify-between items-center p-3 hover:bg-slate-50 transition-all"
                  >
                    <div>
                      <p className="font-medium text-slate-800">{client.name}</p>
                      <p className="text-xs text-slate-500">
                        Status: {client.status} • Risknivå: {client.risk}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm" className="text-emerald-600">
                      Visa
                    </Button>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* ⚙️ Automatisering */}
          {tab === "automation" && (
            <Card className="border border-slate-200 bg-white shadow-sm p-6 space-y-5">
              <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                <AdjustmentsHorizontalIcon className="w-5 h-5 text-emerald-600" />
                Automatisering & Workflow
              </h2>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-700">Autoscan var 6:e timme</span>
                  <Switch defaultChecked />
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-700">AI Risk Review aktiverad</span>
                  <Switch defaultChecked />
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-700">
                    Skicka notifiering vid risk över 0.8
                  </span>
                  <Switch />
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-700">
                    Synka fakturor automatiskt från klienter
                  </span>
                  <Switch />
                </div>
              </div>
            </Card>
          )}

          {/* 👥 Team & Roller */}
          {tab === "team" && (
            <Card className="border border-slate-200 bg-white shadow-sm p-6">
              <h2 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                <UserGroupIcon className="w-5 h-5 text-emerald-600" />
                Team & Åtkomst
              </h2>
              <div className="flex justify-between items-center mb-3">
                <p className="text-sm text-slate-500">Hantera användare och roller.</p>
                <Button size="sm" className="bg-emerald-600 text-white flex items-center gap-1">
                  <PlusIcon className="w-4 h-4" /> Bjud in medlem
                </Button>
              </div>

              <div className="border rounded-lg divide-y divide-slate-100">
                {[
                  { name: "Anna Karlsson", role: "Byråadmin", email: "anna@byra.se" },
                  { name: "Jonas Berg", role: "Analytiker", email: "jonas@byra.se" },
                ].map((user, i) => (
                  <div
                    key={i}
                    className="flex justify-between items-center p-3 hover:bg-slate-50 transition-all"
                  >
                    <div>
                      <p className="font-medium text-slate-800">{user.name}</p>
                      <p className="text-xs text-slate-500">{user.email}</p>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-medium">
                      {user.role}
                    </span>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* 🔗 Integrationer */}
          {tab === "integrations" && (
            <Card className="border border-slate-200 bg-white shadow-sm p-6">
              <h2 className="text-lg font-semibold text-slate-800 mb-6 flex items-center gap-2">
                <LinkIcon className="w-5 h-5 text-emerald-600" />
                Integrationer
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {integrations.map((app, i) => (
                  <motion.div
                    key={i}
                    whileHover={{ scale: 1.02 }}
                    className="p-4 border border-slate-200 rounded-xl shadow-sm hover:shadow-md transition-all"
                  >
                    <h3 className="font-medium text-slate-800 mb-1">{app.name}</h3>
                    <p className={`${app.color} text-sm mb-3`}>{app.status}</p>
                    <Button
                      size="sm"
                      variant={app.status === "Ansluten" ? "outline" : "default"}
                      className={
                        app.status === "Ansluten"
                          ? "text-slate-600 border-slate-200"
                          : "bg-emerald-600 text-white hover:bg-emerald-700"
                      }
                    >
                      {app.status === "Ansluten" ? "Koppla bort" : "Koppla"}
                    </Button>
                  </motion.div>
                ))}
              </div>
            </Card>
          )}

          {/* 📜 Policy & Säkerhet */}
          {tab === "policy" && (
            <Card className="border border-slate-200 bg-white shadow-sm p-6 space-y-5">
              <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                <ShieldCheckIcon className="w-5 h-5 text-emerald-600" />
                Policy & Datasäkerhet
              </h2>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-700">
                    Klientautentisering krävs för åtkomst
                  </span>
                  <Switch defaultChecked />
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-700">
                    Spara fakturadata i 5 år (GDPR)
                  </span>
                  <Switch defaultChecked />
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-700">
                    Tillåt export av kunddata (ZIP)
                  </span>
                  <Switch />
                </div>
              </div>
            </Card>
          )}

          {/* 💳 Plan & Fakturering */}
          {tab === "billing" && (
            <Card className="border border-slate-200 bg-white shadow-sm p-6 flex justify-between items-center">
              <div>
                <h2 className="text-lg font-semibold text-slate-800 mb-1 flex items-center gap-2">
                  <CreditCardIcon className="w-5 h-5 text-emerald-600" />
                  Plan & Fakturering
                </h2>
                <p className="text-slate-500 text-sm">
                  Plan: <span className="font-medium text-slate-700">Byrå Pro</span> • 2490 kr/mån
                </p>
                <p className="text-slate-500 text-sm">Nästa fakturering: 25 oktober 2025</p>
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="text-slate-600 border-slate-200 hover:bg-slate-50">
                  Visa fakturor
                </Button>
                <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
                  Uppgradera plan
                </Button>
              </div>
            </Card>
          )}

          {/* 🤖 AI & Insights */}
          {tab === "ai" && (
            <Card className="border border-slate-200 bg-white shadow-sm p-6 space-y-5">
              <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                <SparklesIcon className="w-5 h-5 text-emerald-600" />
                AI & Insights
              </h2>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-700">Aktivera AI-sammanfattningar</span>
                  <Switch defaultChecked />
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-700">Flagga fakturor med risk > 0.7</span>
                  <Switch defaultChecked />
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-700">
                    Smart Auto-Approval för fakturor &lt; 5000 kr
                  </span>
                  <Switch />
                </div>
              </div>
            </Card>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
