export async function fetchAuditLogs(filters: Record<string, string> = {}) {
  const params = new URLSearchParams(filters).toString();
  const res = await fetch(`${import.meta.env.VITE_API_URL}/audit-logs?${params}`, {
    headers: {
      Authorization: `Bearer ${localStorage.getItem("token")}`,
    },
  });

  if (!res.ok) {
    throw new Error("Failed to fetch audit logs");
  }

  return res.json();
}
