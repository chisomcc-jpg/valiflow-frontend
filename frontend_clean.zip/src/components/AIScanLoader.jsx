import { motion } from "framer-motion";

export default function AIScanLoader() {
  return (
    <div className="flex flex-col items-center justify-center py-10 text-slate-600">
      <motion.div
        className="w-16 h-16 rounded-full border-4 border-green-500 border-t-transparent"
        animate={{ rotate: 360 }}
        transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
      />
      <motion.p
        className="mt-4 text-sm text-slate-500"
        animate={{ opacity: [0.4, 1, 0.4] }}
        transition={{ repeat: Infinity, duration: 2 }}
      >
        🔍 AI analyserar fakturan...
      </motion.p>
    </div>
  );
}
