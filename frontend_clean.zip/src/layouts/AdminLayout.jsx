import React, { useState } from "react";
import {
  HomeIcon,
  BuildingOfficeIcon,
  DocumentTextIcon,
  ShieldExclamationIcon,
  AdjustmentsHorizontalIcon,
  Cog6ToothIcon,
  UsersIcon,
  MagnifyingGlassCircleIcon,
  Squares2X2Icon,
  ServerStackIcon,
} from "@heroicons/react/24/outline";
import { NavLink, Outlet, useLocation, Link } from "react-router-dom";

export default function AdminLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: "Översikt", to: "/admin", icon: HomeIcon },
    { name: "Byråer", to: "/admin/firms", icon: BuildingOfficeIcon },
    { name: "Företag & Kunder", to: "/admin/clients", icon: UsersIcon },
    { name: "Fakturor", to: "/admin/invoices", icon: DocumentTextIcon },
    { name: "Fraud & AI", to: "/admin/fraud", icon: ShieldExclamationIcon },
    { name: "Rule Engine", to: "/admin/rules", icon: AdjustmentsHorizontalIcon },
    { name: "Användare", to: "/admin/users", icon: MagnifyingGlassCircleIcon },
    { name: "Audit Log", to: "/admin/logs", icon: ServerStackIcon },
    { name: "Inställningar", to: "/admin/settings", icon: Cog6ToothIcon },
  ];

  // 🧭 Sidtitlar för topbaren
  const pageTitles = {
    "/admin": "Systemöversikt",
    "/admin/firms": "Byråer",
    "/admin/clients": "Företag & Kunder",
    "/admin/invoices": "Fakturor",
    "/admin/fraud": "Fraud & AI",
    "/admin/rules": "Rule Engine",
    "/admin/users": "Användare",
    "/admin/logs": "Audit Logg",
    "/admin/settings": "Inställningar",
  };

  const currentPath = location.pathname;
  const pageTitle = pageTitles[currentPath] || "Adminpanel";

  // 🧩 Breadcrumbs
  const crumbs = currentPath.split("/").filter(Boolean); // ex: ["admin", "fraud"]

  return (
    <div className="flex min-h-screen bg-gray-50 text-slate-700">
      {/* Sidebar */}
      <aside
        className={`${
          collapsed ? "w-20" : "w-64"
        } bg-white border-r shadow-sm transition-all duration-300 flex flex-col`}
      >
        <div className="flex items-center justify-between p-4 border-b">
          <h1 className="font-bold text-lg text-slate-800">Valiflow Admin</h1>
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="text-gray-500 hover:text-gray-700"
          >
            <Squares2X2Icon className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 p-3 space-y-1">
          {navLinks.map((link) => (
            <NavLink
              key={link.name}
              to={link.to}
              end
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-emerald-100 text-emerald-700"
                    : "hover:bg-gray-100 text-slate-600"
                }`
              }
            >
              <link.icon className="w-5 h-5" />
              {!collapsed && link.name}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 border-t text-xs text-gray-400">
          v1.0.0 • Valiflow
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col">
        {/* Topbar with dynamic title & breadcrumbs */}
        <header className="h-16 bg-white border-b flex items-center justify-between px-6">
          <div>
            <h2 className="font-semibold text-slate-800 text-lg">
              {pageTitle}
            </h2>
            <nav className="text-xs text-gray-500 mt-1">
              {crumbs.map((crumb, i) => {
                const path = `/${crumbs.slice(0, i + 1).join("/")}`;
                const isLast = i === crumbs.length - 1;
                return (
                  <span key={i}>
                    {i > 0 && " / "}
                    {isLast ? (
                      <span className="font-medium text-gray-700">
                        {crumb.charAt(0).toUpperCase() + crumb.slice(1)}
                      </span>
                    ) : (
                      <Link
                        to={path}
                        className="hover:underline text-gray-500"
                      >
                        {crumb.charAt(0).toUpperCase() + crumb.slice(1)}
                      </Link>
                    )}
                  </span>
                );
              })}
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-600">Superadmin</span>
            <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold">
              VA
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
