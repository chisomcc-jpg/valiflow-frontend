// src/components/TopNavbar.jsx
import { BellIcon, MagnifyingGlassIcon } from "@heroicons/react/24/outline";

export default function TopNavbar() {
  return (
    <header className="flex items-center justify-between bg-white h-16 px-6 shadow-md border-b border-gray-200">
      {/* Left side: Page title */}
      <div className="flex items-center space-x-4">
        <h1 className="text-xl font-semibold text-gray-800">Dashboard</h1>
        {/* Optional search bar */}
        <div className="relative">
          <input
            type="text"
            placeholder="Search..."
            className="pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
          />
          <MagnifyingGlassIcon className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
      </div>

      {/* Right side: Notifications + User */}
      <div className="flex items-center space-x-4">
        <button className="relative p-2 rounded-full hover:bg-gray-100 transition-colors">
          <BellIcon className="h-6 w-6 text-gray-600" />
          {/* Notification badge */}
          <span className="absolute top-0 right-0 inline-flex h-2 w-2 rounded-full bg-red-500" />
        </button>

        <div className="flex items-center space-x-2 cursor-pointer">
          <img
            src="https://via.placeholder.com/32"
            alt="User Avatar"
            className="h-8 w-8 rounded-full"
          />
          <span className="text-gray-700 font-medium text-sm">John Doe</span>
        </div>
      </div>
    </header>
  );
}

