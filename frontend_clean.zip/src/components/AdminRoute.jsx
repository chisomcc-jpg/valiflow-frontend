// ⚠️ Temporärt under utveckling
export default function AdminRoute({ children }) {
  return children;
}
