import React from "react";
import { ShieldCheck, Cpu, MailCheck, BarChart3, Zap, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function Product() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white dark:from-slate-950 dark:to-slate-900 text-slate-900 dark:text-white">
      {/* HEADER */}
      <header className="relative overflow-hidden text-center py-24">
        <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/10 via-cyan-400/10 to-indigo-500/10" />
        <div className="relative mx-auto max-w-5xl px-6">
          <h1 className="text-4xl font-bold sm:text-5xl lg:text-6xl mb-4">
            Kraftfulla funktioner för en tryggare fakturahantering
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
            Valiflow kombinerar AI, automatik och svensk regelefterlevnad för att skydda ditt företag mot fakturabedrägerier – utan att ändra ditt arbetssätt.
          </p>
        </div>
      </header>

      {/* FEATURE PILLARS */}
      <section className="max-w-6xl mx-auto px-6 py-20 grid gap-12 md:grid-cols-3 text-center">
        <FeatureCard
          icon={<ShieldCheck className="h-10 w-10 mx-auto mb-4" />}
          title="Automatisk bedrägeri­detektering"
          desc="Identifierar ovanliga belopp, okända konton och ologiska betalningsmönster i realtid innan fakturan godkänns."
        />
        <FeatureCard
          icon={<MailCheck className="h-10 w-10 mx-auto mb-4" />}
          title="E-post till faktura-hygien"
          desc="Analyserar inkommande e-post, kontrollerar avsändaridentitet och varnar för spoofade eller manipulerade bilagor."
        />
        <FeatureCard
          icon={<Cpu className="h-10 w-10 mx-auto mb-4" />}
          title="Sömlös integration"
          desc="Koppla Fortnox, Visma, Xero eller egna API-flöden. Ingen manuell export – allt sker automatiskt i bakgrunden."
        />
      </section>

      {/* HOW IT WORKS */}
      <section className="bg-slate-100 dark:bg-slate-900 py-24">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-3xl font-semibold text-center mb-12">Hur Valiflow fungerar</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Step
              icon={<Zap className="h-8 w-8 text-emerald-600 dark:text-emerald-400" />}
              title="1. Ta emot fakturan"
              text="Fakturor tas emot via e-post eller API och analyseras automatiskt utan att du behöver ladda upp filer manuellt."
            />
            <Step
              icon={<BarChart3 className="h-8 w-8 text-emerald-600 dark:text-emerald-400" />}
              title="2. AI-riskanalys"
              text="Systemet jämför mot historiska mönster, kontrollerar leverantörer och flaggar misstänkta fakturor i realtid."
            />
            <Step
              icon={<ShieldCheck className="h-8 w-8 text-emerald-600 dark:text-emerald-400" />}
              title="3. Beslutsstöd & godkännande"
              text="Ekonomiteamet ser tydliga riskindikatorer innan fakturan bokförs – snabbt, enkelt och tryggt."
            />
          </div>
        </div>
      </section>

      {/* WHY VALIFLOW ADVANTAGES */}
      <section className="max-w-6xl mx-auto px-6 py-24">
        <h2 className="text-3xl font-semibold text-center mb-12">Varför Valiflow?</h2>
        <ul className="grid md:grid-cols-2 gap-6 text-left max-w-3xl mx-auto">
          <Advantage text="Byggt för svenska ekonomiprocesser och GDPR från grunden." />
          <Advantage text="Ingen systemmigration – Valiflow fungerar ovanpå dina befintliga verktyg." />
          <Advantage text="AI-driven analys med mänsklig kontroll för maximal säkerhet." />
          <Advantage text="Full transparens – varje fakturakontroll är spårbar och granskningsbar." />
          <Advantage text="Integrerat med Fortnox, Visma och andra nordiska system." />
          <Advantage text="Molnbaserad lösning – ingen installation, uppdateras automatiskt." />
        </ul>
      </section>

      {/* CTA SECTION */}
      <section className="relative py-20 bg-gradient-to-tr from-emerald-600 to-cyan-600 text-center text-white">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.1)_1px,transparent_0)] [background-size:16px_16px]" />
        <div className="relative z-10 mx-auto max-w-4xl">
          <h3 className="text-3xl font-semibold mb-4">Prova Valiflow gratis</h3>
          <p className="text-white/90 mb-8 text-lg">
            Kom igång på några minuter – ingen installation, inga kreditkort, ingen bindningstid.
          </p>
          <Link
            to="/login"
            className="inline-flex items-center gap-2 rounded-xl bg-white text-emerald-700 font-medium px-8 py-4 text-lg shadow-lg hover:bg-slate-100 transition"
          >
            Skapa gratis konto
            <ArrowRight className="h-6 w-6" />
          </Link>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-10 text-center text-sm text-slate-500 dark:text-slate-400 border-t border-slate-200 dark:border-slate-800">
        <p>
          © {new Date().getFullYear()} Valiflow AB • Byggt i Sverige •{" "}
          <a href="#" className="underline underline-offset-4 hover:text-slate-700 dark:hover:text-slate-200">
            Integritetspolicy
          </a>
        </p>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, desc }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/70 p-6 shadow-md backdrop-blur-sm dark:border-slate-800 dark:bg-slate-900/60 transition hover:-translate-y-1 hover:shadow-lg">
      {icon}
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-sm text-slate-600 dark:text-slate-300">{desc}</p>
    </div>
  );
}

function Step({ icon, title, text }) {
  return (
    <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800">
      <div className="mb-4">{icon}</div>
      <h4 className="text-lg font-semibold mb-2">{title}</h4>
      <p className="text-sm text-slate-600 dark:text-slate-300">{text}</p>
    </div>
  );
}

function Advantage({ text }) {
  return (
    <li className="flex items-start gap-3 text-slate-700 dark:text-slate-300">
      <span className="mt-1 h-3 w-3 rounded-full bg-emerald-500 flex-shrink-0" />
      <span>{text}</span>
    </li>
  );
}
