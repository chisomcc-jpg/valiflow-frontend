// src/components/DashboardTour.jsx
import React from "react";
import GuidedTooltip from "./GuidedTooltip";
import { useOnboardingTour } from "./useOnboardingTour";

/**
 * 🧭 DashboardTour
 * Displays the guided onboarding tooltips for first-time users.
 */
export default function DashboardTour() {
  const { steps, currentStep, nextStep, isActive } = useOnboardingTour();

  if (!isActive) return null;

  const step = steps[currentStep];

  return (
    <GuidedTooltip
      key={step.id}
      targetId={step.targetId}
      title={step.title}
      description={step.description}
      position={step.position}
      onNext={nextStep}
      isLastStep={currentStep === steps.length - 1}
    />
  );
}
