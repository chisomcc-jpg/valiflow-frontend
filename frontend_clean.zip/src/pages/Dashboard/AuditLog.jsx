import React, { useEffect, useState } from "react";
import {
  MagnifyingGlassIcon,
  ArrowDownTrayIcon,
  FunnelIcon,
  EyeIcon,
  XMarkIcon,
  ChartBarIcon,
  CheckCircleIcon,
  CpuChipIcon,
  UserIcon,
} from "@heroicons/react/24/outline";
import { format } from "date-fns";
import { toast } from "sonner";
import { fetchAuditLogs } from "@/services/auditService";

export default function AuditLog() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState(null);
  const [filters, setFilters] = useState({
    query: "",
    from: "",
    to: "",
  });
  const [aiStats, setAiStats] = useState({
    decisions: 4392,
    accuracy: 95.3,
    autoApproved: 73,
    manualReviewed: 27,
  });

  useEffect(() => {
    loadLogs();
  }, []);

  async function loadLogs() {
    setLoading(true);
    try {
      const data = await fetchAuditLogs();
      setLogs(data);
      setAiStats({
        decisions: 4392,
        accuracy: 95.3,
        autoApproved: 73,
        manualReviewed: 27,
      });
    } catch (error) {
      console.error(error);
      toast.error("Kunde inte ladda granskningsloggar.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 via-white to-slate-100 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold text-slate-800">
            🧾 Granskningslogg
          </h1>
          <p className="text-slate-500 text-sm">
            Full spårbarhet och transparens för alla händelser i Valiflow.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1 px-3 py-2 border rounded-lg text-sm bg-white hover:bg-slate-50 transition shadow-sm">
            <ArrowDownTrayIcon className="w-4 h-4" /> Exportera CSV
          </button>
          <button className="flex items-center gap-1 px-3 py-2 border rounded-lg text-sm bg-white hover:bg-slate-50 transition shadow-sm">
            <ArrowDownTrayIcon className="w-4 h-4" /> Exportera PDF
          </button>
        </div>
      </div>

      {/* 🧠 AI Transparency Section */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-xl border shadow-sm p-4 flex items-center gap-3">
          <CpuChipIcon className="w-8 h-8 text-blue-600" />
          <div>
            <p className="text-sm text-slate-500">AI-beslut (30 dagar)</p>
            <p className="text-xl font-semibold text-slate-800">
              {aiStats.decisions.toLocaleString()}
            </p>
          </div>
        </div>

        <div className="bg-white rounded-xl border shadow-sm p-4 flex items-center gap-3">
          <ChartBarIcon className="w-8 h-8 text-green-600" />
          <div>
            <p className="text-sm text-slate-500">Noggrannhet</p>
            <p className="text-xl font-semibold text-slate-800">
              {aiStats.accuracy}%
            </p>
          </div>
        </div>

        <div className="bg-white rounded-xl border shadow-sm p-4 flex items-center gap-3">
          <CheckCircleIcon className="w-8 h-8 text-emerald-600" />
          <div>
            <p className="text-sm text-slate-500">Auto-godkända</p>
            <p className="text-xl font-semibold text-slate-800">
              {aiStats.autoApproved}%
            </p>
          </div>
        </div>

        <div className="bg-white rounded-xl border shadow-sm p-4 flex items-center gap-3">
          <UserIcon className="w-8 h-8 text-amber-600" />
          <div>
            <p className="text-sm text-slate-500">Manuellt granskade</p>
            <p className="text-xl font-semibold text-slate-800">
              {aiStats.manualReviewed}%
            </p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-5">
        <div className="relative">
          <MagnifyingGlassIcon className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Sök kund, faktura eller kommentar..."
            value={filters.query}
            onChange={(e) =>
              setFilters((prev) => ({ ...prev, query: e.target.value }))
            }
            className="pl-8 pr-3 py-2 border rounded-lg text-sm w-72 bg-white focus:ring-1 focus:ring-blue-500 outline-none shadow-sm"
          />
        </div>

        <input
          type="date"
          className="border rounded-lg text-sm px-2 py-2 shadow-sm bg-white"
          value={filters.from}
          onChange={(e) =>
            setFilters((prev) => ({ ...prev, from: e.target.value }))
          }
        />
        <input
          type="date"
          className="border rounded-lg text-sm px-2 py-2 shadow-sm bg-white"
          value={filters.to}
          onChange={(e) =>
            setFilters((prev) => ({ ...prev, to: e.target.value }))
          }
        />
        <button
          onClick={loadLogs}
          className="flex items-center gap-1 px-3 py-2 border rounded-lg text-sm bg-slate-100 hover:bg-slate-200 transition shadow-sm"
        >
          <FunnelIcon className="w-4 h-4" /> Filtrera
        </button>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-md border overflow-hidden">
        <table className="min-w-full text-sm">
          <thead className="bg-slate-100 text-slate-600 text-left">
            <tr>
              <th className="p-3">Datum</th>
              <th className="p-3">Kund</th>
              <th className="p-3">Faktura-ID</th>
              <th className="p-3">Händelse</th>
              <th className="p-3">Användare</th>
              <th className="p-3">Kommentar</th>
              <th className="p-3 text-center">Visa</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td
                  colSpan={7}
                  className="text-center py-10 text-slate-400 italic"
                >
                  Laddar granskningsloggar...
                </td>
              </tr>
            ) : logs.length > 0 ? (
              logs.map((log) => (
                <tr
                  key={log.id}
                  className="border-t hover:bg-slate-50 cursor-pointer transition"
                >
                  <td className="p-3">
                    {format(new Date(log.timestamp), "yyyy-MM-dd HH:mm")}
                  </td>
                  <td className="p-3">{log.customer}</td>
                  <td className="p-3">{log.invoice_id}</td>
                  <td
                    className={`p-3 font-medium ${
                      log.event.includes("approved")
                        ? "text-green-600"
                        : log.event.includes("flagged")
                        ? "text-yellow-600"
                        : log.event.includes("synced")
                        ? "text-blue-600"
                        : "text-red-600"
                    }`}
                  >
                    {log.event.replaceAll("_", " ")}
                  </td>
                  <td className="p-3">{log.user}</td>
                  <td className="p-3 text-slate-500">{log.comment}</td>
                  <td className="text-center">
                    <button
                      onClick={() => setSelected(log)}
                      className="p-1 text-blue-600 hover:text-blue-800 transition"
                    >
                      <EyeIcon className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan={7}
                  className="text-center py-10 text-slate-400 italic"
                >
                  Inga händelser hittades för nuvarande filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {selected && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-[600px] max-h-[80vh] overflow-y-auto relative p-6">
            <button
              onClick={() => setSelected(null)}
              className="absolute top-3 right-3 text-slate-500 hover:text-slate-700"
            >
              <XMarkIcon className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-semibold mb-3 text-slate-800">
              Faktura #{selected.invoice_id}
            </h2>
            <p className="text-sm text-slate-500 mb-4">
              Kund:{" "}
              <span className="font-medium text-slate-700">
                {selected.customer}
              </span>
            </p>

            <div className="space-y-3">
              <div className="border-l-4 border-blue-500 pl-3">
                <p className="text-sm font-medium text-slate-800">
                  {format(new Date(selected.timestamp), "HH:mm")} –{" "}
                  {selected.event.replaceAll("_", " ")}
                </p>
                <p className="text-xs text-slate-500">
                  {selected.user} ({selected.system})
                </p>
                <p className="text-xs text-slate-400">{selected.comment}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
