import React, { useState, useMemo, useEffect, useCallback } from "react";
import {
  BuildingOfficeIcon,
  DocumentTextIcon,
  ShieldExclamationIcon,
  MagnifyingGlassIcon,
  ChartBarIcon,
  ArrowTrendingUpIcon,
} from "@heroicons/react/24/outline";
import { useNavigate } from "react-router-dom";

export default function Clients() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("Alla");
  const navigate = useNavigate();

  // KPI dummy data
  const kpis = [
    { label: "Totala företag", value: 312, icon: BuildingOfficeIcon, color: "bg-emerald-100 text-emerald-700" },
    { label: "Nya senaste månaden", value: 24, icon: ArrowTrendingUpIcon, color: "bg-blue-100 text-blue-700" },
    { label: "Under granskning", value: 5, icon: ShieldExclamationIcon, color: "bg-yellow-100 text-yellow-700" },
    { label: "Genomsnittligt riskindex", value: "3.4 / 10", icon: ChartBarIcon, color: "bg-cyan-100 text-cyan-700" },
  ];

  // Dummy data (företagslista)
  const clients = [
    { id: 1, name: "Nordic Trade AB", org: "556882-1122", bureau: "EkonomiPartner AB", invoices: 312, risk: 2.3, status: "Aktiv", lastActive: "2025-10-22" },
    { id: 2, name: "FinTechify AB", org: "559101-5555", bureau: "Balance Consulting", invoices: 155, risk: 7.8, status: "Under granskning", lastActive: "2025-10-21" },
    { id: 3, name: "Greenify Tech AB", org: "559551-1144", bureau: "Nordic Revision AB", invoices: 48, risk: 5.6, status: "Aktiv", lastActive: "2025-10-23" },
    { id: 4, name: "Logico Systems", org: "556778-3344", bureau: "FinVision AB", invoices: 203, risk: 1.8, status: "Aktiv", lastActive: "2025-10-24" },
    { id: 5, name: "Ardentica AB", org: "556123-0099", bureau: "EkonomiPartner AB", invoices: 87, risk: 3.2, status: "Inaktiv", lastActive: "2025-09-30" },
  ];

  const filteredClients = useMemo(() => {
    return clients.filter((c) => {
      const matchQuery =
        c.name.toLowerCase().includes(query.toLowerCase()) ||
        c.org.includes(query);
      const matchFilter = filter === "Alla" || c.status === filter;
      return matchQuery && matchFilter;
    });
  }, [query, filter]);

  const getRiskColor = (risk) => {
    if (risk >= 7) return "text-red-600 bg-red-50";
    if (risk >= 4) return "text-orange-600 bg-orange-50";
    return "text-emerald-600 bg-emerald-50";
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-slate-800">Företag & Kunder</h1>
          <p className="text-slate-500">Överblick över alla företagskonton som hanteras av byråer i Valiflow.</p>
        </div>

        {/* Filter + search */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <MagnifyingGlassIcon className="w-5 h-5 text-slate-400 absolute left-2 top-2.5" />
            <input
              type="text"
              placeholder="Sök företag..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-8 pr-3 py-2 border rounded-lg text-sm focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="border rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500"
          >
            <option>Alla</option>
            <option>Aktiv</option>
            <option>Under granskning</option>
            <option>Inaktiv</option>
          </select>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
        {kpis.map((kpi, i) => (
          <div key={i} className="bg-white border rounded-2xl shadow-sm p-5 flex items-center justify-between hover:shadow-md transition">
            <div>
              <p className="text-sm text-gray-500">{kpi.label}</p>
              <p className="text-2xl font-semibold text-slate-800 mt-1">{kpi.value}</p>
            </div>
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${kpi.color}`}>
              <kpi.icon className="w-5 h-5" />
            </div>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white border rounded-2xl shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b text-gray-600">
            <tr>
              <th className="text-left py-3 px-4">Företag</th>
              <th className="text-left py-3 px-4">Org.nr</th>
              <th className="text-left py-3 px-4">Byrå</th>
              <th className="text-left py-3 px-4">Fakturor</th>
              <th className="text-left py-3 px-4">Riskindex</th>
              <th className="text-left py-3 px-4">Status</th>
              <th className="text-left py-3 px-4">Senast aktiv</th>
              <th className="text-right py-3 px-4">Åtgärder</th>
            </tr>
          </thead>
          <tbody>
            {filteredClients.map((c) => (
              <tr key={c.id} className="border-b last:border-none hover:bg-gray-50 transition">
                <td className="py-3 px-4 font-medium text-slate-800">{c.name}</td>
                <td className="py-3 px-4">{c.org}</td>
                <td className="py-3 px-4 text-slate-600">{c.bureau}</td>
                <td className="py-3 px-4">{c.invoices}</td>
                <td className="py-3 px-4">
                  <span className={`px-2 py-1 rounded-lg text-xs font-medium ${getRiskColor(c.risk)}`}>
                    {c.risk.toFixed(1)}
                  </span>
                </td>
                <td className="py-3 px-4">
                  <span
                    className={`px-2 py-1 rounded-lg text-xs font-medium ${
                      c.status === "Aktiv"
                        ? "bg-emerald-50 text-emerald-700"
                        : c.status === "Under granskning"
                        ? "bg-yellow-50 text-yellow-700"
                        : "bg-gray-100 text-gray-500"
                    }`}
                  >
                    {c.status}
                  </span>
                </td>
                <td className="py-3 px-4 text-slate-600">{c.lastActive}</td>
                <td className="py-3 px-4 text-right">
                  <button
                    onClick={() => navigate(`/admin/clients/${c.id}`)}
                    className="text-emerald-600 hover:text-emerald-800 text-sm"
                  >
                    Visa
                  </button>
                </td>
              </tr>
            ))}
            {filteredClients.length === 0 && (
              <tr>
                <td colSpan={8} className="py-6 text-center text-gray-400 text-sm">
                  Inga företag matchar sökningen.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* AI Insights */}
      <div className="bg-gradient-to-br from-gray-50 to-white border rounded-2xl shadow-sm p-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-slate-800 flex items-center gap-2">
            <ArrowTrendingUpIcon className="w-5 h-5 text-emerald-600" />
            AI-observationer & insikter
          </h2>
          <span className="text-xs text-slate-500">
            Uppdaterad {new Date().toLocaleTimeString("sv-SE", { hour: "2-digit", minute: "2-digit" })}
          </span>
        </div>

        <ul className="text-sm text-slate-600 space-y-2">
          <li>🤖 4 företag har ökat risknivå senaste veckan.</li>
          <li>⚠️ 2 företag har dubblettfakturor med identiska IBAN.</li>
          <li>🏆 Mest aktivt företag: <b>Nordic Trade AB</b> (312 fakturor).</li>
          <li>🕵️ 5 företag under manuell granskning av AI-systemet.</li>
        </ul>

        <div className="mt-4 flex gap-3">
          <button className="px-4 py-2 bg-emerald-600 text-white text-sm rounded-lg hover:bg-emerald-700 transition">
            Se detaljanalys
          </button>
          <button className="px-4 py-2 bg-gray-100 text-slate-700 text-sm rounded-lg hover:bg-gray-200 transition">
            Uppdatera insikter
          </button>
        </div>
      </div>
    </div>
  );
}
