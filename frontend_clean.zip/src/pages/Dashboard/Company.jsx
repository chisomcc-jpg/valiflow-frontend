import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  BuildingOfficeIcon,
  UserGroupIcon,
  CurrencyDollarIcon,
  SwatchIcon,
} from "@heroicons/react/24/outline";

export default function Company() {
  const [activeTab, setActiveTab] = useState("profil");

  const tabs = [
    { id: "profil", label: "Företagsprofil", icon: BuildingOfficeIcon, color: "from-blue-600 to-cyan-500" },
    { id: "team", label: "Team & Åtkomst", icon: UserGroupIcon, color: "from-emerald-600 to-green-400" },
    { id: "finans", label: "Finansiella inställningar", icon: CurrencyDollarIcon, color: "from-amber-500 to-orange-400" },
  ];

  return (
    <div className="p-8 space-y-8 bg-gradient-to-b from-slate-50 to-white min-h-screen">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold text-slate-900">Företag</h1>
        <p className="text-slate-500 mt-1">
          Hantera företagsinformation, användare och finansiella inställningar.
        </p>
      </motion.div>

      {/* Tabs */}
      <motion.div
        initial={{ opacity: 0, y: 5 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="flex bg-white border border-slate-200 rounded-2xl shadow-lg p-1 backdrop-blur-sm"
      >
        {tabs.map(({ id, label, icon: Icon, color }) => {
          const active = activeTab === id;
          return (
            <motion.button
              key={id}
              onClick={() => setActiveTab(id)}
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.97 }}
              className={`relative flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                active
                  ? "text-white shadow-md"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              {active && (
                <motion.div
                  layoutId="activeGlow"
                  className={`absolute inset-0 rounded-xl bg-gradient-to-r ${color} shadow-lg`}
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
              <motion.div
                className="relative z-10 flex items-center gap-2"
                animate={{ y: active ? -2 : 0 }}
                transition={{ duration: 0.2 }}
              >
                <Icon className="w-5 h-5" />
                <span>{label}</span>
              </motion.div>
            </motion.button>
          );
        })}
      </motion.div>

      {/* Content */}
      <div className="relative mt-8">
        <AnimatePresence mode="wait">
          {activeTab === "profil" && (
            <motion.div
              key="profil"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-8"
            >
              {/* Företagsinfo */}
              <PremiumCard
                title="Företagsinformation"
                icon={<BuildingOfficeIcon className="w-6 h-6" />}
                color="from-blue-500/10 to-transparent"
              >
                <div className="space-y-3 text-sm text-slate-700">
                  <div><strong>Företagsnamn:</strong> Valiflow AB</div>
                  <div><strong>Organisationsnummer:</strong> 556123-4567</div>
                  <div><strong>Momsnummer (VAT):</strong> SE556123456701</div>
                  <div><strong>Adress:</strong> Storgatan 12, 111 22 Stockholm</div>
                  <div><strong>Webbplats:</strong> www.valiflow.com</div>
                  <GlowButton text="Redigera information" color="blue" />
                </div>
              </PremiumCard>

              {/* Varumärke */}
              <PremiumCard
                title="Varumärke"
                icon={<SwatchIcon className="w-6 h-6" />}
                color="from-indigo-500/10 to-transparent"
              >
                <div className="space-y-3 text-sm text-slate-700">
                  <div className="flex items-center gap-6">
                    <img
                      src="/valiflow-logo.png"
                      alt="Företagslogotyp"
                      className="w-20 h-20 object-contain border border-slate-200 rounded-lg shadow-sm"
                    />
                    <GlowButton text="Ladda upp ny logotyp" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mt-4">
                      Accentfärg
                    </label>
                    <input
                      type="color"
                      value="#0527FF"
                      className="mt-1 w-12 h-8 border border-slate-200 rounded"
                    />
                  </div>
                </div>
              </PremiumCard>
            </motion.div>
          )}

          {activeTab === "team" && (
            <motion.div
              key="team"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
            >
              <PremiumCard
                title="Team och åtkomst"
                icon={<UserGroupIcon className="w-6 h-6" />}
                color="from-emerald-500/10 to-transparent"
              >
                <div className="text-sm text-slate-700">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b bg-slate-50 text-slate-600">
                        <th className="p-2 text-left">Namn</th>
                        <th className="p-2 text-left">E-post</th>
                        <th className="p-2 text-left">Roll</th>
                        <th className="p-2 text-left">Status</th>
                        <th className="p-2 text-right">Åtgärder</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b hover:bg-slate-50 transition">
                        <td className="p-2 font-medium">Chris</td>
                        <td className="p-2">chris@valiflow.com</td>
                        <td className="p-2">Administratör</td>
                        <td className="p-2 text-green-600 font-medium">Aktiv</td>
                        <td className="p-2 text-right">
                          <button className="text-blue-600 hover:underline">Hantera</button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <div className="pt-4">
                    <GlowButton text="Bjud in ny medlem" color="emerald" />
                  </div>
                </div>
              </PremiumCard>
            </motion.div>
          )}

          {activeTab === "finans" && (
            <motion.div
              key="finans"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
            >
              <PremiumCard
                title="Finansiella inställningar"
                icon={<CurrencyDollarIcon className="w-6 h-6" />}
                color="from-amber-500/10 to-transparent"
              >
                <div className="space-y-4 text-sm text-slate-700">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Input label="Valuta" type="select" options={["SEK", "EUR", "USD"]} />
                    <Input label="Räkenskapsår börjar" type="date" />
                    <Input label="Fakturaprefix" placeholder="INV-" />
                    <Input label="Standard moms" type="number" placeholder="25" />
                  </div>
                  <GlowButton text="Spara ändringar" color="amber" />
                </div>
              </PremiumCard>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

/* 🔹 PremiumCard Component */
function PremiumCard({ title, icon, color, children }) {
  return (
    <motion.div
      whileHover={{ y: -3 }}
      transition={{ duration: 0.2 }}
      className="bg-white border border-slate-100 rounded-2xl shadow-lg relative overflow-hidden"
    >
      <div className={`absolute inset-0 bg-gradient-to-r ${color} opacity-50`}></div>
      <div className="relative z-10">
        <div className="flex items-center gap-3 border-b border-slate-100 p-6 rounded-t-2xl backdrop-blur-sm">
          <div className="p-2 bg-slate-800/80 text-white rounded-xl shadow">
            {icon}
          </div>
          <div>
            <h2 className="text-lg font-semibold text-slate-800">{title}</h2>
          </div>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </motion.div>
  );
}

/* 🔹 GlowButton Component */
function GlowButton({ text, color = "blue" }) {
  const colorMap = {
    blue: "from-blue-600 to-cyan-500",
    emerald: "from-emerald-600 to-green-500",
    amber: "from-amber-500 to-orange-400",
  };
  return (
    <motion.button
      whileHover={{ scale: 1.04 }}
      whileTap={{ scale: 0.97 }}
      className={`relative px-4 py-2 text-white font-medium rounded-lg overflow-hidden`}
    >
      <span className={`absolute inset-0 bg-gradient-to-r ${colorMap[color]} opacity-90 rounded-lg`}></span>
      <span className="absolute inset-0 bg-white/20 blur-md opacity-0 group-hover:opacity-40 transition"></span>
      <span className="relative z-10">{text}</span>
    </motion.button>
  );
}

/* 🔹 Input Component */
function Input({ label, type = "text", placeholder, options }) {
  return (
    <div>
      <label className="block text-slate-600 text-sm font-medium mb-1">{label}</label>
      {type === "select" ? (
        <select className="w-full border border-slate-300 rounded-lg px-2 py-1.5 focus:ring-blue-100 focus:border-blue-400">
          {options.map((opt) => (
            <option key={opt}>{opt}</option>
          ))}
        </select>
      ) : (
        <input
          type={type}
          placeholder={placeholder}
          className="w-full border border-slate-300 rounded-lg px-2 py-1.5 focus:ring-blue-100 focus:border-blue-400"
        />
      )}
    </div>
  );
}
