import React, { useState, useRef, useEffect } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  HomeIcon,
  UserGroupIcon,
  DocumentTextIcon,
  Cog6ToothIcon,
  ShieldExclamationIcon,
  EnvelopeOpenIcon,
  ChartBarIcon,
  PuzzlePieceIcon,
  BuildingOfficeIcon,
  FunnelIcon,
  ArrowDownTrayIcon,
  CalendarDaysIcon,
  ArrowRightOnRectangleIcon,
  ChevronDownIcon,
  DocumentArrowDownIcon,
  ShareIcon,
  ClipboardDocumentCheckIcon,
} from "@heroicons/react/24/outline";
import { DateRange } from "react-date-range";
import { format } from "date-fns";
import DashboardTour from "@/components/DashboardTour"; // 👈 Guided Tour component

export default function DashboardLayout() {
  const navigate = useNavigate();

  // --- Dropdown state ---
  const [showDateMenu, setShowDateMenu] = useState(false);
  const [showFilterMenu, setShowFilterMenu] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);

  // --- Date range state ---
  const [range, setRange] = useState([
    {
      startDate: new Date(new Date().setDate(new Date().getDate() - 30)),
      endDate: new Date(),
      key: "selection",
    },
  ]);

  // --- Filter state ---
  const [filters, setFilters] = useState({
    flagged: true,
    highRisk: false,
    archived: false,
  });

  // --- Refs for dropdowns ---
  const dateRef = useRef(null);
  const filterRef = useRef(null);
  const exportRef = useRef(null);

  // --- Close dropdowns on outside click ---
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (
        dateRef.current &&
        !dateRef.current.contains(e.target) &&
        filterRef.current &&
        !filterRef.current.contains(e.target) &&
        exportRef.current &&
        !exportRef.current.contains(e.target)
      ) {
        setShowDateMenu(false);
        setShowFilterMenu(false);
        setShowExportMenu(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/login");
  };

  // 🇸🇪 Sidebar navigation
  const nav = [
    { to: "/dashboard", label: "Översikt", icon: HomeIcon },
    { to: "/dashboard/customers", label: "Kunder", icon: UserGroupIcon },
    { to: "/dashboard/invoices", label: "Fakturor", icon: DocumentTextIcon },
    { to: "/dashboard/email", label: "E-post", icon: EnvelopeOpenIcon },
    { to: "/dashboard/fraud", label: "Avvikelser", icon: ShieldExclamationIcon },
    { to: "/dashboard/analytics", label: "Analys", icon: ChartBarIcon },
    { to: "/dashboard/audit-log", label: "Granskningslogg", icon: ClipboardDocumentCheckIcon },
    { to: "/dashboard/integrations", label: "Integrationer", icon: PuzzlePieceIcon },
    { to: "/dashboard/company", label: "Företag", icon: BuildingOfficeIcon },
    { to: "/dashboard/settings", label: "Inställningar", icon: Cog6ToothIcon },
  ];

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900">
      {/* Sidebar */}
      <aside className="hidden md:flex md:w-60 lg:w-64 flex-col border-r border-slate-200 bg-white shadow-sm">
        <div className="flex items-center gap-3 h-16 px-6 border-b border-slate-200">
          <img src="/src/assets/valiflow-log.png" alt="Valiflow" className="h-8 w-auto" />
          <span className="font-semibold text-lg">Valiflow</span>
        </div>

        <nav className="flex-1 py-4">
          {nav.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `flex items-center gap-3 mx-3 my-1 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? "bg-gradient-to-r from-blue-600 to-emerald-400 text-white shadow-md"
                    : "text-slate-700 hover:bg-slate-100"
                }`
              }
            >
              <Icon className="h-5 w-5" />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="px-6 py-4 border-t border-slate-200 text-center text-xs text-slate-400">
          © {new Date().getFullYear()} Valiflow
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
          <div className="flex flex-wrap items-center justify-between px-6 py-3">
            {/* Left side */}
            <div>
              <h1 className="text-xl font-semibold text-slate-800">
                Välkommen tillbaka, Chris
              </h1>
              <p className="text-sm text-slate-500">
                {new Date().toLocaleDateString("sv-SE", {
                  weekday: "long",
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}
              </p>
            </div>

            {/* Right controls */}
            <div className="flex items-center gap-3 relative">
              {/* Date range */}
              <div className="relative" ref={dateRef}>
                <button
                  onClick={() => {
                    setShowDateMenu(!showDateMenu);
                    setShowFilterMenu(false);
                    setShowExportMenu(false);
                  }}
                  id="integration-btn"
                  className="flex items-center gap-2 px-3 py-2 text-sm rounded-lg border border-slate-200 hover:bg-slate-50 transition text-slate-700"
                >
                  <CalendarDaysIcon className="h-4 w-4 text-slate-500" />
                  <span>
                    {`${format(range[0].startDate, "MMM d")} – ${format(
                      range[0].endDate,
                      "MMM d"
                    )}`}
                  </span>
                  <ChevronDownIcon className="h-4 w-4 text-slate-400" />
                </button>
                {showDateMenu && (
                  <div className="absolute right-0 mt-2 bg-white border border-slate-200 rounded-xl shadow-lg z-50">
                    <DateRange
                      editableDateInputs
                      onChange={(item) => setRange([item.selection])}
                      moveRangeOnFirstSelection={false}
                      ranges={range}
                      rangeColors={["#2563eb"]}
                    />
                  </div>
                )}
              </div>

              {/* Filter menu */}
              <div className="relative" ref={filterRef}>
                <button
                  onClick={() => {
                    setShowFilterMenu(!showFilterMenu);
                    setShowDateMenu(false);
                    setShowExportMenu(false);
                  }}
                  id="sync-data-btn"
                  className="flex items-center gap-2 px-3 py-2 text-sm rounded-lg border border-slate-200 hover:bg-slate-50 transition text-slate-700"
                >
                  <FunnelIcon className="h-4 w-4 text-slate-500" />
                  <span>Filter</span>
                  <ChevronDownIcon className="h-4 w-4 text-slate-400" />
                </button>
                {showFilterMenu && (
                  <div className="absolute right-0 mt-2 w-56 bg-white border border-slate-200 rounded-xl shadow-lg z-50 p-3 space-y-2 text-sm">
                    {Object.entries(filters).map(([key, value]) => (
                      <label key={key} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={value}
                          onChange={() =>
                            setFilters((prev) => ({
                              ...prev,
                              [key]: !prev[key],
                            }))
                          }
                          className="text-blue-600 focus:ring-blue-500 rounded"
                        />
                        <span className="capitalize text-slate-700">
                          {key === "highRisk"
                            ? "Endast hög risk"
                            : key === "flagged"
                            ? "Visa flaggade fakturor"
                            : "Inkludera arkiverade"}
                        </span>
                      </label>
                    ))}
                  </div>
                )}
              </div>

              {/* Export menu */}
              <div className="relative" ref={exportRef}>
                <button
                  onClick={() => {
                    setShowExportMenu(!showExportMenu);
                    setShowDateMenu(false);
                    setShowFilterMenu(false);
                  }}
                  id="invite-btn"
                  className="flex items-center gap-2 px-3 py-2 text-sm rounded-lg border border-slate-200 hover:bg-slate-50 transition text-slate-700"
                >
                  <ArrowDownTrayIcon className="h-4 w-4 text-slate-500" />
                  <span>Exportera</span>
                  <ChevronDownIcon className="h-4 w-4 text-slate-400" />
                </button>
                {showExportMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white border border-slate-200 rounded-xl shadow-lg z-50 p-2 text-sm">
                    <button className="flex items-center gap-2 w-full px-3 py-2 rounded-lg hover:bg-slate-50 text-slate-700">
                      <DocumentArrowDownIcon className="h-4 w-4" />
                      Exportera som PDF
                    </button>
                    <button className="flex items-center gap-2 w-full px-3 py-2 rounded-lg hover:bg-slate-50 text-slate-700">
                      <ArrowDownTrayIcon className="h-4 w-4" />
                      Exportera som CSV
                    </button>
                    <button className="flex items-center gap-2 w-full px-3 py-2 rounded-lg hover:bg-slate-50 text-slate-700">
                      <ShareIcon className="h-4 w-4" />
                      Dela rapportlänk
                    </button>
                  </div>
                )}
              </div>

              {/* Logout */}
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 transition-all"
              >
                <ArrowRightOnRectangleIcon className="h-4 w-4" />
                Logga ut
              </button>
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-6" id="ai-analysis-section">
          <DashboardTour />
          <Outlet />
        </main>
      </div>
    </div>
  );
}
