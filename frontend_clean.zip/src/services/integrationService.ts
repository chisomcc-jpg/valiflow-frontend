import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

// 💡 Typdefinition för integration
export interface Integration {
  id: string;
  name: string;
  status: "connected" | "disconnected";
  description?: string;
  category?: "ERP" | "Email" | "AI" | "Other";
}

// 📦 Hämta alla integrationer (med status)
export async function fetchIntegrations(): Promise<Integration[]> {
  try {
    const res = await axios.get(`${API_URL}/integrations`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });
    return res.data;
  } catch (err) {
    console.warn("⚠️ Backend för integrations saknas, använder mockdata istället.");
    return getMockIntegrations();
  }
}

// 🔗 Starta anslutning (t.ex. Fortnox OAuth)
export async function connectIntegration(id: string): Promise<void> {
  const res = await axios.get(`${API_URL}/integrations/connect/${id}`, {
    headers: {
      Authorization: `Bearer ${localStorage.getItem("token")}`,
    },
  });

  // 🚪 Om backend svarar med redirect-url (OAuth)
  if (res.data?.url) {
    window.location.href = res.data.url;
  } else {
    console.warn("No redirect URL received from backend");
  }
}

// 🔌 Koppla från integration
export async function disconnectIntegration(id: string): Promise<void> {
  await axios.post(
    `${API_URL}/integrations/disconnect/${id}`,
    {},
    {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    }
  );
}

// 💾 Mockdata (tas bort när backend är klart)
function getMockIntegrations(): Integration[] {
  return [
    // --- ERP ---
    {
      id: "fortnox",
      name: "Fortnox",
      category: "ERP",
      description: "Synka kunder, fakturor och bokföring direkt via Fortnox API.",
      status: "connected",
    },
    {
      id: "visma",
      name: "Visma eAccounting",
      category: "ERP",
      description: "Koppla till Visma eAccounting för att automatiskt importera leverantörsfakturor.",
      status: "disconnected",
    },
    {
      id: "microsoft",
      name: "Microsoft Dynamics 365",
      category: "ERP",
      description: "Integrera med Microsoft Business Central för realtidsdata och ekonomisynk.",
      status: "disconnected",
    },

    // --- EMAIL ---
    {
      id: "gmail",
      name: "Gmail",
      category: "Email",
      description: "Importera fakturor direkt från e-post och synka automatiskt med Valiflow.",
      status: "connected",
    },
    {
      id: "outlook",
      name: "Outlook",
      category: "Email",
      description: "Automatisera fakturahantering via Microsoft Outlook-integration.",
      status: "disconnected",
    },

    // --- AI ---
    {
      id: "aifraud",
      name: "AI Fraud Detection",
      category: "AI",
      description: "Analysera fakturor i realtid för misstänkta avvikelser med hjälp av AI.",
      status: "connected",
    },
    {
      id: "autoscan",
      name: "Auto Scanner",
      category: "AI",
      description: "Skanna nya fakturor automatiskt i bakgrunden med smart detektering.",
      status: "disconnected",
    },
  ];
}
