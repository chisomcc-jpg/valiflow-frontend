import { NavLink } from "react-router-dom";
import {
  Squares2X2Icon,
  UserIcon,
  DocumentIcon,
  Cog6ToothIcon,
  ShieldCheckIcon,
  InboxIcon,
  ExclamationTriangleIcon,
  ChartBarIcon,
  BuildingOfficeIcon,
  PuzzlePieceIcon,
} from "@heroicons/react/24/outline";

export default function Sidebar() {
  const role = localStorage.getItem("role");

  const navItems = [
    // 🌐 Huvudmeny
    { name: "Översikt", path: "/dashboard", icon: Squares2X2Icon },
    { name: "Kunder", path: "/dashboard/customers", icon: UserIcon },
    { name: "Fakturor", path: "/dashboard/invoices", icon: DocumentIcon },
    { name: "E-post", path: "/dashboard/email", icon: InboxIcon },
    { name: "Avvikelser", path: "/dashboard/fraud", icon: ExclamationTriangleIcon },

    // 📈 Analys
    { name: "Analys", path: "/dashboard/analytics", icon: ChartBarIcon },

    // ⚙️ System
    { name: "Integrationer", path: "/dashboard/integrations", icon: PuzzlePieceIcon },
    { name: "Inställningar", path: "/dashboard/settings", icon: Cog6ToothIcon },
    { name: "Företagsprofil", path: "/dashboard/company", icon: BuildingOfficeIcon },
  ];

  // 👑 Admin-only section
  if (role === "ADMIN" || role === "SUPER_ADMIN") {
    navItems.push({
      name: "Adminpanel",
      path: "/admin",
      icon: ShieldCheckIcon,
    });
  }

  return (
    <aside className="w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 flex flex-col transition-colors duration-300">
      {/* Logo Section */}
      <div className="h-16 flex items-center justify-center border-b border-gray-100 dark:border-gray-800">
        <h1 className="text-xl font-bold text-blue-600 dark:text-blue-500 tracking-tight">
          Valiflow
        </h1>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            end
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                isActive
                  ? "bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400"
                  : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
              }`
            }
          >
            <item.icon className="w-5 h-5" />
            {item.name}
          </NavLink>
        ))}
      </nav>

      {/* Footer / Version info */}
      <div className="border-t border-gray-100 dark:border-gray-800 p-4 text-xs text-gray-500 dark:text-gray-400 text-center">
        © {new Date().getFullYear()} Valiflow
      </div>
    </aside>
  );
}
