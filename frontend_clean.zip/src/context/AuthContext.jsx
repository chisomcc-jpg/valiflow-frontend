// src/context/AuthContext.jsx
import React, {
  createContext,
  useState,
  useEffect,
  useContext,
  useCallback,
  useMemo,
  useRef,
} from "react";
import { jwtDecode } from "jwt-decode";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Internal session-warning state (not exposed)
  const [showWarning, setShowWarning] = useState(false);
  const [countdown, setCountdown] = useState(60);
  const initialized = useRef(false);

  // 🔁 Load token on startup once
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    const savedToken = localStorage.getItem("token");
    if (savedToken) {
      try {
        const decoded = jwtDecode(savedToken);
        setToken(savedToken);
        setUser(decoded);
      } catch {
        localStorage.removeItem("token");
      }
    }
    setLoading(false);
  }, []);

  // 🧩 Stable login helper (async so callers can await it)
  const login = useCallback(async (newToken) => {
    try {
      const decoded = jwtDecode(newToken);
      localStorage.setItem("token", newToken);
      setToken(newToken);
      setUser(decoded);
      setLoading(false);
      return decoded;
    } catch (err) {
      console.error("JWT decode failed:", err);
      throw err;
    }
  }, []);

  // 🔓 Stable logout helper
  const logout = useCallback(() => {
    localStorage.removeItem("token");
    setToken(null);
    setUser(null);
    setShowWarning(false);
  }, []);

  // 🕐 Auto-logout after inactivity (internal)
  useEffect(() => {
    const INACTIVITY_LIMIT = 15 * 60 * 1000;
    const WARNING_BEFORE = 60 * 1000;
    let logoutTimer, warningTimer, countdownTimer;

    const resetTimers = () => {
      clearTimeout(logoutTimer);
      clearTimeout(warningTimer);
      clearInterval(countdownTimer);
      setShowWarning(false);

      warningTimer = setTimeout(() => {
        setShowWarning(true);
        setCountdown(60);
        countdownTimer = setInterval(() => {
          setCountdown((prev) => (prev <= 1 ? 0 : prev - 1));
        }, 1000);
      }, INACTIVITY_LIMIT - WARNING_BEFORE);

      logoutTimer = setTimeout(() => {
        clearInterval(countdownTimer);
        setShowWarning(false);
        logout();
      }, INACTIVITY_LIMIT);
    };

    const events = ["mousemove", "keydown", "click", "scroll", "touchstart"];
    events.forEach((e) => window.addEventListener(e, resetTimers));
    resetTimers();

    return () => {
      events.forEach((e) => window.removeEventListener(e, resetTimers));
      clearTimeout(logoutTimer);
      clearTimeout(warningTimer);
      clearInterval(countdownTimer);
    };
  }, [logout]);

  const value = useMemo(
    () => ({ token, user, login, logout, loading }),
    [token, user, login, logout, loading]
  );

  return (
    <AuthContext.Provider value={value}>
      {children}

      {showWarning && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/40 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xl p-6 max-w-sm text-center">
            <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
              Session Timeout
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-300 mt-2">
              You’ll be logged out in{" "}
              <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                {countdown}s
              </span>{" "}
              unless you continue using the app.
            </p>
            <button
              onClick={() => {
                setShowWarning(false);
                window.dispatchEvent(new Event("mousemove"));
              }}
              className="mt-4 bg-emerald-600 hover:bg-emerald-700 text-white text-sm px-4 py-2 rounded-lg transition"
            >
              Stay Logged In
            </button>
          </div>
        </div>
      )}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
