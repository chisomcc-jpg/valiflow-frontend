import React, { useEffect, useMemo, useState } from "react";
import {
  PlusIcon,
  MagnifyingGlassIcon,
  ArrowsUpDownIcon,
  FunnelIcon,
  XMarkIcon,
} from "@heroicons/react/24/outline";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";

// Valiflow colors
const VF = {
  blue: "#0527FF",
  green: "#22C55E",
  purple: "#8B5CF6",
};

export default function Customers() {
  const API = import.meta.env.VITE_API_URL || "http://localhost:4000";
  const [customers, setCustomers] = useState([]);
  const [connected, setConnected] = useState({ fortnox: false, visma: false, microsoft: false });
  const [activeTab, setActiveTab] = useState("all");
  const [query, setQuery] = useState("");
  const [sortKey, setSortKey] = useState("name");
  const [drawer, setDrawer] = useState(null);
  const [showAdd, setShowAdd] = useState(false);

  // Mock integration check
  useEffect(() => {
    setConnected({ fortnox: true, visma: false, microsoft: true });
  }, []);

  // Fetch based on connected integrations
  const fetchCustomers = async () => {
    try {
      const results = [];
      if (connected.fortnox) results.push(await (await fetch(`${API}/fortnox/customers`)).json());
      if (connected.visma) results.push(await (await fetch(`${API}/visma/customers`)).json());
      if (connected.microsoft) results.push(await (await fetch(`${API}/microsoft/customers`)).json());
      setCustomers(results.flat());
    } catch (err) {
      toast.error("Failed to load customers");
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, [connected]);

  const filtered = useMemo(() => {
    let arr = customers.filter((c) => {
      const src = c.source || "fortnox";
      if (activeTab !== "all" && src !== activeTab) return false;
      return (c.name || c.Name || "").toLowerCase().includes(query.toLowerCase());
    });
    if (sortKey === "risk") arr.sort((a, b) => (b.risk || 0) - (a.risk || 0));
    if (sortKey === "balance") arr.sort((a, b) => (b.balance || 0) - (a.balance || 0));
    return arr;
  }, [customers, activeTab, query, sortKey]);

  const sourceBadge = (srcs = []) => (
    <div className="flex gap-1 mt-2">
      {srcs.includes("fortnox") && <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">Fortnox</span>}
      {srcs.includes("visma") && <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">Visma</span>}
      {srcs.includes("microsoft") && <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">Microsoft</span>}
    </div>
  );

  const riskBadge = (r) => {
    if (r < 30) return <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full text-xs">Low</span>;
    if (r < 70) return <span className="px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full text-xs">Medium</span>;
    return <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-xs">High</span>;
  };

  return (
    <div className="space-y-6 text-slate-800">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Customers</h1>
          <p className="text-sm text-slate-500">Unified customer view across all connected systems.</p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="inline-flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-white shadow hover:shadow-md"
        >
          <PlusIcon className="w-5 h-5" /> Add Customer
        </button>
      </div>

      {/* Integration badges */}
      <div className="flex gap-3 text-sm">
        <span className={`px-3 py-1 rounded-full ${connected.fortnox ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-600'}`}>Fortnox {connected.fortnox ? '✓' : '✕'}</span>
        <span className={`px-3 py-1 rounded-full ${connected.visma ? 'bg-purple-100 text-purple-700' : 'bg-slate-200 text-slate-600'}`}>Visma {connected.visma ? '✓' : '✕'}</span>
        <span className={`px-3 py-1 rounded-full ${connected.microsoft ? 'bg-blue-100 text-blue-700' : 'bg-slate-200 text-slate-600'}`}>Microsoft {connected.microsoft ? '✓' : '✕'}</span>
      </div>

      {/* Tabs */}
      <div className="flex gap-3 border-b border-slate-200">
        {['all', 'fortnox', 'visma', 'microsoft'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`py-2 px-4 text-sm font-medium border-b-2 transition ${
              activeTab === tab ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            {tab === 'all' ? 'All' : tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Search & Sort */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <MagnifyingGlassIcon className="absolute left-3 top-2.5 w-5 h-5 text-gray-400" />
          <input
            placeholder="Search customers..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full rounded-xl border border-slate-200 pl-10 pr-3 py-2.5 shadow-sm focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <div className="relative">
          <select
            value={sortKey}
            onChange={(e) => setSortKey(e.target.value)}
            className="rounded-xl border border-slate-200 bg-white pl-3 pr-8 py-2.5 shadow-sm focus:ring-2 focus:ring-indigo-500"
          >
            <option value="name">Sort by Name</option>
            <option value="risk">Sort by Risk</option>
            <option value="balance">Sort by Balance</option>
          </select>
          <ArrowsUpDownIcon className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
        </div>
      </div>

      {/* Cards */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {filtered.length === 0 && (
          <div className="col-span-full text-center text-slate-500 p-8 border border-dashed rounded-2xl">No customers found.</div>
        )}
        {filtered.map((c, i) => (
          <motion.div
            key={i}
            whileHover={{ y: -2 }}
            className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm hover:shadow-md transition cursor-pointer"
            onClick={() => setDrawer(c)}
          >
            <div className="flex justify-between">
              <h3 className="font-semibold text-slate-800">{c.Name || c.name}</h3>
              {riskBadge(c.risk || 20)}
            </div>
            <p className="text-sm text-slate-500 mt-1">{c.Email || c.email || '—'}</p>
            <p className="text-sm text-slate-500">📞 {c.Phone || '—'}</p>
            <div className="mt-3 text-sm">
              🧾 {c.invoices || 0} invoices • 💰 {c.balance || 0} kr
            </div>
            {sourceBadge(c.source ? [c.source] : ["fortnox"])}
          </motion.div>
        ))}
      </div>

      {/* Drawer */}
      <AnimatePresence>
        {drawer && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 z-40"
            onClick={() => setDrawer(null)}
          >
            <motion.div
              initial={{ x: 400 }}
              animate={{ x: 0 }}
              exit={{ x: 400 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="absolute right-0 top-0 h-full w-full sm:w-[420px] bg-white shadow-2xl p-6"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-lg font-semibold">{drawer.Name || drawer.name}</h2>
                  <p className="text-sm text-slate-500">Org.nr: {drawer.org || '—'}</p>
                </div>
                <button onClick={() => setDrawer(null)} className="p-1 hover:bg-slate-100 rounded-lg">
                  <XMarkIcon className="w-6 h-6 text-slate-600" />
                </button>
              </div>
              <div className="mt-4 space-y-3">
                <p className="text-sm text-slate-600">Email: {drawer.Email || '—'}</p>
                <p className="text-sm text-slate-600">Phone: {drawer.Phone || '—'}</p>
                <p className="text-sm text-slate-600">Balance: {drawer.balance || 0} kr</p>
                <div className="mt-3">{sourceBadge([drawer.source || 'fortnox'])}</div>
                <div className="mt-5 flex gap-2">
                  <button className="flex-1 bg-indigo-600 text-white py-2 rounded-xl hover:opacity-90">View Invoices</button>
                  <button className="flex-1 border border-slate-300 py-2 rounded-xl hover:bg-slate-50">Rescan</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
