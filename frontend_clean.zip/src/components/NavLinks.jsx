import { Link, useLocation } from "react-router-dom";
import {
  HomeIcon,
  UserGroupIcon,
  DocumentDuplicateIcon,
  EnvelopeOpenIcon,
  ExclamationTriangleIcon,
} from "@heroicons/react/24/outline";
import clsx from "clsx";

const links = [
  { name: "Översikt", href: "/dashboard", icon: HomeIcon },
  { name: "Kunder", href: "/dashboard/customers", icon: UserGroupIcon },
  { name: "Fakturor", href: "/dashboard/invoices", icon: DocumentDuplicateIcon },
  { name: "E-post", href: "/dashboard/email", icon: EnvelopeOpenIcon }, // ✅ Ny länk
  { name: "Avvikelser", href: "/dashboard/fraud", icon: ExclamationTriangleIcon }, // valfritt
];

export default function NavLinks() {
  const location = useLocation();
  const pathname = location.pathname;

  return (
    <nav className="flex flex-col gap-1">
      {links.map((link) => {
        const LinkIcon = link.icon;
        const isActive =
          pathname === link.href || pathname.startsWith(link.href);

        return (
          <Link
            key={link.name}
            to={link.href}
            className={clsx(
              "flex items-center gap-3 p-3 rounded-lg text-sm font-medium transition-colors duration-200",
              isActive
                ? "bg-blue-50 text-blue-600 dark:bg-blue-900/40 dark:text-blue-400"
                : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
            )}
          >
            <LinkIcon className="w-5 h-5" />
            <span>{link.name}</span>
          </Link>
        );
      })}
    </nav>
  );
}
