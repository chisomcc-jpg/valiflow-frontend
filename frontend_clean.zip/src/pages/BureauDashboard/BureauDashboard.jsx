import React from "react";
import {
  UsersIcon,
  DocumentTextIcon,
  ExclamationTriangleIcon,
  BanknotesIcon,
  CpuChipIcon,
  MagnifyingGlassIcon,
  BellIcon,
  PlusIcon,
} from "@heroicons/react/24/outline";
import { motion } from "framer-motion";

// 🔹 Mockdata
const mockCustomers = [
  { name: "ByggPartner AB", erp: "Visma.net", status: "Aktiv", risk: 14, flagged: 8, accuracy: "94%" },
  { name: "Ekonomi & Co", erp: "Fortnox", status: "Avvikelser", risk: 32, flagged: 16, accuracy: "88%" },
  { name: "Creative Minds Oy", erp: "BC", status: "Aktiv", risk: 11, flagged: 2, accuracy: "97%" },
];

const cards = [
  {
    title: "Antal kunder",
    value: "42",
    icon: UsersIcon,
    color: "from-cyan-500/10 to-cyan-500/5 text-cyan-600",
  },
  {
    title: "Fakturor analyserade",
    value: "8 921",
    icon: DocumentTextIcon,
    color: "from-blue-500/10 to-blue-500/5 text-blue-600",
  },
  {
    title: "Flaggade fakturor",
    value: "112",
    icon: ExclamationTriangleIcon,
    color: "from-amber-500/10 to-amber-500/5 text-amber-600",
  },
  {
    title: "Totalt besparat belopp",
    value: "457 000 kr",
    icon: BanknotesIcon,
    color: "from-emerald-500/10 to-emerald-500/5 text-emerald-600",
  },
  {
    title: "AI Accuracy (snitt)",
    value: "94%",
    icon: CpuChipIcon,
    color: "from-indigo-500/10 to-indigo-500/5 text-indigo-600",
  },
];

export default function BureauDashboard() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4 }}
      className="min-h-screen bg-[#f2f3f5] text-slate-800"
    >
      {/* 🔝 Topbar */}
      <header className="glass sticky top-0 z-50 flex items-center justify-between px-8 py-4 backdrop-blur-md border-b border-slate-200">
        <div className="flex items-center gap-3">
          <img src="/valiflow-logo.png" alt="Valiflow" className="w-8 h-8" />
          <h1 className="text-lg font-semibold text-slate-700">Byrå: Redo AB</h1>
        </div>

        <div className="flex items-center gap-4">
          {/* Sökfält */}
          <div className="relative">
            <MagnifyingGlassIcon className="w-5 h-5 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Sök kund eller orgnr..."
              className="bg-white border border-slate-200 pl-10 pr-4 py-2 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 w-64 shadow-sm"
            />
          </div>

          {/* Lägg till kund */}
          <button className="flex items-center gap-2 bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2 rounded-lg shadow-sm transition">
            <PlusIcon className="w-4 h-4" /> Lägg till kund
          </button>

          {/* Notifications */}
          <button className="relative p-2 text-slate-500 hover:text-cyan-600 transition">
            <BellIcon className="w-6 h-6" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
        </div>
      </header>

      {/* 📊 Huvudinnehåll */}
      <main className="max-w-7xl mx-auto px-10 py-10 space-y-12">
        {/* Översiktskort */}
        <section>
          <h2 className="section-title">Byråns portföljöversikt</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-6">
            {cards.map((c, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="card-premium p-6 hover-lift"
              >
                <div className="flex items-center justify-between mb-4">
                  <div
                    className={`w-10 h-10 rounded-xl bg-gradient-to-br ${c.color} flex items-center justify-center shadow-sm`}
                  >
                    <c.icon className={`w-5 h-5 ${c.color.split(" ")[2]}`} />
                  </div>
                </div>
                <p className="text-sm text-slate-500 mb-1">{c.title}</p>
                <p className="text-3xl font-semibold text-slate-800">{c.value}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* 👥 Kundtabell */}
        <section>
          <h2 className="section-title">Kundöversikt</h2>
          <div className="card-premium p-6 overflow-x-auto">
            <table className="table-premium w-full">
              <thead>
                <tr>
                  <th>Kund</th>
                  <th>ERP-system</th>
                  <th>Status</th>
                  <th>Risk</th>
                  <th>Flaggade</th>
                  <th>AI Accuracy</th>
                  <th>Senast synkad</th>
                </tr>
              </thead>
              <tbody>
                {mockCustomers.map((c, i) => (
                  <tr key={i}>
                    <td>{c.name}</td>
                    <td>{c.erp}</td>
                    <td>
                      {c.status === "Aktiv" ? (
                        <span className="text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md text-xs font-medium">
                          Aktiv
                        </span>
                      ) : (
                        <span className="text-amber-600 bg-amber-50 px-2 py-1 rounded-md text-xs font-medium">
                          Avvikelser
                        </span>
                      )}
                    </td>
                    <td>{c.risk}</td>
                    <td>{c.flagged}</td>
                    <td>{c.accuracy}</td>
                    <td>{i === 0 ? "Idag" : i === 1 ? "Igår" : "Idag"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* 📈 Portfolio Insights */}
        <section>
          <h2 className="section-title">Portfolio Insights</h2>
          <div className="card-premium p-8 text-center text-slate-500">
            <p>📊 Kommande: grafer över risknivå, branschfördelning och AI-trender.</p>
          </div>
        </section>

        {/* 📤 Export */}
        <section>
          <div className="card-premium p-6 text-center text-slate-500">
            <p>📥 Exportfunktion för rapporter kommer snart.</p>
          </div>
        </section>
      </main>
    </motion.div>
  );
}
