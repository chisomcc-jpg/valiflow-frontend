// src/pages/Auth/Login.jsx
import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import {
  Mail,
  Lock,
  Eye,
  EyeOff,
  ShieldCheck,
  ArrowRight,
  MailCheck,
  ArrowLeftRight,
} from "lucide-react";

export default function ValiflowLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState("");

  const navigate = useNavigate();
  const { login, token, user, loading: authLoading } = useAuth();
  const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

  // ✅ Redirect if already logged in
  useEffect(() => {
    if (!authLoading && token && user) {
      navigate(user.role === "SUPER_ADMIN" ? "/admin" : "/dashboard", {
        replace: true,
      });
    }
  }, [authLoading, token, user, navigate]);

  // 🔑 Email/password login
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const payload = { email, password };
      const res = await axios.post(`${API_URL}/api/auth/login`, payload, {
        headers: { "Content-Type": "application/json" },
      });

      if (res.status !== 200 || !res.data?.token) {
        throw new Error(res.data?.error || "Invalid credentials");
      }

      const { token, user } = res.data;
      await login(token);

      localStorage.setItem("role", user?.role || "USER");
      if (user?.companyId) localStorage.setItem("companyId", user.companyId);
      localStorage.setItem("user", JSON.stringify(user));

      navigate(user?.role === "SUPER_ADMIN" ? "/admin" : "/dashboard", {
        replace: true,
      });
    } catch (err) {
      console.error("❌ Login error:", err);
      setError(
        err.response?.data?.error ||
          err.message ||
          "Login failed. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  // 🪪 BankID login
  const handleBankIdLogin = async () => {
    try {
      const personalNumber = prompt("Enter your personal number (YYYYMMDDXXXX):");
      if (!personalNumber) return;

      setLoading(true);
      setError("");

      const startRes = await axios.post(`${API_URL}/api/auth/bankid/start`, {
        personalNumber,
      });

      const { orderRef } = startRes.data;
      console.log("📲 BankID started, orderRef:", orderRef);

      let verified = false;
      let attempts = 0;
      const pollInterval = 2000;
      const maxAttempts = 60;

      while (!verified && attempts < maxAttempts) {
        await new Promise((r) => setTimeout(r, pollInterval));

        const statusRes = await axios.post(`${API_URL}/api/auth/bankid/status`, {
          orderRef,
        });

        const { status, token, user, hintCode } = statusRes.data;
        console.log("🔄 BankID status:", status, hintCode || "");

        if (status === "complete" && token && user) {
          await login(token);

          localStorage.setItem("role", user.role);
          if (user.companyId) localStorage.setItem("companyId", user.companyId);
          localStorage.setItem("user", JSON.stringify(user));

          navigate(user.role === "SUPER_ADMIN" ? "/admin" : "/dashboard", {
            replace: true,
          });

          console.log("✅ BankID verified successfully!");
          verified = true;
          break;
        }

        if (status === "failed" || status === "cancelled") {
          setError("BankID login was cancelled or failed. Please try again.");
          break;
        }

        attempts++;
      }

      if (!verified) setError("BankID login timed out. Please try again.");
    } catch (err) {
      console.error("❌ BankID login failed:", err);
      setError("BankID login failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-50 via-white to-slate-100 dark:from-slate-900 dark:via-slate-950 dark:to-slate-900">
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(circle_at_1px_1px,rgba(0,0,0,0.05)_1px,transparent_0)] [background-size:14px_14px] dark:bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.06)_1px,transparent_0)]" />

      <div className="mx-auto flex min-h-screen max-w-7xl flex-col lg:flex-row">
        {/* Left panel */}
        <aside className="relative hidden w-full items-center justify-center overflow-hidden lg:flex lg:w-1/2">
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 via-cyan-400/10 to-indigo-500/10" />
          <div className="absolute -left-24 top-24 h-72 w-72 rounded-full bg-emerald-400/30 blur-3xl" />
          <div className="absolute -right-16 bottom-12 h-80 w-80 rounded-full bg-indigo-400/30 blur-3xl" />

          <div className="relative z-10 p-12">
            <BrandHeader />
            <ul className="mt-10 space-y-6 text-slate-700 dark:text-slate-200">
              <BenefitItem
                icon={<ShieldCheck className="h-5 w-5" aria-hidden />}
                title="Invoice fraud defense"
                desc="Real-time anomaly flags, vendor validation and payment hold workflows."
              />
              <BenefitItem
                icon={<MailCheck className="h-5 w-5" aria-hidden />}
                title="Email-to-invoice hygiene"
                desc="Parse, verify and sanitize inbound invoice emails before they hit your ERP."
              />
              <BenefitItem
                icon={<ArrowRight className="h-5 w-5" aria-hidden />}
                title="Plug into your stack"
                desc="Fortnox, Xero, and custom webhooks—designed for accounting teams."
              />
            </ul>

            <div className="mt-10 flex items-center gap-3 text-sm text-slate-500 dark:text-slate-400">
              <div className="h-2 w-2 rounded-full bg-emerald-500" />
              <p>ISO-27001 mindset • GDPR aware • Sweden-first</p>
            </div>
          </div>
        </aside>

        {/* Right panel */}
        <main className="flex w-full items-center justify-center p-6 lg:w-1/2">
          <div className="mx-auto w-full max-w-md">
            <BrandHeader compact />

            <div className="mt-6 rounded-2xl border border-slate-200/70 bg-white/70 p-6 shadow-xl backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/60">
              <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
                Sign in to Valiflow
              </h1>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                Welcome back. Securely continue to your dashboard.
              </p>

              {/* 🧪 staging indicator */}
              {import.meta.env.MODE === "staging" && (
                <p className="mt-2 text-xs font-medium text-amber-600">
                  🧪 Internal staging — real authentication enabled
                </p>
              )}

              <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                {/* Email */}
                <label className="block" htmlFor="email">
                  <span className="mb-1 block text-sm text-slate-600 dark:text-slate-300">
                    Email
                  </span>
                  <div className="group relative flex items-center rounded-xl border border-slate-200 bg-white transition focus-within:ring-2 focus-within:ring-emerald-500 dark:border-slate-700 dark:bg-slate-900">
                    <div className="pl-3 text-slate-400 group-focus-within:text-emerald-600 dark:text-slate-500">
                      <Mail className="h-5 w-5" aria-hidden />
                    </div>
                    <input
                      id="email"
                      type="email"
                      autoComplete="username"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@company.com"
                      className="w-full rounded-xl border-0 bg-transparent px-3 py-3 text-slate-900 placeholder-slate-400 outline-none dark:text-slate-100"
                    />
                  </div>
                </label>

                {/* Password */}
                <label className="block" htmlFor="password">
                  <span className="mb-1 block text-sm text-slate-600 dark:text-slate-300">
                    Password
                  </span>
                  <div className="group relative flex items-center rounded-xl border border-slate-200 bg-white transition focus-within:ring-2 focus-within:ring-emerald-500 dark:border-slate-700 dark:bg-slate-900">
                    <div className="pl-3 text-slate-400 group-focus-within:text-emerald-600 dark:text-slate-500">
                      <Lock className="h-5 w-5" aria-hidden />
                    </div>
                    <input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      autoComplete="current-password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full rounded-xl border-0 bg-transparent px-3 py-3 text-slate-900 placeholder-slate-400 outline-none dark:text-slate-100"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((s) => !s)}
                      className="absolute right-3 inline-flex items-center justify-center rounded-lg p-2 text-slate-400 hover:text-slate-600 focus:outline-none focus:ring-2 focus:ring-emerald-500 dark:text-slate-500 dark:hover:text-slate-300"
                    >
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                </label>

                {/* Options */}
                <div className="flex items-center justify-between pt-1">
                  <label className="inline-flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
                    <input
                      type="checkbox"
                      checked={remember}
                      onChange={(e) => setRemember(e.target.checked)}
                      className="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 dark:border-slate-600"
                    />
                    Remember me
                  </label>
                  <a
                    href="#"
                    className="text-sm font-medium text-emerald-700 hover:text-emerald-800 dark:text-emerald-400 dark:hover:text-emerald-300"
                  >
                    Forgot password?
                  </a>
                </div>

                {/* Submit */}
                <button
                  type="submit"
                  disabled={loading}
                  className="group relative mt-2 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-tr from-emerald-600 to-cyan-600 px-4 py-3 font-medium text-white shadow-lg shadow-emerald-600/20 transition hover:shadow-emerald-600/30 focus:outline-none focus:ring-2 focus:ring-emerald-500 disabled:opacity-60"
                >
                  <span>{loading ? "Signing in…" : "Sign in"}</span>
                  <ArrowRight className="h-4 w-4 transition -translate-x-1 group-hover:translate-x-0" />
                </button>

                {/* 🪪 BankID login */}
                <button
                  type="button"
                  onClick={handleBankIdLogin}
                  className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-emerald-200 bg-white/70 px-4 py-3 text-sm font-medium text-emerald-700 shadow-sm hover:bg-emerald-50 transition dark:border-emerald-700/40 dark:bg-emerald-900/30 dark:text-emerald-200 dark:hover:bg-emerald-900/40"
                >
                  <ArrowLeftRight className="h-4 w-4" />
                  Login with BankID
                </button>

                {/* Error */}
                {error && (
                  <div className="mt-3 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-200">
                    {error}
                  </div>
                )}
              </form>
            </div>

            <p className="mt-6 text-center text-sm text-slate-500 dark:text-slate-400">
              New to Valiflow?{" "}
              <a
                href="#"
                className="font-medium text-emerald-700 underline-offset-4 hover:underline dark:text-emerald-400"
              >
                Create an account
              </a>
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}

// --- Helper components ---
function BrandHeader({ compact = false }) {
  return (
    <div
      className={`flex items-center ${compact ? "justify-center lg:justify-start" : "justify-start"}`}
    >
      <div className="mr-3 inline-flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-emerald-600 to-cyan-600 text-white shadow shadow-emerald-600/30">
        <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden>
          <path
            d="M5 6l7 12L19 6"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <div>
        <div className="text-xl font-semibold tracking-tight text-slate-900 dark:text-white">
          Valiflow
        </div>
        {!compact && (
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Validate • Detect • Flow
          </p>
        )}
      </div>
    </div>
  );
}

function BenefitItem({ icon, title, desc }) {
  return (
    <li className="flex items-start gap-3 rounded-2xl bg-white/60 p-4 backdrop-blur-md ring-1 ring-slate-200/70 shadow-sm dark:bg-slate-900/50 dark:ring-slate-800">
      <div className="mt-0.5 inline-flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
        {icon}
      </div>
      <div>
        <p className="font-medium text-slate-900 dark:text-slate-100">{title}</p>
        <p className="text-sm text-slate-600 dark:text-slate-300">{desc}</p>
      </div>
    </li>
  );
}
