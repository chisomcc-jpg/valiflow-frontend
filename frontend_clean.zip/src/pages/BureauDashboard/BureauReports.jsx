import React, { useState } from "react";
import {
  DocumentChartBarIcon,
  ChartBarIcon,
  UserGroupIcon,
  BuildingOfficeIcon,
  ArrowDownTrayIcon,
  ClockIcon,
  DocumentDuplicateIcon,
  PlusIcon,
  EyeIcon,
  XMarkIcon,
  LinkIcon,
} from "@heroicons/react/24/outline";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";

export default function BureauReports() {
  const [selectedCustomer, setSelectedCustomer] = useState("");
  const [selectedReport, setSelectedReport] = useState(null);

  const customers = ["Acme AB", "Nordic Foods", "EkonomiBolaget"];

  const reports = [
    {
      id: 1,
      name: "Kundrapport - Oktober",
      type: "Kund",
      date: "2025-10-22",
      createdBy: "Anna Karlsson",
      status: "Klar",
      format: "PDF",
      preview: "/pdf-preview.png",
    },
    {
      id: 2,
      name: "Riskanalys - v.42",
      type: "Risk",
      date: "2025-10-20",
      createdBy: "Jonas Berg",
      status: "Pågår",
      format: "Excel",
      preview: "/excel-preview.png",
    },
  ];

  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 via-white to-slate-100 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Rapporter</h1>
          <p className="text-slate-500 text-sm">
            Generera, förhandsgranska och exportera rapporter för kunder, team och risk.
          </p>
        </div>
        <Button className="bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-2">
          <PlusIcon className="w-5 h-5" />
          Ny rapport
        </Button>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        {[
          {
            title: "Månadens kundrapport",
            desc: "Full sammanställning över alla aktiva kunder.",
            icon: BuildingOfficeIcon,
            color: "bg-emerald-50 text-emerald-700",
          },
          {
            title: "Riskanalys för aktiva kunder",
            desc: "Identifiera kunder med ökande risktrend.",
            icon: ChartBarIcon,
            color: "bg-amber-50 text-amber-700",
          },
          {
            title: "Teamprestanda & effektivitet",
            desc: "Analys av medarbetarnas aktivitet.",
            icon: UserGroupIcon,
            color: "bg-sky-50 text-sky-700",
          },
        ].map((action, i) => (
          <motion.div
            key={i}
            whileHover={{ scale: 1.02 }}
            className={`p-5 border border-slate-200 rounded-xl shadow-sm cursor-pointer hover:shadow-md transition-all ${action.color}`}
          >
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-md bg-white/60 shadow-sm">
                <action.icon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-semibold text-base">{action.title}</h3>
                <p className="text-sm opacity-80">{action.desc}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Rapportgenerator */}
      <Card className="p-6 mb-8 border border-slate-200 shadow-sm bg-white/90">
        <h2 className="text-slate-800 font-semibold mb-4 flex items-center gap-2">
          <DocumentChartBarIcon className="w-5 h-5 text-emerald-600" />
          Skapa rapport
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-4">
          <select className="border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500">
            <option>Välj rapporttyp</option>
            <option>Kundrapport</option>
            <option>Riskanalys</option>
            <option>Teamrapport</option>
          </select>

          <select
            value={selectedCustomer}
            onChange={(e) => setSelectedCustomer(e.target.value)}
            className="border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500"
          >
            <option>Välj kund</option>
            {["Acme AB", "Nordic Foods", "EkonomiBolaget"].map((c, i) => (
              <option key={i}>{c}</option>
            ))}
          </select>

          <select className="border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500">
            <option>Tidsperiod</option>
            <option>Senaste 7 dagar</option>
            <option>Senaste 30 dagar</option>
            <option>3 månader</option>
          </select>

          <select className="border border-slate-200 rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500">
            <option>Filformat</option>
            <option>PDF</option>
            <option>Excel</option>
            <option>CSV</option>
          </select>

          <Button className="bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center gap-2">
            <ArrowDownTrayIcon className="w-5 h-5" />
            Generera
          </Button>
        </div>
      </Card>

      {/* Tvåkolumnslayout */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        {/* Senaste rapporter */}
        <div>
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <ClockIcon className="w-5 h-5 text-emerald-600" />
            Senaste rapporter
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {reports.map((r) => (
              <motion.div
                key={r.id}
                whileHover={{ scale: 1.02 }}
                className="cursor-pointer border border-slate-200 bg-white rounded-xl shadow-sm hover:shadow-md transition-all"
                onClick={() => setSelectedReport(r)}
              >
                <CardContent className="p-5">
                  <div className="flex justify-between mb-3">
                    <h4 className="font-semibold text-slate-800">{r.name}</h4>
                    <span
                      className={`text-xs font-medium px-2 py-0.5 rounded ${
                        r.status === "Klar"
                          ? "bg-emerald-50 text-emerald-700"
                          : "bg-yellow-50 text-yellow-700"
                      }`}
                    >
                      {r.status}
                    </span>
                  </div>
                  <div className="h-32 flex items-center justify-center border border-dashed border-slate-200 rounded-lg overflow-hidden">
                    <img
                      src={r.preview}
                      alt={r.name}
                      className="object-cover w-full h-full opacity-80"
                    />
                  </div>
                  <div className="flex justify-between mt-3 text-xs text-slate-500">
                    <span>{r.date}</span>
                    <span>{r.createdBy}</span>
                  </div>
                </CardContent>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Rapportlogg */}
        <div>
          <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <DocumentDuplicateIcon className="w-5 h-5 text-emerald-600" />
            Rapportlogg
          </h3>
          <div className="overflow-hidden border border-slate-200 rounded-xl bg-white shadow-sm">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-slate-600 border-b">
                <tr>
                  <th className="text-left p-3 font-medium">Rapportnamn</th>
                  <th className="text-left p-3 font-medium">Typ</th>
                  <th className="text-left p-3 font-medium">Datum</th>
                  <th className="text-left p-3 font-medium">Status</th>
                  <th className="text-right p-3 font-medium">Åtgärd</th>
                </tr>
              </thead>
              <tbody>
                {reports.map((r) => (
                  <motion.tr
                    key={r.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.05 }}
                    className="hover:bg-slate-50 border-b last:border-0 transition-colors"
                  >
                    <td className="p-3 font-medium text-slate-800">{r.name}</td>
                    <td className="p-3 text-slate-500">{r.type}</td>
                    <td className="p-3 text-slate-500">{r.date}</td>
                    <td
                      className={`p-3 font-medium ${
                        r.status === "Klar"
                          ? "text-emerald-600"
                          : "text-yellow-600"
                      }`}
                    >
                      {r.status}
                    </td>
                    <td className="p-3 text-right">
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-slate-600 border-slate-200 hover:bg-slate-50 flex items-center gap-1"
                      >
                        <ArrowDownTrayIcon className="w-4 h-4" />
                        Ladda ned
                      </Button>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* 🪟 Förhandsvisnings-modal */}
      <AnimatePresence>
        {selectedReport && (
          <motion.div
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              initial={{ scale: 0.95, y: 10 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 10 }}
              className="bg-white rounded-xl shadow-2xl max-w-4xl w-full p-6 relative"
            >
              <button
                onClick={() => setSelectedReport(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-600"
              >
                <XMarkIcon className="w-6 h-6" />
              </button>

              <h3 className="text-xl font-semibold text-slate-800 mb-2">
                {selectedReport.name}
              </h3>
              <p className="text-slate-500 text-sm mb-4">
                {selectedReport.type} • {selectedReport.format} •{" "}
                {selectedReport.date}
              </p>

              <div className="h-[400px] border border-slate-200 rounded-lg overflow-hidden mb-4">
                <img
                  src={selectedReport.preview}
                  alt={selectedReport.name}
                  className="object-cover w-full h-full"
                />
              </div>

              <div className="flex justify-end gap-3">
                <Button
                  variant="outline"
                  className="text-slate-600 border-slate-200 hover:bg-slate-50 flex items-center gap-1"
                >
                  <LinkIcon className="w-4 h-4" />
                  Dela länk
                </Button>
                <Button className="bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-2">
                  <ArrowDownTrayIcon className="w-5 h-5" />
                  Ladda ned
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
