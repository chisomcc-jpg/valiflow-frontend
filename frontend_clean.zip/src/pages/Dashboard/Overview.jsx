import React, { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from "recharts";
import axios from "axios";
import { useParams } from "react-router-dom";

/**
 * CompanyOverview v2 — AI-driven, modulär, SaaS-klass
 * - Ett enda API-anrop: GET /company/:id/overview
 * - Widgets: InsightPanel, KPI-grid, RevenueChart, RiskDonut, AlertsFeed,
 *   BenchmarkCard, CompliancePanel, IntegrationStatus, UpsellPanel
 * - Byggd för att vara konfigurerbar per användare (framtida layout-state)
 */

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

const VF = {
  blue: "#0527FF",
  cyan: "#22d3ee",
  green: "#22C55E",
  amber: "#F59E0B",
  red: "#EF4444",
  slate700: "#334155",
};

const fadeUp = {
  hidden: { opacity: 0, y: 22 },
  visible: (i = 1) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.45, ease: "easeOut" },
  }),
};

export default function CompanyOverviewV2() {
  const { companyId } = useParams();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [data, setData] = useState({
    invoices: [],
    customers: [],
    fraudLogs: [],
    totalAmount: 0,
    flagged: 0,
    avgRisk: 0,
    avgConfidence: 0,
    aiSummary: "",
    invoicesByMonth: [],
    benchmark: null,
    integrations: [],
    compliance: null,
    loading: true,
  });

  useEffect(() => {
    if (!companyId) {
      console.warn("⚠️ Ingen companyId i URL – kontrollera din route!");
      return;
    }
    load(true);
    const t = setInterval(() => load(false), 60000);
    return () => clearInterval(t);
  }, [companyId]);

  async function load(initial) {
    try {
      if (!initial) setIsRefreshing(true);
      const res = await axios.get(`${API_URL}/company/${companyId}/overview`);
      setData({ ...res.data, loading: false });
      setLastUpdated(new Date());
    } catch (e) {
      console.error("❌ Failed to load company overview:", e);
      setData((p) => ({ ...p, loading: false }));
    } finally {
      setTimeout(() => setIsRefreshing(false), 450);
    }
  }

  const severityCounts = useMemo(() => {
    const logs = data?.fraudLogs || [];
    return logs.reduce(
      (acc, f) => {
        const sev = String(f.severity || "").toLowerCase();
        if (sev === "high") acc.high += 1;
        else if (sev === "medium") acc.medium += 1;
        else if (sev === "low") acc.low += 1;
        else acc.ok += 1;
        return acc;
      },
      {
        ok: Math.max(
          (data?.invoices?.length || 0) - (data?.fraudLogs?.length || 0),
          0
        ),
        low: 0,
        medium: 0,
        high: 0,
      }
    );
  }, [data]);

  const donut = useMemo(
    () => [
      { name: "OK", value: severityCounts.ok, color: VF.green },
      { name: "Low", value: severityCounts.low, color: VF.amber },
      {
        name: "Medium",
        value: Math.max(severityCounts.medium, 0),
        color: "#FDBA74",
      },
      { name: "High", value: severityCounts.high, color: VF.red },
    ],
    [severityCounts]
  );

  const revenueSeries = useMemo(() => {
    const src = data?.invoicesByMonth || [];
    return src.map((r) => ({
      month: new Date(r.month).toLocaleDateString("sv-SE", {
        year: "2-digit",
        month: "short",
      }),
      total: Number(r.total) || 0,
    }));
  }, [data?.invoicesByMonth]);

  const timeAgo =
    lastUpdated &&
    Math.max(0, Math.round((Date.now() - lastUpdated.getTime()) / 60000));

  if (data.loading) {
    return (
      <div className="p-6">
        <div className="h-9 w-64 bg-slate-200 rounded animate-pulse" />
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="h-28 rounded-xl border border-slate-200 bg-white shadow-sm animate-pulse"
            />
          ))}
        </div>
      </div>
    );
  }

  const totalInvoices = data?.invoices?.length || 0;
  const wrongInvoices = data?.fraudLogs?.length || 0;
  const totalAmount = Number(data?.totalAmount || 0);
  const avgRiskPct = Math.round(Number(data?.avgRisk || 0) * 100);
  const avgConfPct = Math.round(Number(data?.avgConfidence || 0));
  const hoursSaved = Math.round(totalInvoices * 0.35);
  const moneySaved = Math.max(
    Math.round(totalAmount * 0.006 + wrongInvoices * 0.7),
    0
  );

  return (
    <motion.div className="bg-slate-50 p-4 space-y-4" initial="hidden" animate="visible">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-slate-900">Företagsöversikt</h1>
          <p className="text-sm text-slate-600">
            Snabb hälsobild, AI-insikter och risk
          </p>
        </div>
        {lastUpdated && (
          <motion.div
            className="flex items-center gap-2 text-xs text-slate-500"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <span
              className={`h-2 w-2 rounded-full ${
                isRefreshing ? "bg-emerald-400 animate-pulse" : "bg-emerald-500"
              }`}
            />
            {isRefreshing
              ? "Uppdaterar…"
              : `Senast uppdaterad ${
                  timeAgo && timeAgo > 0 ? `${timeAgo} min sedan` : "nyss"
                }`}
          </motion.div>
        )}
      </div>

      {/* Insight panel */}
      <InsightPanel summary={data?.aiSummary} benchmark={data?.benchmark} />

      {/* KPI Grid */}
      <motion.section
        className="grid grid-cols-1 md:grid-cols-3 gap-3"
        variants={fadeUp}
      >
        <KpiCard
          title="Pengar sparade"
          value={`${moneySaved.toLocaleString("sv-SE")} kr`}
          sub={"+15 %"}
          gradient="from-emerald-600 to-emerald-400"
        />
        <KpiCard
          title="Felaktiga fakturor upptäckta"
          value={wrongInvoices}
          sub={`Genomsnittlig risk: ${avgRiskPct}%`}
          gradient="from-amber-500 to-orange-400"
        />
        <KpiCard
          title="AI-förtroende"
          value={`${avgConfPct}%`}
          sub={`${hoursSaved}h sparade`}
          gradient="from-indigo-600 to-blue-500"
        />
      </motion.section>

      {/* Charts + Risk */}
      <motion.section
        className="grid grid-cols-1 xl:grid-cols-3 gap-3"
        variants={fadeUp}
        custom={2}
      >
        <Card>
          <h3 className="font-semibold text-slate-800">Omsättning per månad</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={revenueSeries}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line
                type="monotone"
                dataKey="total"
                stroke={VF.cyan}
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <h3 className="font-semibold text-slate-800">Risköversikt</h3>
          <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie
                    data={donut}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={3}
                  >
                    {donut.map((d, i) => (
                      <Cell key={i} fill={d.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="text-sm text-slate-600 space-y-1">
              <RowStat label="Totalt fakturor" value={totalInvoices} />
              <RowStat label="Flaggade av AI" value={wrongInvoices} />
              <RowStat label="Hög risk" value={severityCounts.high} />
              <RowStat label="Medium risk" value={severityCounts.medium} />
              <RowStat label="Låg risk" value={severityCounts.low} />
            </div>
          </div>
        </Card>

        <BenchmarkCard benchmark={data?.benchmark} />
      </motion.section>

      {/* Alerts + Compliance/Integrations + Upsell */}
      <motion.section className="grid grid-cols-1 lg:grid-cols-3 gap-3" variants={fadeUp} custom={3}>
        <div className="lg:col-span-2 space-y-3">
          <AlertsFeed logs={data?.fraudLogs} />
          <AutomationImpact totalInvoices={totalInvoices} />
        </div>
        <div className="space-y-3">
          <CompliancePanel item={data?.compliance} />
          <IntegrationStatus items={data?.integrations} />
          <UpsellPanel />
        </div>
      </motion.section>
    </motion.div>
  );
}

/* ===================== Components ===================== */
function Card({ children }) {
  return (
    <motion.div
      variants={fadeUp}
      className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm transition-all duration-300"
      whileHover={{
        scale: 1.015,
        boxShadow: "0 10px 30px rgba(2,132,199,0.14)",
      }}
    >
      {children}
    </motion.div>
  );
}

function KpiCard({ title, value, sub, gradient }) {
  return (
    <motion.div
      variants={fadeUp}
      className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm transition-all duration-300 hover:shadow-md"
      whileHover={{
        scale: 1.02,
        boxShadow: "0 10px 28px rgba(2,132,199,0.12)",
      }}
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-slate-500">{title}</p>
          <p className="mt-0.5 text-xl font-semibold text-slate-900">{value}</p>
          {sub && <p className="mt-1 text-xs text-slate-500">{sub}</p>}
        </div>
        <div className={`h-9 w-9 rounded-lg bg-gradient-to-tr ${gradient}`} />
      </div>
    </motion.div>
  );
}

function RowStat({ label, value }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-slate-500">{label}</span>
      <span className="font-semibold text-slate-800">{value}</span>
    </div>
  );
}

function InsightPanel({ summary, benchmark }) {
  return (
    <Card>
      <div className="flex items-start justify-between">
        <h3 className="font-semibold text-slate-800">AI-analytiker</h3>
        {benchmark?.label && (
          <span className="rounded-md bg-slate-100 px-2 py-1 text-xs text-slate-700">
            {benchmark.label}
          </span>
        )}
      </div>
      <p className="mt-1 text-sm text-slate-600 min-h-[20px]">
        {summary || "Ingen AI-sammanfattning ännu – genereras efter första analyskörningen."}
      </p>
    </Card>
  );
}

function AlertsFeed({ logs = [] }) {
  return (
    <Card>
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-slate-800">Senaste varningar</h3>
      </div>
      <div className="mt-2 divide-y divide-slate-200">
        <AnimatePresence>
          {logs.slice(0, 6).map((l, i) => (
            <motion.div
              key={i}
              className="py-2 flex items-center justify-between"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
            >
              <div>
                <p className="text-sm font-medium text-slate-800">
                  {l.title || l.type || "Händelse"}
                </p>
                <p className="text-xs text-slate-500">
                  {l.message || l.description || "—"}
                </p>
              </div>
              <span className="h-2 w-2 rounded-full bg-slate-400" />
            </motion.div>
          ))}
          {logs.length === 0 && (
            <div className="py-4 text-sm text-slate-500">
              Inga varningar – allt ser bra ut! 🎉
            </div>
          )}
        </AnimatePresence>
      </div>
    </Card>
  );
}

function AutomationImpact({ totalInvoices }) {
  const autoPct = 73;
  const manualPct = 27;
  const series = [
    { n: "Auto", v: autoPct },
    { n: "Manuellt", v: manualPct },
  ];
  return (
    <Card>
      <h3 className="font-semibold text-slate-800">Automatiseringspåverkan</h3>
      <div className="mt-2 grid grid-cols-2 gap-3 text-sm">
        <div className="space-y-1">
          <p className="text-slate-500">Andel hanteras helt automatiskt</p>
          <p className="text-2xl font-semibold text-slate-800">{autoPct} %</p>
          <p className="text-slate-500">Totalt fakturor</p>
          <p className="text-2xl font-semibold text-slate-800">{totalInvoices}</p>
        </div>
        <div className="flex items-end">
          <div className="w-full">
            <ResponsiveContainer width="100%" height={90}>
              <BarChart data={series}>
                <XAxis dataKey="n" hide />
                <YAxis hide />
                <Bar dataKey="v" fill={VF.green} radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      <p className="mt-1 text-xs text-slate-500">
        IBAN-kontroller & regelmotor minskar manuellt arbete markant.
      </p>
    </Card>
  );
}

function CompliancePanel({ item }) {
  const status = item?.status || "OK";
  const lastSync = item?.lastSync ? new Date(item.lastSync) : null;
  return (
    <Card>
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-slate-800">Compliance & GDPR</h3>
        <span
          className={`h-2 w-2 rounded-full ${
            status === "OK" ? "bg-emerald-500" : "bg-amber-500"
          }`}
        />
      </div>
      <p className="mt-1 text-sm text-slate-600">
        AI-processer aktiva: Fakturaanalys, Riskbedömning, Prediktiva varningar
      </p>
      <p className="mt-1 text-xs text-slate-500">
        Senast synkad:{" "}
        {lastSync ? lastSync.toLocaleString("sv-SE") : "—"}
      </p>
    </Card>
  );
}

function IntegrationStatus({ items = [] }) {
  const list =
    items.length > 0
      ? items
      : [
          { name: "Fortnox", status: "active" },
          { name: "Visma", status: "auth_required" },
          { name: "Microsoft 365", status: "active" },
        ];
  return (
    <Card>
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-slate-800">Integrationer</h3>
      </div>
      <ul className="mt-2 divide-y divide-slate-200">
        {list.map((it, i) => (
          <li
            key={i}
            className="py-2 flex items-center justify-between text-sm"
          >
            <div className="flex items-center gap-2">
              <span
                className={`h-2 w-2 rounded-full ${
                  it.status === "active"
                    ? "bg-emerald-500"
                    : it.status === "auth_required"
                    ? "bg-amber-500"
                    : "bg-slate-400"
                }`}
              />
              <span className="text-slate-800">{it.name}</span>
            </div>
          </li>
        ))}
      </ul>
    </Card>
  );
}

function UpsellPanel() {
  return (
    <motion.div
      className="rounded-xl p-4 text-white bg-emerald-700 shadow-sm flex flex-col justify-between"
      variants={fadeUp}
      whileHover={{
        scale: 1.02,
        boxShadow: "0 10px 30px rgba(16,185,129,0.35)",
      }}
    >
      <div>
        <p className="text-sm opacity-90">Lås upp fördjupad AI-analys</p>
        <h3 className="mt-2 text-3xl font-extrabold">
          Prognos & Deep Fraud Scan
        </h3>
        <p className="text-sm opacity-90">Uppskattad besparing: +26%/mån</p>
      </div>
      <button className="mt-4 self-start rounded-md bg-white px-3 py-2 text-sm font-semibold text-emerald-700 hover:bg-emerald-50">
        Uppgradera till Pro →
      </button>
    </motion.div>
  );
}
