import React, { useState } from "react";
import {
  ChartBarIcon,
  UserGroupIcon,
  BuildingOfficeIcon,
  ExclamationTriangleIcon,
  ArrowTrendingUpIcon,
  DocumentArrowDownIcon,
  LightBulbIcon,
  ClockIcon,
} from "@heroicons/react/24/outline";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";

export default function BureauAnalytics() {
  const [tab, setTab] = useState("overview");

  const tabs = [
    { id: "overview", label: "Översikt" },
    { id: "customers", label: "Kunder" },
    { id: "team", label: "Team" },
    { id: "risk", label: "Risk & AI" },
  ];

  // 🔹 Unified Section Header with stronger styling
  const SectionHeader = ({ icon: Icon, title, subtitle, color = "emerald" }) => {
    const colorClasses = {
      emerald: "from-emerald-500 to-teal-500",
      slate: "from-slate-600 to-slate-800",
      blue: "from-sky-500 to-blue-600",
      orange: "from-orange-500 to-amber-600",
    };

    return (
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center text-white shadow-sm">
            <Icon className="w-5 h-5" />
          </div>
          <h2
            className={`text-2xl font-bold bg-gradient-to-r ${colorClasses[color]} bg-clip-text text-transparent tracking-tight`}
          >
            {title}
          </h2>
        </div>
        {subtitle && (
          <p className="text-slate-500 text-sm border-l-2 border-emerald-300 pl-3">
            {subtitle}
          </p>
        )}
      </div>
    );
  };

  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 via-white to-slate-100 min-h-screen">
      {/* 🧭 Page header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            Byråanalys
          </h1>
          <p className="text-slate-500 mt-1">
            Djupanalys av byråns prestanda, kunder och risker.
          </p>
        </div>
        <Button className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg px-4 py-2 flex items-center gap-2 shadow-sm">
          <DocumentArrowDownIcon className="w-5 h-5" />
          Exportera rapport
        </Button>
      </div>

      {/* 🔝 Tabs navigation */}
      <div className="flex gap-6 border-b border-slate-200 mb-8 sticky top-0 bg-gradient-to-br from-slate-50 via-white to-slate-100 z-10">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`pb-3 text-sm font-semibold transition-all ${
              tab === t.id
                ? "text-emerald-600 border-b-2 border-emerald-600"
                : "text-slate-500 hover:text-slate-700"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Animated content area */}
      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.3 }}
        >
          {/* 🌍 ÖVERSIKT */}
          {tab === "overview" && (
            <section>
              <SectionHeader
                icon={ChartBarIcon}
                title="Översikt"
                subtitle="Nyckeltal och effekt av automatisering."
                color="emerald"
              />

              <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-10">
                {[
                  {
                    title: "Totalt antal kunder",
                    value: "128",
                    icon: BuildingOfficeIcon,
                  },
                  {
                    title: "Aktiva användare",
                    value: "23",
                    icon: UserGroupIcon,
                  },
                  {
                    title: "Flaggade avvikelser",
                    value: "12",
                    icon: ExclamationTriangleIcon,
                  },
                  {
                    title: "Fakturavärde (30d)",
                    value: "1.2 Mkr",
                    icon: ChartBarIcon,
                  },
                  {
                    title: "Manuella arbetstimmar sparade",
                    value: "46 h",
                    icon: ClockIcon,
                  },
                ].map((item, i) => (
                  <motion.div
                    key={i}
                    whileHover={{ scale: 1.03 }}
                    transition={{ type: "spring", stiffness: 200 }}
                  >
                    <Card className="shadow-[0_2px_10px_rgba(0,0,0,0.04)] border border-slate-200 bg-white/80 backdrop-blur-sm">
                      <CardContent className="flex items-center justify-between p-5">
                        <div>
                          <p className="text-sm text-slate-500">{item.title}</p>
                          <h3 className="text-2xl font-semibold text-slate-800 mt-1">
                            {item.value}
                          </h3>
                        </div>
                        <item.icon className="w-9 h-9 text-emerald-500" />
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              <Card className="p-8 bg-white/70 border border-slate-200 shadow-sm backdrop-blur-sm">
                <h3 className="text-slate-700 font-semibold mb-3">
                  Aktivitet senaste 30 dagarna
                </h3>
                <div className="h-64 flex items-center justify-center text-slate-400">
                  [Line Chart: Fakturor hanterade över tid]
                </div>
              </Card>
            </section>
          )}

          {/* 🏢 KUNDER */}
          {tab === "customers" && (
            <section>
              <SectionHeader
                icon={BuildingOfficeIcon}
                title="Kundanalyser"
                subtitle="Analys av kundportföljen och risknivåer."
                color="blue"
              />

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="p-6 border-slate-200 bg-white/80 shadow-sm backdrop-blur-sm">
                  <h3 className="text-slate-700 font-semibold mb-3">
                    Topp 5 kunder (fakturavolym)
                  </h3>
                  <div className="h-56 flex items-center justify-center text-slate-400">
                    [Bar Chart]
                  </div>
                </Card>

                <Card className="p-6 border-slate-200 bg-white/80 shadow-sm backdrop-blur-sm">
                  <h3 className="text-slate-700 font-semibold mb-3">
                    Avvikelser per kund
                  </h3>
                  <div className="h-56 flex items-center justify-center text-slate-400">
                    [Pie Chart]
                  </div>
                </Card>

                <Card className="p-6 col-span-2 border-slate-200 bg-white/80 shadow-sm backdrop-blur-sm">
                  <h3 className="text-slate-700 font-semibold mb-3">
                    Kunder med ökande risktrend
                  </h3>
                  <div className="h-64 flex items-center justify-center text-slate-400">
                    [Risk Trend Chart]
                  </div>
                </Card>
              </div>
            </section>
          )}

          {/* 👥 TEAM */}
          {tab === "team" && (
            <section>
              <SectionHeader
                icon={UserGroupIcon}
                title="Teamprestanda"
                subtitle="Produktivitet och effektivitet hos byråns medarbetare."
                color="orange"
              />

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="p-6 bg-white/80 border-slate-200 shadow-sm backdrop-blur-sm">
                  <h3 className="text-slate-700 font-semibold mb-3">
                    Aktivitet per medarbetare
                  </h3>
                  <div className="h-56 flex items-center justify-center text-slate-400">
                    [Horizontal Bar Chart]
                  </div>
                </Card>

                <Card className="p-6 bg-white/80 border-slate-200 shadow-sm backdrop-blur-sm">
                  <h3 className="text-slate-700 font-semibold mb-3">
                    Effektivitet över tid
                  </h3>
                  <div className="h-56 flex items-center justify-center text-slate-400">
                    [Line Chart]
                  </div>
                </Card>
              </div>
            </section>
          )}

          {/* 🚨 RISK & AI */}
          {tab === "risk" && (
            <section>
              <SectionHeader
                icon={LightBulbIcon}
                title="Risk & AI-insikter"
                subtitle="Upptäck avvikelser och smarta rekommendationer."
                color="slate"
              />

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  {
                    title: "Ökad risk hos 3 kunder",
                    desc: "Kunder med fler flaggade transaktioner än genomsnittet.",
                    color: "bg-red-50 text-red-700 border-red-200",
                    icon: ExclamationTriangleIcon,
                  },
                  {
                    title: "Effektivitet ned 12 %",
                    desc: "Genomsnittlig hanteringstid ökar. Granska teamfördelning.",
                    color: "bg-yellow-50 text-yellow-700 border-yellow-200",
                    icon: ArrowTrendingUpIcon,
                  },
                  {
                    title: "AI-rekommendation",
                    desc: "Systemet föreslår optimering av kundflöde A för minskad väntetid.",
                    color: "bg-emerald-50 text-emerald-700 border-emerald-200",
                    icon: LightBulbIcon,
                  },
                ].map((insight, i) => (
                  <motion.div
                    key={i}
                    whileHover={{ y: -3 }}
                    transition={{ type: "spring", stiffness: 200 }}
                    className={`p-6 rounded-xl border shadow-sm ${insight.color}`}
                  >
                    <div className="flex items-start gap-3">
                      <insight.icon className="w-6 h-6 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold mb-1">{insight.title}</h4>
                        <p className="text-sm leading-snug">{insight.desc}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </section>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
