// src/pages/Home.jsx
import React, { useRef } from "react";
import { Link } from "react-router-dom";
import { motion, useScroll, useTransform } from "framer-motion";
import {
  ArrowRight,
  FileText,
  UploadCloud,
  Brain,
  ShieldCheck,
  CheckCircle2,
  Server,
} from "lucide-react";
import "../index.css";

// Valiflow tones
const VF_BLUE = "#0527FF";
const VF_BLUE_LIGHT = "#3B82F6";
const VF_GREEN = "#22C55E";
const VF_CYAN = "#38BDF8";

export default function Home() {
  // Scroll parallax for the horizontal pipeline
  const pipelineRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: pipelineRef,
    offset: ["start end", "end start"],
  });
  const x = useTransform(scrollYProgress, [0, 1], ["0%", "-40%"]); // smooth drift left

  const steps = [
    {
      title: "Faktura tas emot",
      desc: "PDF, e-faktura eller bild",
      icon: <FileText className="h-5 w-5 text-blue-600" />,
    },
    {
      title: "Ladda upp",
      desc: "Drag & drop eller e-post",
      icon: <UploadCloud className="h-5 w-5 text-emerald-600" />,
    },
    {
      title: "AI-skanning",
      desc: "Automatisk dataläsning",
      icon: <Brain className="h-5 w-5 text-sky-600" />,
    },
    {
      title: "Bedrägerikontroll",
      desc: "Riskflaggor & mönster",
      icon: <ShieldCheck className="h-5 w-5 text-amber-600" />,
    },
    {
      title: "Validering",
      desc: "Regler & toleranser",
      icon: <CheckCircle2 className="h-5 w-5 text-emerald-600" />,
    },
    {
      title: "Synk till ERP",
      desc: "Fortnox • Visma • BC",
      icon: <Server className="h-5 w-5 text-indigo-600" />,
    },
  ];

  return (
    <div className="min-h-screen bg-white text-slate-800 overflow-hidden">
     {/* NAVBAR */}
<nav className="fixed top-0 left-0 w-full bg-gradient-to-r from-blue-50/90 to-emerald-50/90 backdrop-blur-md border-b border-slate-200 z-50">
  <div className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
    <Link to="/" className="flex items-center gap-3">
    <img src="/valiflow-logo.png" alt="Valiflow logo" className="h-10 w-auto" />



      <span className="text-lg font-semibold text-slate-900">Valiflow</span>
    </Link>

    <div className="hidden md:flex items-center gap-8 text-slate-700 font-medium">
      <a href="#" className="hover:text-slate-900">Hem</a>
      <a href="#" className="hover:text-slate-900">Produkter</a>
      <a href="#" className="hover:text-slate-900">Priser</a>
      <a href="#" className="hover:text-slate-900">Säkerhet</a>
      <a href="#" className="hover:text-slate-900">FAQ</a>
    </div>

    <div className="flex items-center gap-3">
      <Link
        to="/login"
        className="rounded-full border border-blue-600/20 text-blue-600 hover:text-white hover:bg-blue-600 font-semibold px-5 py-2 transition"
      >
        Logga in
      </Link>
      <Link
        to="/signup"
        className="hidden sm:inline-flex items-center gap-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-semibold px-5 py-2 shadow-md transition"
      >
        Testa gratis <ArrowRight className="h-4 w-4" />
      </Link>
    </div>
  </div>
</nav>


      {/* HERO */}
      <header className="relative flex flex-col items-center justify-center text-center pt-48 pb-40 px-6">
        {/* Parallax gradient blobs */}
        <motion.div
          aria-hidden
          className="pointer-events-none absolute -top-32 -left-32 h-[400px] w-[400px] rounded-full blur-3xl opacity-30"
          style={{ background: `radial-gradient(closest-side, ${VF_BLUE} 0%, transparent 70%)` }}
          animate={{ y: [0, 20, 0] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        />
        <motion.div
          aria-hidden
          className="pointer-events-none absolute -bottom-24 -right-24 h-[420px] w-[420px] rounded-full blur-3xl opacity-30"
          style={{ background: `radial-gradient(closest-side, ${VF_GREEN} 0%, transparent 70%)` }}
          animate={{ y: [0, -15, 0] }}
          transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
        />

        {/* Glowing, pulsing lines + live pulse dots */}
        <svg
          className="absolute top-0 left-0 w-full h-full opacity-60"
          viewBox="0 0 1440 600"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Lines */}
          <motion.path
            id="vf-line-1"
            d="M-20 200 Q 360 120, 720 200 T 1440 200"
            stroke="url(#vf-blue)"
            strokeWidth="2"
            fill="none"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 6, repeat: Infinity, repeatType: "mirror" }}
          />
          <motion.path
            id="vf-line-2"
            d="M-20 280 Q 360 200, 720 280 T 1440 280"
            stroke="url(#vf-green)"
            strokeWidth="2"
            fill="none"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 8, repeat: Infinity, repeatType: "mirror" }}
          />
          <motion.path
            id="vf-line-3"
            d="M-20 360 Q 360 280, 720 360 T 1440 360"
            stroke="url(#vf-cyan)"
            strokeWidth="2"
            fill="none"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 10, repeat: Infinity, repeatType: "mirror" }}
          />

          {/* Live pulse dots moving along the paths (native SVG animateMotion) */}
          <g opacity="0.85">
            <circle r="4" fill={VF_BLUE_LIGHT}>
              <animateMotion
                dur="8s"
                repeatCount="indefinite"
                rotate="auto"
                keyPoints="0;1"
                keyTimes="0;1"
                path="M-20 200 Q 360 120, 720 200 T 1440 200"
              />
            </circle>
            <circle r="4" fill={VF_GREEN}>
              <animateMotion
                dur="9s"
                begin="1s"
                repeatCount="indefinite"
                rotate="auto"
                path="M-20 280 Q 360 200, 720 280 T 1440 280"
              />
            </circle>
            <circle r="4" fill={VF_CYAN}>
              <animateMotion
                dur="10s"
                begin="2s"
                repeatCount="indefinite"
                rotate="auto"
                path="M-20 360 Q 360 280, 720 360 T 1440 360"
              />
            </circle>
          </g>

          <defs>
            <linearGradient id="vf-blue" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor={VF_BLUE_LIGHT} stopOpacity="0.8" />
              <stop offset="100%" stopColor={VF_CYAN} stopOpacity="0.25" />
            </linearGradient>
            <linearGradient id="vf-green" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor={VF_GREEN} stopOpacity="0.8" />
              <stop offset="100%" stopColor="#A3E635" stopOpacity="0.25" />
            </linearGradient>
            <linearGradient id="vf-cyan" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#0EA5E9" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#CFFAFE" stopOpacity="0.25" />
            </linearGradient>
          </defs>
        </svg>

        {/* Headline + CTA */}
        <div className="relative z-10 max-w-3xl mx-auto">
          <motion.h1
            initial={{ opacity: 0, y: 16, filter: "blur(6px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="text-5xl sm:text-6xl font-bold leading-tight text-slate-900"
          >
            Automatiserad fakturakontroll –{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-emerald-400">
              innan du betalar.
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 12, filter: "blur(4px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            transition={{ delay: 0.15, duration: 0.6 }}
            className="mt-6 text-lg text-slate-600 max-w-2xl mx-auto"
          >
            Valiflow läser, analyserar och validerar varje leverantörsfaktura.
            Upptäck fel, stoppa bedrägerier och synka säkert till ditt ERP.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 10, filter: "blur(4px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            transition={{ delay: 0.25, duration: 0.6 }}
            className="mt-10 flex flex-wrap justify-center gap-4"
          >
            <Link
              to="/signup"
              className="px-8 py-4 rounded-full bg-gradient-to-r from-blue-600 to-emerald-400 text-white font-semibold shadow-lg hover:shadow-blue-400/30 transition flex items-center gap-2"
            >
              Testa gratis <ArrowRight className="h-5 w-5" />
            </Link>
            <a
              href="#how-it-works"
              className="px-8 py-4 rounded-full border border-slate-300 text-slate-700 font-semibold hover:bg-slate-50 transition"
            >
              Så fungerar det
            </a>
          </motion.div>

          <div className="mt-6 flex justify-center gap-6 text-sm text-slate-500">
            <span>🔒 GDPR-säkert</span>
            <span>🏦 Bankklassad kryptering</span>
          </div>
        </div>

        {/* SCROLL-ANIMATED PIPELINE */}
        <div
          ref={pipelineRef}
          className="relative z-10 mt-28 w-full max-w-7xl mx-auto overflow-hidden"
        >
          <motion.div style={{ x }} className="flex items-center gap-6 px-10 min-w-max">
            {steps.map((s, i) => (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                whileHover={{ scale: 1.045, translateY: -2 }}
                className="flex items-center gap-3 bg-white border border-slate-200 rounded-2xl shadow-sm px-6 py-4 min-w-[220px] hover:shadow-md transition"
              >
                <div className="h-9 w-9 grid place-items-center rounded-full bg-slate-100">
                  {s.icon}
                </div>
                <div className="text-left">
                  <p className="text-sm font-semibold text-slate-900">{s.title}</p>
                  <p className="text-xs text-slate-500">{s.desc}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </header>

      {/* INTEGRATIONS */}
      <section id="how-it-works" className="bg-slate-50 py-20 text-center">
        <h2 className="text-3xl font-semibold text-slate-900 mb-6">
          Integrerar med ditt ekonomisystem
        </h2>
        <p className="text-slate-600 mb-10">
          Inga nya system. Ingen utbildning. Bara tryggare betalningar.
        </p>
        <div className="flex flex-wrap justify-center gap-8 text-slate-700">
          {["Fortnox", "Visma", "Business Central", "Xero", "QuickBooks"].map((brand) => (
            <div
              key={brand}
              className="px-6 py-3 border border-slate-200 rounded-xl bg-white shadow-sm hover:shadow-md transition font-medium"
            >
              {brand}
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="bg-white py-24 text-center">
        <h2 className="text-3xl font-semibold text-slate-900 mb-12">
          Så här använder svenska företag Valiflow
        </h2>
        <div className="grid gap-8 md:grid-cols-3 max-w-6xl mx-auto px-6">
          {[
            {
              name: "Anna Sjöberg",
              title: "Redovisningskonsult, Ekonomihuset AB",
              quote:
                "Vi sparar flera timmar i veckan tack vare Valiflow. Verktyget har redan stoppat två falska fakturor – det har betalat sig själv.",
            },
            {
              name: "Johan Lindström",
              title: "CFO, Nordvent AB",
              quote:
                "Att integrera med Fortnox tog bara några minuter. Nu har vi full insyn i varje leverantör och riskflagga innan betalning sker.",
            },
            {
              name: "Maria Ek",
              title: "Ekonomiansvarig, SvenskTeknik",
              quote:
                "Enkel onboarding, tydliga riskindikatorer och fantastiskt stöd. Vi känner oss trygga med att inga felaktiga fakturor går igenom.",
            },
          ].map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="p-6 rounded-2xl bg-slate-50 border border-slate-200 shadow-sm text-left sm:text-center"
            >
              <p className="italic text-slate-700 mb-4">“{t.quote}”</p>
              <p className="font-semibold text-slate-900">{t.name}</p>
              <p className="text-slate-600 text-sm">{t.title}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-r from-blue-600 to-emerald-400 text-white text-center py-24 px-6">
        <h3 className="text-4xl font-bold mb-6">
          Skydda ditt företag mot felbetalningar – automatiskt.
        </h3>
        <p className="text-white/90 text-lg max-w-2xl mx-auto mb-10">
          Testa Valiflow gratis i 14 dagar. Ingen installation. Ingen bindningstid.
        </p>
        <Link
          to="/signup"
          className="inline-flex items-center gap-2 bg-white text-blue-600 font-semibold px-8 py-4 rounded-full text-lg hover:bg-slate-100 shadow-md"
        >
          Kom igång nu <ArrowRight className="h-5 w-5" />
        </Link>
      </section>

      {/* FOOTER */}
      <footer className="py-8 text-center text-sm text-slate-500 border-t border-slate-200">
        © {new Date().getFullYear()} Valiflow AB • Byggt i Sverige •{" "}
        <a href="#" className="underline hover:text-slate-700">Integritetspolicy</a>
      </footer>
    </div>
  );
}
