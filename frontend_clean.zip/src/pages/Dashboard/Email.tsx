import React, { useEffect, useState } from "react";
import {
  EnvelopeOpenIcon,
  CheckCircleIcon,
  ArrowPathIcon,
  ClockIcon,
  XMarkIcon,
  DocumentTextIcon,
  SparklesIcon,
} from "@heroicons/react/24/outline";
import { motion, AnimatePresence } from "framer-motion";
import { fetchEmails, EmailItem } from "../../services/emailService";

export default function Email() {
  const [emails, setEmails] = useState<EmailItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedEmail, setSelectedEmail] = useState<EmailItem | null>(null);

  useEffect(() => {
    async function loadEmails() {
      setLoading(true);
      try {
        const data = await fetchEmails();
        setEmails(data);
      } catch (error) {
        console.error("Error loading emails:", error);
      } finally {
        setLoading(false);
      }
    }

    loadEmails();
  }, []);

  const total = emails.length;
  const processed = emails.filter((e) => e.status === "processed").length;
  const pending = total - processed;

  return (
    <div className="relative min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950 p-8 overflow-hidden">
      <div className="max-w-6xl mx-auto">
        {/* --- HEADER --- */}
        <div className="flex items-center justify-between mb-8">
          <motion.h1
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-3xl font-semibold text-slate-800 dark:text-white"
          >
            📧 E-postinkorg
          </motion.h1>

          <button
            onClick={() => window.location.reload()}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition shadow-md"
          >
            <ArrowPathIcon className="w-5 h-5" />
            Uppdatera
          </button>
        </div>

        {/* --- SUMMARY CARDS --- */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10"
        >
          <SummaryCard
            title="Totalt antal mejl"
            value={total}
            icon={EnvelopeOpenIcon}
            color="from-blue-500 to-blue-700"
          />
          <SummaryCard
            title="Bearbetade"
            value={processed}
            icon={CheckCircleIcon}
            color="from-green-500 to-green-700"
          />
          <SummaryCard
            title="Väntande"
            value={pending}
            icon={ClockIcon}
            color="from-amber-400 to-orange-600"
          />
        </motion.div>

        {/* --- EMAIL TABLE --- */}
        {loading ? (
          <div className="flex justify-center items-center h-64 text-gray-500">
            <ArrowPathIcon className="w-6 h-6 mr-2 animate-spin text-blue-600" />
            Laddar e-post...
          </div>
        ) : total === 0 ? (
          <div className="flex justify-center items-center h-64 text-gray-500 dark:text-gray-400">
            Inga mejl har mottagits ännu.
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="backdrop-blur-md bg-white/70 dark:bg-slate-800/60 rounded-2xl shadow-lg border border-slate-200/40 dark:border-slate-700/40 overflow-hidden"
          >
            <table className="min-w-full text-sm">
              <thead className="bg-slate-100/60 dark:bg-slate-700/50">
                <tr>
                  {["Från", "Ämne", "Datum", "Status", ""].map((h) => (
                    <th
                      key={h}
                      className="px-6 py-3 text-left text-slate-600 dark:text-slate-300 font-medium"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {emails.map((email, index) => (
                  <motion.tr
                    key={email.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.04 }}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition cursor-pointer"
                  >
                    <td className="px-6 py-4 font-medium text-slate-800 dark:text-slate-200">
                      {email.from}
                    </td>
                    <td className="px-6 py-4 text-slate-700 dark:text-slate-300">
                      {email.subject}
                    </td>
                    <td className="px-6 py-4 text-slate-500 dark:text-slate-400">
                      {new Date(email.date).toLocaleString("sv-SE", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </td>
                    <td className="px-6 py-4">
                      {email.status === "processed" ? (
                        <span className="inline-flex items-center px-2 py-1 text-xs font-medium text-green-700 bg-green-100 rounded-md dark:bg-green-900/40 dark:text-green-300">
                          <CheckCircleIcon className="w-4 h-4 mr-1" />
                          Bearbetad
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-1 text-xs font-medium text-yellow-700 bg-yellow-100 rounded-md dark:bg-yellow-800/40 dark:text-yellow-200">
                          Väntar
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={() => setSelectedEmail(email)}
                        className="text-blue-600 dark:text-blue-400 hover:underline mr-3"
                      >
                        Visa
                      </button>
                      {email.status !== "processed" && (
                        <button
                          onClick={() =>
                            setEmails((prev) =>
                              prev.map((e) =>
                                e.id === email.id
                                  ? { ...e, status: "processed" }
                                  : e
                              )
                            )
                          }
                          className="text-green-600 dark:text-green-400 hover:underline"
                        >
                          Markera som bearbetad
                        </button>
                      )}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </motion.div>
        )}
      </div>

      {/* --- SLIDING PANEL --- */}
      <AnimatePresence>
        {selectedEmail && (
          <>
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.4 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black z-40"
              onClick={() => setSelectedEmail(null)}
            />
            {/* Right panel */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 250 }}
              className="fixed top-0 right-0 w-full sm:w-[450px] md:w-[550px] h-full bg-white dark:bg-slate-900 shadow-2xl z-50 flex flex-col"
            >
              <div className="flex justify-between items-center px-6 py-4 border-b border-slate-200 dark:border-slate-700">
                <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-100">
                  Mejlöversikt
                </h2>
                <button
                  onClick={() => setSelectedEmail(null)}
                  className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                >
                  <XMarkIcon className="w-6 h-6 text-slate-600 dark:text-slate-300" />
                </button>
              </div>

              {/* Mejl Detaljer */}
              <div className="p-6 overflow-y-auto">
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">
                  Från:
                </p>
                <p className="font-medium text-slate-800 dark:text-slate-100 mb-3">
                  {selectedEmail.from}
                </p>

                <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">
                  Ämne:
                </p>
                <p className="font-medium text-slate-800 dark:text-slate-100 mb-3">
                  {selectedEmail.subject}
                </p>

                <p className="text-sm text-slate-500 dark:text-slate-400 mb-1">
                  Datum:
                </p>
                <p className="font-medium text-slate-700 dark:text-slate-300 mb-6">
                  {new Date(selectedEmail.date).toLocaleString("sv-SE")}
                </p>

                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 mb-6">
                  <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                    {selectedEmail.body ||
                      "Det här mejlet innehåller ingen text. Möjligen en bifogad faktura eller pdf-fil."}
                  </p>
                </div>

                {/* --- AI ANALYS SEKTION --- */}
                <div className="bg-gradient-to-br from-blue-600 to-blue-800 text-white rounded-xl p-5 shadow-lg">
                  <div className="flex items-center gap-3 mb-2">
                    <SparklesIcon className="w-5 h-5" />
                    <h3 className="font-semibold text-lg">AI-insikt</h3>
                  </div>
                  <p className="text-sm opacity-90">
                    Analysen identifierar automatiskt fakturainnehåll,
                    leverantör och belopp.  
                    <br />
                    <span className="opacity-80">
                      (Kommer snart: automatisk fakturatolkning och
                      verifiering.)
                    </span>
                  </p>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

// --- Summary Card Component ---
function SummaryCard({
  title,
  value,
  icon: Icon,
  color,
}: {
  title: string;
  value: number;
  icon: any;
  color: string;
}) {
  return (
    <motion.div
      whileHover={{ y: -4, scale: 1.02 }}
      transition={{ duration: 0.2 }}
      className={`relative p-6 rounded-2xl bg-gradient-to-br ${color} text-white shadow-lg overflow-hidden`}
    >
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm opacity-80">{title}</p>
          <Icon className="w-6 h-6 opacity-90" />
        </div>
        <h2 className="text-2xl font-semibold">{value}</h2>
      </div>
      <div className="absolute inset-0 bg-white/10 blur-2xl opacity-20" />
    </motion.div>
  );
}
