import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  BuildingOfficeIcon,
  EnvelopeOpenIcon,
  CpuChipIcon,
  ArrowPathIcon,
  CheckCircleIcon,
  XCircleIcon,
  PuzzlePieceIcon, // ✅ Ny ikon här
} from "@heroicons/react/24/outline";
import {
  fetchIntegrations,
  connectIntegration,
  disconnectIntegration,
} from "@/services/integrationService";
import { toast } from "sonner";

export default function Integrations() {
  const [integrations, setIntegrations] = useState([]);
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const data = await fetchIntegrations();
      setIntegrations(data);
    } catch {
      toast.error("Kunde inte ladda integrationer.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 via-white to-slate-100 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 min-h-screen">
      <motion.div
        initial={{ opacity: 0, y: -15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mb-10"
      >
        <h1 className="text-3xl font-semibold text-slate-900 dark:text-white mb-2">
          🔌 Integrationer
        </h1>
        <p className="text-slate-600 dark:text-slate-400 max-w-2xl">
          Hantera anslutningar till ERP-system, e-post och AI-tjänster —
          allt på ett ställe för att maximera automation och kontroll.
        </p>
      </motion.div>

      {loading ? (
        <div className="flex justify-center py-16 text-slate-500">
          <ArrowPathIcon className="w-6 h-6 animate-spin mr-2" />
          Laddar integrationer...
        </div>
      ) : (
        <div className="space-y-14">
          <IntegrationSection
            title="📦 ERP-System"
            icon={BuildingOfficeIcon}
            items={integrations.filter((i) => i.category === "ERP")}
            onRefresh={load}
          />
          <IntegrationSection
            title="📧 E-postintegrationer"
            icon={EnvelopeOpenIcon}
            items={integrations.filter((i) => i.category === "Email")}
            onRefresh={load}
          />
          <IntegrationSection
            title="🧠 AI & Automation"
            icon={CpuChipIcon}
            items={integrations.filter((i) => i.category === "AI")}
            onRefresh={load}
          />
        </div>
      )}
    </div>
  );
}

function IntegrationSection({ title, icon: Icon, items, onRefresh }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-6"
    >
      <div className="flex items-center gap-2">
        <Icon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
        <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-100">
          {title}
        </h2>
      </div>

      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {items.map((intg) => (
          <IntegrationCard key={intg.id} integration={intg} onRefresh={onRefresh} />
        ))}
      </div>
    </motion.div>
  );
}

function IntegrationCard({ integration, onRefresh }) {
  const { id, name, description, status } = integration;
  const isConnected = status === "connected";

  async function handleConnect() {
    toast.loading("Ansluter...");
    try {
      await connectIntegration(id);
    } catch {
      toast.error("Kunde inte ansluta integrationen.");
    } finally {
      toast.dismiss();
    }
  }

  async function handleDisconnect() {
    try {
      await disconnectIntegration(id);
      toast.success(`${name} har kopplats från.`);
      onRefresh();
    } catch {
      toast.error("Kunde inte koppla från integrationen.");
    }
  }

  return (
    <motion.div
      whileHover={{
        scale: 1.03,
        boxShadow: isConnected
          ? "0px 8px 25px rgba(34,197,94,0.25)"
          : "0px 8px 25px rgba(59,130,246,0.2)",
      }}
      transition={{ duration: 0.25 }}
      className={`relative rounded-2xl p-6 shadow-lg border backdrop-blur-xl transition-all overflow-hidden
        ${
          isConnected
            ? "bg-gradient-to-br from-green-50/70 to-green-100/60 dark:from-green-900/20 dark:to-green-800/10 border-green-200 dark:border-green-700"
            : "bg-gradient-to-br from-white/70 to-slate-50/50 dark:from-slate-800/40 dark:to-slate-900/40 border-slate-200 dark:border-slate-700"
        }`}
    >
      {isConnected && (
        <div className="absolute top-0 right-0 w-1 h-full bg-green-400 rounded-r-xl shadow-md"></div>
      )}

      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <PuzzlePieceIcon className="w-5 h-5 text-slate-500 dark:text-slate-300" /> {/* ✅ ersatt CableIcon */}
          <h3 className="font-semibold text-slate-900 dark:text-white">{name}</h3>
        </div>
        {isConnected ? (
          <CheckCircleIcon className="w-5 h-5 text-green-500" />
        ) : (
          <XCircleIcon className="w-5 h-5 text-slate-400" />
        )}
      </div>

      <p className="text-sm text-slate-600 dark:text-slate-400 mb-5 min-h-[50px]">
        {description}
      </p>

      {isConnected ? (
        <button
          onClick={handleDisconnect}
          className="w-full py-2 text-sm font-medium text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-600 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 transition"
        >
          Koppla från
        </button>
      ) : (
        <button
          onClick={handleConnect}
          className="w-full py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md hover:shadow-blue-500/20 transition"
        >
          Anslut
        </button>
      )}
    </motion.div>
  );
}
