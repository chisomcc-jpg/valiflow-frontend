import React, { useState } from "react";
import {
  UserPlusIcon,
  TrashIcon,
  XCircleIcon,
  CheckCircleIcon,
  MagnifyingGlassIcon,
  FunnelIcon,
  BuildingOfficeIcon,
  UserGroupIcon,
} from "@heroicons/react/24/outline";
import { AnimatePresence, motion } from "framer-motion";
import { Tooltip } from "react-tooltip";
import { toast } from "sonner";

export default function BureauTeam() {
  const [query, setQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("Alla");
  const [statusFilter, setStatusFilter] = useState("Alla");

  const [team, setTeam] = useState([
    { id: 1, name: "Anna Karlsson", role: "Admin", email: "anna@byra.se", active: true, joined: "2024-01-12", customers: [] },
    { id: 2, name: "Jonas Berg", role: "Revisor", email: "jonas@byra.se", active: true, joined: "2024-03-05", customers: ["Nordbygg AB"] },
    { id: 3, name: "Sara Lind", role: "Assistent", email: "sara@byra.se", active: false, joined: "2024-06-18", customers: [] },
  ]);

  const customers = ["Nordbygg AB", "LjusDesign AB", "FastEkonomi AB", "ByggHuset AB", "Mäklarbolaget AB"];

  const [showModal, setShowModal] = useState(false);
  const [showPanel, setShowPanel] = useState(false);
  const [selectedRevisor, setSelectedRevisor] = useState(null);
  const [selectedCustomers, setSelectedCustomers] = useState([]);
  const [editing, setEditing] = useState(null); // id of row being edited
  const [editField, setEditField] = useState({ name: "", email: "", role: "" });

  const [newMember, setNewMember] = useState({ name: "", email: "", role: "Assistent" });

  // --- CRUD handlers -------------------------------------------------
  const handleAdd = () => {
    if (!newMember.name || !newMember.email) return;
    const id = team.length + 1;
    setTeam([...team, { ...newMember, id, active: true, joined: new Date().toISOString().split("T")[0], customers: [] }]);
    toast.success("Ny användare tillagd!");
    setNewMember({ name: "", email: "", role: "Assistent" });
    setShowModal(false);
  };

  const toggleActive = (id) =>
    setTeam(team.map((m) => (m.id === id ? { ...m, active: !m.active } : m)));

  const removeMember = (id) => {
    setTeam(team.filter((m) => m.id !== id));
    toast.success("Användaren har tagits bort.");
  };

  const handleAssignCustomers = () => {
    if (!selectedRevisor) return;
    setTeam(
      team.map((m) =>
        m.id === selectedRevisor.id
          ? { ...m, customers: [...new Set([...m.customers, ...selectedCustomers])] }
          : m
      )
    );
    setSelectedCustomers([]);
    setShowPanel(false);
    toast.success("Kunder tilldelade framgångsrikt!");
  };

  // --- Inline editing ------------------------------------------------
  const startEdit = (member) => {
    setEditing(member.id);
    setEditField({ name: member.name, email: member.email, role: member.role });
  };

  const saveEdit = (id) => {
    setTeam(
      team.map((m) =>
        m.id === id ? { ...m, ...editField } : m
      )
    );
    setEditing(null);
    toast.success("Ändringar sparade");
  };

  // --- Filtering -----------------------------------------------------
  const filteredTeam = team.filter((m) => {
    const matchesQuery =
      m.name.toLowerCase().includes(query.toLowerCase()) ||
      m.email.toLowerCase().includes(query.toLowerCase()) ||
      m.role.toLowerCase().includes(query.toLowerCase());

    const matchesRole = roleFilter === "Alla" || m.role === roleFilter;
    const matchesStatus =
      statusFilter === "Alla" ||
      (statusFilter === "Aktiv" && m.active) ||
      (statusFilter === "Inaktiv" && !m.active);

    return matchesQuery && matchesRole && matchesStatus;
  });

  return (
    <div className="p-8 bg-gray-100 min-h-screen">
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-800 flex items-center gap-2">
            <UserGroupIcon className="w-6 h-6 text-blue-600" />
            Team & Roller
          </h1>
          <p className="text-gray-500">
            Hantera användare, roller och kundtilldelningar för din byrå.
          </p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition shadow-sm"
        >
          <UserPlusIcon className="w-5 h-5" />
          Ny användare
        </button>
      </div>

      {/* QUICK STATS */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        <StatCard label="Totalt team" value={team.length} />
        <StatCard label="Aktiva användare" value={team.filter((m) => m.active).length} color="text-blue-600" />
        <StatCard label="Revisorer" value={team.filter((m) => m.role === 'Revisor').length} color="text-blue-600" />
        <StatCard label="Kundtilldelningar" value={team.reduce((a, m) => a + m.customers.length, 0)} />
      </div>

      {/* SEARCH + FILTERS */}
      <div className="flex flex-wrap gap-3 items-center mb-6">
        <div className="relative w-full sm:w-64">
          <MagnifyingGlassIcon className="w-5 h-5 absolute left-3 top-2.5 text-gray-400" />
          <input
            type="text"
            placeholder="Sök användare..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-10 pr-3 py-2 w-full border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 outline-none text-sm text-gray-700"
          />
        </div>
        <div className="flex items-center gap-2">
          <FunnelIcon className="w-5 h-5 text-gray-400" />
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="border border-gray-300 rounded-lg px-2 py-2 text-sm bg-white text-gray-700 focus:ring-2 focus:ring-blue-500 outline-none"
          >
            <option>Alla</option>
            <option>Admin</option>
            <option>Revisor</option>
            <option>Assistent</option>
          </select>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="border border-gray-300 rounded-lg px-2 py-2 text-sm bg-white text-gray-700 focus:ring-2 focus:ring-blue-500 outline-none"
          >
            <option>Alla</option>
            <option>Aktiv</option>
            <option>Inaktiv</option>
          </select>
        </div>
      </div>

      {/* TEAM TABLE */}
      <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50 sticky top-0">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Användare</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Roll</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Kunder</th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Status</th>
              <th className="px-6 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Åtgärder</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filteredTeam.map((member) => (
              <tr key={member.id} className="hover:bg-gray-50 transition">
                {/* USER */}
                <td
                  className="px-6 py-3 flex items-center gap-3 cursor-text"
                  onDoubleClick={() => startEdit(member)}
                >
                  <div className="w-8 h-8 flex items-center justify-center rounded-full bg-blue-100 text-blue-700 font-semibold">
                    {member.name.charAt(0)}
                  </div>
                  <div>
                    {editing === member.id ? (
                      <input
                        value={editField.name}
                        onChange={(e) => setEditField({ ...editField, name: e.target.value })}
                        className="text-sm border rounded px-1 py-0.5"
                      />
                    ) : (
                      <p className="font-medium text-gray-800">{member.name}</p>
                    )}
                    {editing === member.id ? (
                      <input
                        value={editField.email}
                        onChange={(e) => setEditField({ ...editField, email: e.target.value })}
                        className="text-xs border rounded px-1 py-0.5 mt-1 w-48"
                      />
                    ) : (
                      <p className="text-xs text-gray-500">{member.email}</p>
                    )}
                  </div>
                </td>

                {/* ROLE */}
                <td className="px-6 py-3 cursor-text">
                  {editing === member.id ? (
                    <select
                      value={editField.role}
                      onChange={(e) => setEditField({ ...editField, role: e.target.value })}
                      className="border border-gray-300 rounded-md text-sm text-gray-700 bg-gray-50 px-2 py-1 focus:ring-1 focus:ring-blue-500 outline-none"
                    >
                      <option>Admin</option>
                      <option>Revisor</option>
                      <option>Assistent</option>
                    </select>
                  ) : (
                    <span
                      className={`inline-flex px-2 py-1 text-xs rounded-full font-medium ${
                        member.role === "Admin"
                          ? "bg-blue-100 text-blue-700"
                          : member.role === "Revisor"
                          ? "bg-emerald-100 text-emerald-700"
                          : "bg-gray-100 text-gray-600"
                      }`}
                    >
                      {member.role}
                    </span>
                  )}
                </td>

                {/* CUSTOMERS */}
                <td className="px-6 py-3 text-gray-600 text-sm">
                  {member.customers.length > 0 ? member.customers.join(", ") : <span className="text-gray-400">Inga</span>}
                </td>

                {/* STATUS */}
                <td className="px-6 py-3">
                  <button
                    onClick={() => toggleActive(member.id)}
                    className={`flex items-center gap-1 text-sm font-medium ${
                      member.active ? "text-blue-600" : "text-gray-400"
                    }`}
                  >
                    {member.active ? (
                      <>
                        <CheckCircleIcon className="w-4 h-4" /> Aktiv
                      </>
                    ) : (
                      <>
                        <XCircleIcon className="w-4 h-4" /> Inaktiv
                      </>
                    )}
                  </button>
                </td>

                {/* ACTIONS */}
                <td className="px-6 py-3 text-right flex justify-end gap-3">
                  {editing === member.id ? (
                    <button
                      onClick={() => saveEdit(member.id)}
                      className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                    >
                      Spara
                    </button>
                  ) : (
                    member.role === "Revisor" && (
                      <button
                        onClick={() => {
                          setSelectedRevisor(member);
                          setSelectedCustomers(member.customers);
                          setShowPanel(true);
                        }}
                        className="text-blue-600 hover:text-blue-800 flex items-center gap-1 text-sm"
                      >
                        <BuildingOfficeIcon className="w-4 h-4" />
                        Tilldela
                      </button>
                    )
                  )}
                  <button
                    onClick={() => removeMember(member.id)}
                    className="text-red-500 hover:text-red-700 transition"
                  >
                    <TrashIcon className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredTeam.length === 0 && (
          <div className="p-6 text-center text-gray-500 text-sm">Inga användare matchar dina filter.</div>
        )}
      </div>

      {/* ADD USER MODAL */}
      <AnimatePresence>
        {showModal && (
          <motion.div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <motion.div
              className="bg-white rounded-2xl p-6 shadow-xl w-full max-w-md"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
            >
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Lägg till ny användare</h2>
              <div className="space-y-3">
                <input type="text" placeholder="Namn"
                  value={newMember.name} onChange={(e) => setNewMember({ ...newMember, name: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none" />
                <input type="email" placeholder="E-postadress"
                  value={newMember.email} onChange={(e) => setNewMember({ ...newMember, email: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none" />
                <select value={newMember.role}
                  onChange={(e) => setNewMember({ ...newMember, role: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none">
                  <option>Assistent</option>
                  <option>Revisor</option>
                  <option>Admin</option>
                </select>
              </div>
              <div className="mt-6 flex justify-end gap-3">
                <button onClick={() => setShowModal(false)} className="px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-100 transition">Avbryt</button>
                <button onClick={handleAdd} className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition">Lägg till</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* RIGHT PANEL (CUSTOMER ASSIGN) */}
      <AnimatePresence>
        {showPanel && selectedRevisor && (
          <motion.div
            className="fixed top-0 right-0 w-full sm:w-[420px] h-full bg-white shadow-xl border-l border-gray-200 p-6 z-50"
            initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold text-gray-800">
                Tilldela kunder till {selectedRevisor.name}
              </h2>
              <button onClick={() => setShowPanel(false)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>
            <p className="text-sm text-gray-500 mb-4">Välj vilka kunder revisorn ska ansvara för.</p>
            <div className="space-y-2 overflow-y-auto max-h-[70vh] pr-2">
              {customers.map((cust) => (
                <label key={cust} className="flex items-center gap-2 text-gray-700 text-sm">
                  <input
                    type="checkbox"
                    checked={selectedCustomers.includes(cust)}
                    onChange={(e) =>
                      e.target.checked
                        ? setSelectedCustomers([...selectedCustomers, cust])
                        : setSelectedCustomers(selectedCustomers.filter((c) => c !== cust))
                    }
                  />
                  {cust}
                </label>
              ))}
            </div>
            <div className="flex justify-end mt-6 gap-3">
              <button onClick={() => setShowPanel(false)} className="px-4 py-2 rounded-lg text-gray-600 hover:bg-gray-100 transition">Avbryt</button>
              <button onClick={handleAssignCustomers} className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition">Spara</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// small stat component
function StatCard({ label, value, color = "text-gray-800" }) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-200">
      <p className="text-sm text-gray-500">{label}</p>
      <p className={`text-xl font-semibold ${color}`}>{value}</p>
    </div>
  );
}
