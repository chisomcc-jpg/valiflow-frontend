import React, { useMemo, useState } from "react";
import {
  UserPlusIcon,
  TrashIcon,
  XCircleIcon,
  CheckCircleIcon,
  MagnifyingGlassIcon,
  FunnelIcon,
  BuildingOfficeIcon,
  UserGroupIcon,
  ArrowDownTrayIcon,
  EllipsisHorizontalIcon,
  KeyIcon,
  ShieldCheckIcon,
} from "@heroicons/react/24/outline";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "sonner";

/* =========================================================================
   BureauTeamPro – Ledande SaaS-nivå för teamhantering (Valiflow-stil)
   - Smart filter & stats
   - Inline-edit
   - Invite-modal (rollval)
   - Högerpanel med detaljer & kundtilldelning
   - CSV-export
   - 2FA & Senast aktiv
   ========================================================================= */

type Role = "Admin" | "Revisor" | "Analytiker" | "Assistent";

type Member = {
  id: number;
  name: string;
  email: string;
  role: Role;
  active: boolean;
  joined: string; // ISO date
  lastActive?: string; // ISO date
  customers: string[];
  mfaEnabled?: boolean;
};

// --- Mock data (byt mot API) ------------------------------------------------
const INITIAL_TEAM: Member[] = [
  {
    id: 1,
    name: "Anna Karlsson",
    role: "Admin",
    email: "anna@byra.se",
    active: true,
    joined: "2024-01-12",
    lastActive: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(), // 5h sedan
    customers: ["Nordbygg AB", "ByggHuset AB", "LjusDesign AB"],
    mfaEnabled: true,
  },
  {
    id: 2,
    name: "Jonas Berg",
    role: "Revisor",
    email: "jonas@byra.se",
    active: true,
    joined: "2024-03-05",
    lastActive: new Date(Date.now() - 1000 * 60 * 60 * 30).toISOString(), // 30h sedan
    customers: ["Nordbygg AB"],
    mfaEnabled: true,
  },
  {
    id: 3,
    name: "Sara Lind",
    role: "Assistent",
    email: "sara@byra.se",
    active: false,
    joined: "2024-06-18",
    lastActive: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString(), // 7d sedan
    customers: [],
    mfaEnabled: false,
  },
  {
    id: 4,
    name: "Omar Nilsson",
    role: "Analytiker",
    email: "omar@byra.se",
    active: true,
    joined: "2025-01-10",
    lastActive: new Date(Date.now() - 1000 * 60 * 50).toISOString(), // 50m sedan
    customers: ["Mäklarbolaget AB", "FastEkonomi AB", "LjusDesign AB", "Nordbygg AB"],
    mfaEnabled: true,
  },
];

const ALL_CUSTOMERS = [
  "Nordbygg AB",
  "LjusDesign AB",
  "FastEkonomi AB",
  "ByggHuset AB",
  "Mäklarbolaget AB",
  "ElektronikPartner AB",
];

export default function BureauTeamPro() {
  // ---------------- State ----------------
  const [team, setTeam] = useState<Member[]>(INITIAL_TEAM);
  const [query, setQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<"Alla" | Role>("Alla");
  const [statusFilter, setStatusFilter] = useState<"Alla" | "Aktiv" | "Inaktiv">("Alla");
  const [minCustomerCount, setMinCustomerCount] = useState<number>(0);

  const [showInvite, setShowInvite] = useState(false);
  const [inviteData, setInviteData] = useState<{ name: string; email: string; role: Role }>({
    name: "",
    email: "",
    role: "Assistent",
  });

  const [editing, setEditing] = useState<number | null>(null);
  const [editField, setEditField] = useState<{ name: string; email: string; role: Role }>({
    name: "",
    email: "",
    role: "Assistent",
  });

  const [showPanel, setShowPanel] = useState(false);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [panelCustomers, setPanelCustomers] = useState<string[]>([]);

  // ---------------- Derived ----------------
  const filteredTeam = useMemo(() => {
    return team.filter((m) => {
      const matchesQuery =
        !query ||
        m.name.toLowerCase().includes(query.toLowerCase()) ||
        m.email.toLowerCase().includes(query.toLowerCase()) ||
        m.role.toLowerCase().includes(query.toLowerCase());

      const matchesRole = roleFilter === "Alla" || m.role === roleFilter;
      const matchesStatus =
        statusFilter === "Alla" ||
        (statusFilter === "Aktiv" && m.active) ||
        (statusFilter === "Inaktiv" && !m.active);

      const matchesMinCustomers = m.customers.length >= (minCustomerCount || 0);

      return matchesQuery && matchesRole && matchesStatus && matchesMinCustomers;
    });
  }, [team, query, roleFilter, statusFilter, minCustomerCount]);

  // ---------------- Actions ----------------
  const openInvite = () => setShowInvite(true);

  const inviteMember = () => {
    if (!inviteData.name || !inviteData.email) {
      toast.error("Fyll i namn och e-post.");
      return;
    }
    const id = team.length ? Math.max(...team.map((m) => m.id)) + 1 : 1;
    const newMember: Member = {
      id,
      name: inviteData.name,
      email: inviteData.email,
      role: inviteData.role,
      active: true,
      joined: new Date().toISOString().split("T")[0],
      lastActive: new Date().toISOString(),
      customers: [],
      mfaEnabled: false,
    };
    setTeam([newMember, ...team]);
    toast.success("Inbjudan skickad (mock).");
    setInviteData({ name: "", email: "", role: "Assistent" });
    setShowInvite(false);
  };

  const startEdit = (m: Member) => {
    setEditing(m.id);
    setEditField({ name: m.name, email: m.email, role: m.role });
  };

  const saveEdit = (id: number) => {
    setTeam((prev) => prev.map((m) => (m.id === id ? { ...m, ...editField } : m)));
    setEditing(null);
    toast.success("Ändringar sparade");
  };

  const toggleActive = (id: number) => {
    setTeam((prev) => prev.map((m) => (m.id === id ? { ...m, active: !m.active } : m)));
  };

  const removeMember = (id: number) => {
    setTeam((prev) => prev.filter((m) => m.id !== id));
    toast.success("Användaren har tagits bort.");
  };

  const openPanel = (m: Member) => {
    setSelectedMember(m);
    setPanelCustomers(m.customers);
    setShowPanel(true);
  };

  const savePanel = () => {
    if (!selectedMember) return;
    setTeam((prev) => prev.map((m) => (m.id === selectedMember.id ? { ...m, customers: panelCustomers } : m)));
    toast.success("Kunder uppdaterade.");
    setShowPanel(false);
  };

  const toggleMFA = (id: number) => {
    setTeam((prev) => prev.map((m) => (m.id === id ? { ...m, mfaEnabled: !m.mfaEnabled } : m)));
    toast.success("2FA-inställning uppdaterad.");
  };

  const exportCSV = () => {
    const headers = ["Namn", "E-post", "Roll", "Status", "Kunder", "Senast aktiv", "2FA", "Gick med"];
    const rows = team.map((m) => [
      m.name,
      m.email,
      m.role,
      m.active ? "Aktiv" : "Inaktiv",
      m.customers.join("; "),
      m.lastActive ? timeAgo(m.lastActive) : "-",
      m.mfaEnabled ? "Aktiv" : "Av",
      m.joined,
    ]);

    const csv = [headers, ...rows].map((r) => r.map(escapeCSV).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `valiflow-team-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // ---------------- Stats ----------------
  const total = team.length;
  const activeCount = team.filter((m) => m.active).length;
  const revisors = team.filter((m) => m.role === "Revisor").length;
  const assignments = team.reduce((a, m) => a + m.customers.length, 0);

  // AI-liknande snabb-sammanfattning (statisk copy nu)
  const summary = `Teamet har ${activeCount} aktiva av ${total} totala. ${revisors} revisorer ansvarar för ${assignments} kundtilldelningar.`;

  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 via-white to-slate-100 min-h-screen">
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-2">
            <UserGroupIcon className="w-7 h-7 text-emerald-600" />
            Team & Roller
          </h1>
          <p className="text-slate-500">
            Hantera användare, roller, kundtilldelningar och säkerhet för din byrå.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={exportCSV}
            className="flex items-center gap-2 border border-slate-200 text-slate-700 px-4 py-2 rounded-lg hover:bg-slate-50 transition shadow-sm"
          >
            <ArrowDownTrayIcon className="w-5 h-5" />
            Exportera CSV
          </button>
          <button
            onClick={openInvite}
            className="flex items-center gap-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition shadow-sm"
          >
            <UserPlusIcon className="w-5 h-5" />
            Bjud in
          </button>
        </div>
      </div>

      {/* QUICK STATS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Totalt team" value={total} />
        <StatCard label="Aktiva användare" value={activeCount} accent />
        <StatCard label="Revisorer" value={revisors} />
        <StatCard label="Kundtilldelningar" value={assignments} />
      </div>

      {/* AI Summary */}
      <div className="mb-6">
        <div className="bg-white/80 border border-emerald-100 rounded-xl p-4 shadow-sm">
          <p className="text-sm text-slate-700">
            <span className="font-medium text-emerald-700">Översikt:</span> {summary}
          </p>
        </div>
      </div>

      {/* SEARCH + FILTERS */}
      <div className="flex flex-wrap gap-3 items-center mb-6">
        <div className="relative w-full sm:w-72">
          <MagnifyingGlassIcon className="w-5 h-5 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Sök namn, e-post eller roll…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-10 pr-3 py-2 w-full border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-emerald-500 outline-none text-sm text-slate-700"
          />
        </div>

        <div className="flex items-center gap-2">
          <FunnelIcon className="w-5 h-5 text-slate-400" />
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value as any)}
            className="border border-slate-300 rounded-lg px-2 py-2 text-sm bg-white text-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none"
          >
            <option>Alla</option>
            <option>Admin</option>
            <option>Revisor</option>
            <option>Analytiker</option>
            <option>Assistent</option>
          </select>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="border border-slate-300 rounded-lg px-2 py-2 text-sm bg-white text-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none"
          >
            <option>Alla</option>
            <option>Aktiv</option>
            <option>Inaktiv</option>
          </select>
          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-600">Min. kunder</span>
            <input
              type="number"
              min={0}
              value={minCustomerCount}
              onChange={(e) => setMinCustomerCount(Number(e.target.value || 0))}
              className="w-20 border border-slate-300 rounded-lg px-2 py-2 text-sm bg-white text-slate-700 focus:ring-2 focus:ring-emerald-500 outline-none"
            />
          </div>
          <span className="text-sm text-slate-500">
            {filteredTeam.length} träffar av {team.length}
          </span>
        </div>
      </div>

      {/* TEAM TABLE */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        <table className="min-w-full divide-y divide-slate-200">
          <thead className="bg-slate-50">
            <tr>
              <Th>Användare</Th>
              <Th>Roll</Th>
              <Th>Kunder</Th>
              <Th>Senast aktiv</Th>
              <Th>2FA</Th>
              <Th>Status</Th>
              <Th right>Åtgärder</Th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredTeam.map((m) => (
              <tr key={m.id} className="hover:bg-slate-50 transition">
                {/* USER */}
                <td className="px-6 py-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 flex items-center justify-center rounded-full bg-emerald-50 text-emerald-700 font-semibold">
                      {initials(m.name)}
                    </div>
                    <div onDoubleClick={() => startEdit(m)} className="cursor-text">
                      {editing === m.id ? (
                        <>
                          <input
                            value={editField.name}
                            onChange={(e) => setEditField({ ...editField, name: e.target.value })}
                            className="text-sm border rounded px-1 py-0.5"
                          />
                          <div className="mt-1">
                            <input
                              value={editField.email}
                              onChange={(e) => setEditField({ ...editField, email: e.target.value })}
                              className="text-xs border rounded px-1 py-0.5 w-56"
                            />
                          </div>
                        </>
                      ) : (
                        <>
                          <p className="font-medium text-slate-800">{m.name}</p>
                          <p className="text-xs text-slate-500">{m.email}</p>
                        </>
                      )}
                    </div>
                  </div>
                </td>

                {/* ROLE */}
                <td className="px-6 py-3">
                  {editing === m.id ? (
                    <select
                      value={editField.role}
                      onChange={(e) => setEditField({ ...editField, role: e.target.value as Role })}
                      className="border border-slate-300 rounded-md text-sm text-slate-700 bg-slate-50 px-2 py-1 focus:ring-1 focus:ring-emerald-500 outline-none"
                    >
                      <option>Admin</option>
                      <option>Revisor</option>
                      <option>Analytiker</option>
                      <option>Assistent</option>
                    </select>
                  ) : (
                    <RoleBadge role={m.role} />
                  )}
                </td>

                {/* CUSTOMERS */}
                <td className="px-6 py-3 text-slate-700 text-sm">
                  {m.customers.length > 0 ? (
                    <button
                      onClick={() => openPanel(m)}
                      className="underline underline-offset-2 hover:text-emerald-700"
                      title="Visa & redigera tilldelning"
                    >
                      {m.customers.length} tilldelad{m.customers.length > 1 ? "e" : ""} kund
                      {m.customers.length > 1 ? "er" : ""}
                    </button>
                  ) : (
                    <span className="text-slate-400">Inga</span>
                  )}
                </td>

                {/* LAST ACTIVE */}
                <td className="px-6 py-3 text-sm text-slate-600">
                  {m.lastActive ? timeAgo(m.lastActive) : "–"}
                </td>

                {/* 2FA */}
                <td className="px-6 py-3">
                  <button
                    onClick={() => toggleMFA(m.id)}
                    className={`inline-flex items-center gap-1 text-sm ${
                      m.mfaEnabled ? "text-emerald-700" : "text-slate-400"
                    }`}
                    title={m.mfaEnabled ? "2FA är aktiv" : "2FA är av"}
                  >
                    <KeyIcon className="w-4 h-4" />
                    {m.mfaEnabled ? "Aktiv" : "Av"}
                  </button>
                </td>

                {/* STATUS */}
                <td className="px-6 py-3">
                  <button
                    onClick={() => toggleActive(m.id)}
                    className={`flex items-center gap-1 text-sm font-medium ${
                      m.active ? "text-emerald-700" : "text-slate-400"
                    }`}
                  >
                    {m.active ? (
                      <>
                        <CheckCircleIcon className="w-4 h-4" /> Aktiv
                      </>
                    ) : (
                      <>
                        <XCircleIcon className="w-4 h-4" /> Inaktiv
                      </>
                    )}
                  </button>
                </td>

                {/* ACTIONS */}
                <td className="px-6 py-3">
                  <div className="flex items-center justify-end gap-3">
                    {editing === m.id ? (
                      <button
                        onClick={() => saveEdit(m.id)}
                        className="text-emerald-700 hover:text-emerald-900 text-sm font-medium"
                      >
                        Spara
                      </button>
                    ) : (
                      <>
                        <button
                          onClick={() => startEdit(m)}
                          className="text-slate-500 hover:text-slate-700 transition"
                          title="Redigera"
                        >
                          <EllipsisHorizontalIcon className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() => openPanel(m)}
                          className="text-emerald-700 hover:text-emerald-900 transition flex items-center gap-1 text-sm"
                        >
                          <BuildingOfficeIcon className="w-4 h-4" />
                          Tilldela
                        </button>
                        <button
                          onClick={() => removeMember(m.id)}
                          className="text-rose-500 hover:text-rose-700 transition"
                          title="Ta bort"
                        >
                          <TrashIcon className="w-5 h-5" />
                        </button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
            {filteredTeam.length === 0 && (
              <tr>
                <td colSpan={7} className="p-6 text-center text-slate-500 text-sm">
                  Inga användare matchar dina filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* INVITE MODAL */}
      <AnimatePresence>
        {showInvite && (
          <motion.div
            className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          >
            <motion.div
              className="bg-white rounded-2xl p-6 shadow-xl w-full max-w-md border border-slate-200"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
            >
              <h2 className="text-xl font-semibold text-slate-900 mb-2">Bjud in ny medlem</h2>
              <p className="text-sm text-slate-500 mb-4">Skapar en CompanyInvite och skickar e-post (mock).</p>
              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Namn"
                  value={inviteData.name}
                  onChange={(e) => setInviteData({ ...inviteData, name: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500 outline-none"
                />
                <input
                  type="email"
                  placeholder="E-postadress"
                  value={inviteData.email}
                  onChange={(e) => setInviteData({ ...inviteData, email: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500 outline-none"
                />
                <select
                  value={inviteData.role}
                  onChange={(e) => setInviteData({ ...inviteData, role: e.target.value as Role })}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-emerald-500 outline-none bg-white"
                >
                  <option>Assistent</option>
                  <option>Analytiker</option>
                  <option>Revisor</option>
                  <option>Admin</option>
                </select>
              </div>
              <div className="mt-6 flex justify-between items-center">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <ShieldCheckIcon className="w-4 h-4" />
                  En inbjudan kan kräva BankID vid första inloggning.
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowInvite(false)}
                    className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 transition"
                  >
                    Avbryt
                  </button>
                  <button
                    onClick={inviteMember}
                    className="px-4 py-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition"
                  >
                    Skicka inbjudan
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* RIGHT PANEL – MEMBER DETAILS & CUSTOMER ASSIGN */}
      <AnimatePresence>
        {showPanel && selectedMember && (
          <motion.div
            className="fixed top-0 right-0 w-full sm:w-[460px] h-full bg-white shadow-2xl border-l border-slate-200 z-50"
            initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
          >
            <div className="p-6 flex items-start justify-between border-b border-slate-100">
              <div>
                <h3 className="text-lg font-semibold text-slate-900">{selectedMember.name}</h3>
                <p className="text-sm text-slate-500">{selectedMember.email}</p>
                <div className="mt-2 flex items-center gap-2">
                  <RoleBadge role={selectedMember.role} />
                  <span className="text-xs text-slate-500">
                    Senast aktiv: {selectedMember.lastActive ? timeAgo(selectedMember.lastActive) : "–"}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setShowPanel(false)}
                className="text-slate-400 hover:text-slate-600 text-xl"
                title="Stäng"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-6 overflow-y-auto h-[calc(100%-80px)]">
              {/* KUND-TILLDELNING */}
              <section>
                <h4 className="text-sm font-semibold text-slate-700 mb-2">Kundtilldelning</h4>
                <p className="text-sm text-slate-500 mb-3">
                  Välj vilka kundbolag som {selectedMember.name.split(" ")[0]} ska ansvara för.
                </p>
                <div className="space-y-2 max-h-[40vh] overflow-y-auto pr-1">
                  {ALL_CUSTOMERS.map((c) => (
                    <label key={c} className="flex items-center gap-2 text-sm text-slate-700">
                      <input
                        type="checkbox"
                        checked={panelCustomers.includes(c)}
                        onChange={(e) =>
                          e.target.checked
                            ? setPanelCustomers((prev) => [...prev, c])
                            : setPanelCustomers((prev) => prev.filter((x) => x !== c))
                        }
                      />
                      {c}
                    </label>
                  ))}
                </div>
              </section>

              {/* SÄKERHET */}
              <section className="pt-4 border-t border-slate-100">
                <h4 className="text-sm font-semibold text-slate-700 mb-2">Säkerhet</h4>
                <div className="flex items-center justify-between">
                  <div className="text-sm text-slate-700 flex items-center gap-2">
                    <KeyIcon className="w-4 h-4" />
                    Tvåfaktorsautentisering (2FA)
                  </div>
                  <button
                    onClick={() => toggleMFA(selectedMember.id)}
                    className={`text-sm px-3 py-1 rounded-md border ${
                      selectedMember.mfaEnabled ? "border-emerald-200 text-emerald-700" : "border-slate-200 text-slate-600"
                    }`}
                  >
                    {selectedMember.mfaEnabled ? "Aktiv" : "Aktivera"}
                  </button>
                </div>
              </section>

              {/* AKTIONER */}
              <div className="flex justify-end gap-3 pt-2">
                <button
                  onClick={() => setShowPanel(false)}
                  className="px-4 py-2 rounded-lg text-slate-600 hover:bg-slate-100 transition"
                >
                  Stäng
                </button>
                <button
                  onClick={savePanel}
                  className="px-4 py-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition"
                >
                  Spara
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ====================== Helpers & UI bits ====================== */

function Th({ children, right = false }: { children: React.ReactNode; right?: boolean }) {
  return (
    <th
      className={`px-6 py-3 text-xs font-semibold text-slate-600 uppercase ${right ? "text-right" : "text-left"}`}
    >
      {children}
    </th>
  );
}

function StatCard({ label, value, accent = false }: { label: string; value: number | string; accent?: boolean }) {
  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
      className="bg-white rounded-xl shadow-sm p-4 border border-slate-200"
    >
      <p className="text-sm text-slate-500">{label}</p>
      <p className={`text-2xl font-semibold ${accent ? "text-emerald-700" : "text-slate-800"}`}>{value}</p>
    </motion.div>
  );
}

function RoleBadge({ role }: { role: Role }) {
  const map: Record<Role, string> = {
    Admin: "bg-emerald-100 text-emerald-700",
    Revisor: "bg-cyan-100 text-cyan-700",
    Analytiker: "bg-indigo-100 text-indigo-700",
    Assistent: "bg-slate-100 text-slate-600",
  };
  return (
    <span className={`inline-flex px-2 py-1 text-xs rounded-full font-medium ${map[role]}`}>{role}</span>
  );
}

function initials(name: string) {
  const parts = name.trim().split(" ");
  const head = parts[0]?.[0] || "";
  const tail = parts[1]?.[0] || "";
  return (head + tail).toUpperCase();
}

function timeAgo(iso: string) {
  const diffMs = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diffMs / (1000 * 60));
  if (m < 1) return "nu";
  if (m < 60) return `${m} min sedan`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} h sedan`;
  const d = Math.floor(h / 24);
  return `${d} d sedan`;
}

function escapeCSV(v: string) {
  if (v == null) return "";
  const needsQuotes = /[",\n]/.test(v);
  const s = String(v).replace(/"/g, '""');
  return needsQuotes ? `"${s}"` : s;
}
