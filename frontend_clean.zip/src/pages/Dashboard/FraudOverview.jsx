import React, { useEffect, useState, useMemo } from "react";
import axios from "axios";
import {
  ShieldExclamationIcon,
  ExclamationTriangleIcon,
  XCircleIcon,
  CheckCircleIcon,
  TrashIcon,
  MagnifyingGlassIcon,
  ArrowDownTrayIcon,
} from "@heroicons/react/24/outline";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";

export default function FraudOverview() {
  const API = import.meta.env.VITE_API_URL || "http://localhost:4000";
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [insights, setInsights] = useState(null);
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");

  // 🧠 Hämta fakturor med riskScore >= 60
  useEffect(() => {
    const fetchInvoices = async () => {
      try {
        setLoading(true);
        const res = await axios.get(`${API}/api/invoices`, { withCredentials: true });
        const all = res.data.invoices || [];
        const risky = all.filter((i) => i.riskScore >= 60);
        setInvoices(risky);
        calculateInsights(risky);
      } catch (err) {
        console.error("❌ Error loading fraud overview:", err);
        toast.error("Kunde inte hämta fakturor");
      } finally {
        setLoading(false);
      }
    };
    fetchInvoices();
  }, []);

  // 📊 Statistikpanel
  const calculateInsights = (data) => {
    if (!data?.length) {
      setInsights({ total: 0, avgRisk: 0, high: 0, medium: 0, trend: [], lastUpdated: null });
      return;
    }

    const high = data.filter((d) => d.riskScore >= 80).length;
    const medium = data.filter((d) => d.riskScore >= 60 && d.riskScore < 80).length;
    const avgRisk = Math.round(data.reduce((sum, d) => sum + (d.riskScore || 0), 0) / data.length);

    // Grupp för trendgraf
    const trendMap = {};
    data.forEach((d) => {
      const date = new Date(d.invoiceDate || d.createdAt || Date.now())
        .toISOString()
        .split("T")[0];
      trendMap[date] = trendMap[date] || [];
      trendMap[date].push(d.riskScore);
    });
    const trend = Object.entries(trendMap).map(([date, scores]) => ({
      date,
      avg: Math.round(scores.reduce((a, b) => a + b, 0) / scores.length),
    }));

    setInsights({
      total: data.length,
      avgRisk,
      high,
      medium,
      trend,
      lastUpdated: new Date().toLocaleString("sv-SE"),
    });
  };

  // 🔍 Filtrering & sökning
  const filteredInvoices = useMemo(() => {
    return invoices.filter((i) => {
      const matchFilter =
        filter === "all"
          ? true
          : filter === "high"
          ? i.riskScore >= 80
          : i.riskScore < 80 && i.riskScore >= 60;
      const matchSearch =
        !search ||
        i.customerName?.toLowerCase().includes(search.toLowerCase()) ||
        i.invoiceId?.toLowerCase().includes(search.toLowerCase());
      return matchFilter && matchSearch;
    });
  }, [invoices, filter, search]);

  // 🗑️ Radera faktura
  const handleDelete = async (id) => {
    if (!confirm("Vill du verkligen radera denna faktura?")) return;
    try {
      await axios.delete(`${API}/api/invoices/${id}`, { withCredentials: true });
      setInvoices((prev) => prev.filter((i) => i.id !== id));
      toast.success("🗑️ Fakturan raderades");
    } catch (err) {
      console.error("❌ Delete error:", err);
      toast.error("Kunde inte radera fakturan");
    }
  };

  // 📤 Exportera CSV
  const handleExportCSV = () => {
    if (!filteredInvoices.length) {
      toast.info("Inga fakturor att exportera.");
      return;
    }
    const headers = ["Invoice ID", "Customer", "Total", "Currency", "Risk Score", "AI Confidence"];
    const rows = filteredInvoices.map((i) => [
      i.invoiceId,
      i.customerName,
      i.total,
      i.currency,
      i.riskScore,
      i.aiConfidence,
    ]);
    const csvContent =
      "data:text/csv;charset=utf-8," +
      [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");
    const blob = new Blob([decodeURIComponent(encodeURI(csvContent))], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "fraud_invoices.csv";
    a.click();
    URL.revokeObjectURL(url);
    toast.success("📄 CSV-export klar!");
  };

  const getColor = (risk) => {
    if (risk >= 80) return "bg-rose-100 text-rose-700 border-rose-300";
    if (risk >= 60) return "bg-amber-100 text-amber-700 border-amber-300";
    return "bg-emerald-100 text-emerald-700 border-emerald-300";
  };

  const getIcon = (risk) => {
    if (risk >= 80) return <XCircleIcon className="w-5 h-5 text-rose-600" />;
    if (risk >= 60)
      return <ExclamationTriangleIcon className="w-5 h-5 text-amber-600" />;
    return <CheckCircleIcon className="w-5 h-5 text-emerald-600" />;
  };

  if (loading)
    return (
      <div className="flex justify-center items-center h-64 text-slate-500 animate-pulse">
        ⏳ Hämtar riskfakturor...
      </div>
    );

  return (
    <div className="space-y-6 p-6">
      {/* 🔹 Statistikpaneler */}
      {insights && (
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <StatCard title="Totala riskfakturor" value={insights.total} />
          <StatCard title="Genomsnittlig risknivå" value={`${insights.avgRisk}%`} />
          <StatCard title="Högriskfakturor" value={insights.high} color="text-rose-600" />
          <StatCard title="Senast uppdaterad" value={insights.lastUpdated} small />
        </motion.div>
      )}

      {/* 🔹 Graf */}
      {insights?.trend?.length > 1 && (
        <div className="bg-white border rounded-xl p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-700 mb-3">
            📈 Risktrend över tid
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={insights.trend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} />
              <YAxis stroke="#94a3b8" fontSize={12} />
              <Tooltip />
              <Line
                type="monotone"
                dataKey="avg"
                stroke="#0284c7"
                strokeWidth={2}
                dot={{ r: 3, fill: "#0ea5e9" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* 🔹 Rubrik & verktyg */}
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <ShieldExclamationIcon className="h-6 w-6 text-amber-600" />
            Riskbedömda fakturor
          </h1>
          <p className="text-slate-500 text-sm">
            {filteredInvoices.length} fakturor med riskScore ≥ 60%
          </p>
        </div>

        <div className="flex flex-wrap gap-2 items-center">
          {["all", "medium", "high"].map((lvl) => (
            <button
              key={lvl}
              onClick={() => setFilter(lvl)}
              className={`px-3 py-1.5 rounded-lg border text-sm capitalize transition ${
                filter === lvl
                  ? "bg-sky-600 text-white border-sky-600"
                  : "bg-white border-slate-300 text-slate-600 hover:bg-slate-50"
              }`}
            >
              {lvl === "all"
                ? "Alla"
                : lvl === "high"
                ? "Hög risk"
                : "Mellanrisk"}
            </button>
          ))}
          <div className="relative">
            <MagnifyingGlassIcon className="w-4 h-4 absolute left-2.5 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Sök kund eller faktura-ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8 pr-3 py-1.5 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-sky-500 outline-none"
            />
          </div>
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium transition"
          >
            <ArrowDownTrayIcon className="w-4 h-4" /> Exportera CSV
          </button>
        </div>
      </header>

      {/* 🔹 Tabell */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden mt-2">
        {filteredInvoices.length === 0 ? (
          <p className="text-center py-10 text-slate-500">
            Inga fakturor matchar dina filter.
          </p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-100 text-slate-600">
              <tr>
                <th className="px-4 py-3">Risk</th>
                <th className="px-4 py-3">Faktura-ID</th>
                <th className="px-4 py-3">Kund</th>
                <th className="px-4 py-3">Belopp</th>
                <th className="px-4 py-3">AI-bedömning</th>
                <th className="px-4 py-3 text-right">Åtgärder</th>
              </tr>
            </thead>
            <tbody>
              {filteredInvoices.map((inv) => (
                <motion.tr
                  key={inv.id}
                  className="border-t hover:bg-slate-50 transition cursor-pointer"
                  onClick={() => setSelectedInvoice(inv)}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <td className="px-4 py-3">
                    <div
                      className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg border text-xs font-medium ${getColor(
                        inv.riskScore
                      )}`}
                    >
                      {getIcon(inv.riskScore)}
                      {inv.riskScore}%
                    </div>
                  </td>
                  <td className="px-4 py-3">{inv.invoiceId || "—"}</td>
                  <td className="px-4 py-3">{inv.customerName || "—"}</td>
                  <td className="px-4 py-3">
                    {inv.total
                      ? new Intl.NumberFormat("sv-SE", {
                          style: "currency",
                          currency: inv.currency || "SEK",
                        }).format(inv.total)
                      : "—"}
                  </td>
                  <td className="px-4 py-3 text-slate-600 truncate">
                    {inv.aiSummary || "Ingen AI-förklaring"}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(inv.id);
                      }}
                      className="p-2 hover:bg-red-100 rounded-md text-red-600"
                    >
                      <TrashIcon className="w-5 h-5" />
                    </button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {selectedInvoice && (
        <InvoiceModal
          invoice={selectedInvoice}
          onClose={() => setSelectedInvoice(null)}
        />
      )}
    </div>
  );
}

/* ─────────────────────────────
   📊 Statistikpanel-komponent
───────────────────────────── */
function StatCard({ title, value, color = "text-slate-800", small = false }) {
  return (
    <div className="bg-white border rounded-xl p-4 shadow-sm">
      <h4 className="text-sm text-slate-500">{title}</h4>
      <p className={`font-bold ${color} ${small ? "text-xs" : "text-2xl"}`}>
        {value || "—"}
      </p>
    </div>
  );
}

/* ─────────────────────────────
   🪟 Modal för fakturadetaljer
───────────────────────────── */
function InvoiceModal({ invoice, onClose }) {
  return (
    <motion.div
      className="fixed inset-0 bg-black/40 flex items-center justify-center z-[9999]"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <motion.div
        className="bg-white w-full max-w-3xl rounded-2xl shadow-xl overflow-hidden"
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.2 }}
      >
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold text-slate-800">
            Faktura #{invoice.invoiceId}
          </h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-2xl leading-none"
          >
            ×
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <p>
              <span className="text-slate-500">Kund:</span>{" "}
              <span className="font-medium">{invoice.customerName || "—"}</span>
            </p>
            <p>
              <span className="text-slate-500">Belopp:</span>{" "}
              {invoice.total
                ? `${invoice.total} ${invoice.currency || "SEK"}`
                : "—"}
            </p>
            <p>
              <span className="text-slate-500">Risknivå:</span>{" "}
              {invoice.riskScore || "—"}%
            </p>
            <p>
              <span className="text-slate-500">AI-förtroende:</span>{" "}
              {invoice.aiConfidence || "—"}%
            </p>
          </div>

          <div className="border-t pt-3">
            <h4 className="font-semibold text-slate-700 mb-1">AI-analys</h4>
            <p className="text-slate-600 text-sm leading-relaxed">
              {invoice.aiSummary || "Ingen analys tillgänglig."}
            </p>
          </div>

          {invoice.pdfUrl && (
            <div className="border-t pt-3">
              <h4 className="font-semibold text-slate-700 mb-2">Faktura (PDF)</h4>
              <iframe
                src={invoice.pdfUrl}
                className="w-full h-96 border rounded-lg"
                title="Invoice PDF"
              />
            </div>
          )}
        </div>

        <div className="p-4 border-t bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm rounded-lg border hover:bg-slate-100 text-slate-700"
          >
            Stäng
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
