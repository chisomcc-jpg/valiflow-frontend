import React, { useMemo, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  ArrowLeftIcon,
  ArrowTrendingUpIcon,
  XMarkIcon,
} from "@heroicons/react/24/outline";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";

export default function FirmClientDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [showReviewModal, setShowReviewModal] = useState(false);

  // 🧩 Dummy data
  const client = useMemo(() => {
    const all = [
      {
        id: 1,
        name: "Nordic Trade AB",
        org: "556882-1122",
        bureau: "EkonomiPartner AB",
        invoices: 312,
        risk: 2.3,
        status: "Aktiv",
        lastActive: "2025-10-22",
      },
      {
        id: 2,
        name: "FinTechify AB",
        org: "559101-5555",
        bureau: "Balance Consulting",
        invoices: 155,
        risk: 7.8,
        status: "Under granskning",
        lastActive: "2025-10-21",
      },
    ];
    return all.find((c) => c.id === Number(id)) || all[0];
  }, [id]);

  const riskTrend = [
    { month: "Maj", risk: 3.2 },
    { month: "Jun", risk: 3.8 },
    { month: "Jul", risk: 4.5 },
    { month: "Aug", risk: 5.6 },
    { month: "Sep", risk: 7.2 },
    { month: "Okt", risk: 7.8 },
  ];

  const invoices = [
    { id: "#INV-1451", amount: "12 300 kr", date: "2025-10-22", status: "Godkänd" },
    { id: "#INV-1448", amount: "8 400 kr", date: "2025-10-21", status: "Flaggad" },
    { id: "#INV-1445", amount: "5 780 kr", date: "2025-10-18", status: "Under granskning" },
  ];

  const aiInsights = [
    "⚠️ AI upptäckte 3 fakturor med samma IBAN men olika mottagare.",
    "📈 Risknivån har ökat med +4.1 senaste 60 dagarna.",
    "🤖 Fakturavolymerna ökade 38% efter semestern — avvikelse från norm.",
  ];

  const statusColor =
    client.status === "Aktiv"
      ? "bg-emerald-50 text-emerald-700"
      : client.status === "Under granskning"
      ? "bg-yellow-50 text-yellow-700"
      : "bg-gray-100 text-gray-500";

  return (
    <div className="space-y-8">
      {/* Back button */}
      <button
        onClick={() => navigate(-1)}
        className="flex items-center text-slate-600 hover:text-slate-800 text-sm mb-2"
      >
        <ArrowLeftIcon className="w-4 h-4 mr-1" /> Tillbaka till kunder
      </button>

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-800">{client.name}</h1>
          <p className="text-slate-500 text-sm mt-1">
            Org.nr <b>{client.org}</b> • Tillhör byrå <b>{client.bureau}</b>
          </p>
          <div className="flex items-center gap-2 mt-2">
            <span className={`px-2 py-1 rounded-lg text-xs font-medium ${statusColor}`}>
              {client.status}
            </span>
            <span
              className={`px-2 py-1 rounded-lg text-xs font-medium ${
                client.risk >= 7
                  ? "bg-red-50 text-red-700"
                  : client.risk >= 4
                  ? "bg-orange-50 text-orange-700"
                  : "bg-emerald-50 text-emerald-700"
              }`}
            >
              Risk {client.risk.toFixed(1)}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap gap-3">
          <button className="px-4 py-2 bg-gray-100 text-slate-700 text-sm rounded-lg hover:bg-gray-200 transition">
            Exportera data
          </button>
          <button
            onClick={() => setShowReviewModal(true)}
            className="px-4 py-2 bg-yellow-500 text-white text-sm rounded-lg hover:bg-yellow-600 transition"
          >
            Sätt i granskning
          </button>
          <button className="px-4 py-2 bg-emerald-600 text-white text-sm rounded-lg hover:bg-emerald-700 transition">
            Återaktivera
          </button>
        </div>
      </div>

      {/* Charts + info */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Risktrend */}
        <div className="border rounded-xl p-4 bg-white shadow-sm">
          <p className="font-medium text-slate-700 mb-2">Risktrend (6 månader)</p>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={riskTrend}>
              <defs>
                <linearGradient id="riskFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" stroke="#94a3b8" />
              <YAxis domain={[0, 10]} stroke="#94a3b8" />
              <Tooltip />
              <Area
                type="monotone"
                dataKey="risk"
                stroke="#10b981"
                fill="url(#riskFill)"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Fakturor */}
        <div className="border rounded-xl p-4 bg-white shadow-sm">
          <p className="font-medium text-slate-700 mb-2">Senaste fakturor</p>
          <div className="space-y-2">
            {invoices.map((inv) => (
              <div
                key={inv.id}
                className="flex items-center justify-between text-sm border rounded-lg px-3 py-2 hover:bg-gray-50 transition"
              >
                <div className="flex flex-col">
                  <span className="font-medium text-slate-800">{inv.id}</span>
                  <span className="text-slate-500">{inv.date}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-slate-700">{inv.amount}</span>
                  <span
                    className={`px-2 py-1 rounded-lg text-xs font-medium ${
                      inv.status === "Godkänd"
                        ? "bg-emerald-50 text-emerald-700"
                        : inv.status === "Under granskning"
                        ? "bg-yellow-50 text-yellow-700"
                        : "bg-red-50 text-red-700"
                    }`}
                  >
                    {inv.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* AI Insights */}
      <div className="bg-gradient-to-br from-gray-50 to-white border rounded-2xl shadow-sm p-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-slate-800 flex items-center gap-2">
            <ArrowTrendingUpIcon className="w-5 h-5 text-emerald-600" />
            AI-observationer & riskinsikter
          </h2>
          <span className="text-xs text-slate-500">
            Uppdaterad {new Date().toLocaleTimeString("sv-SE", { hour: "2-digit", minute: "2-digit" })}
          </span>
        </div>

        <ul className="text-sm text-slate-600 space-y-2">
          {aiInsights.map((ins, i) => (
            <li key={i}>{ins}</li>
          ))}
        </ul>
      </div>

      {/* Modal */}
      {showReviewModal && (
        <ReviewModal
          onClose={() => setShowReviewModal(false)}
          client={client}
        />
      )}
    </div>
  );
}

/* 🧩 Modal Component */
function ReviewModal({ onClose, client }) {
  const [reason, setReason] = useState("");
  const [note, setNote] = useState("");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/30"
        onClick={onClose}
      />
      {/* Modal box */}
      <div className="relative bg-white w-full max-w-md rounded-2xl shadow-xl border p-6 mx-4 animate-fadeIn">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-lg font-semibold text-slate-800">
              Sätt {client.name} i granskning
            </h3>
            <p className="text-sm text-slate-500 mt-1">
              Välj orsak och lägg till valfri kommentar.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-gray-100 text-slate-500"
          >
            <XMarkIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="mt-4 space-y-3">
          <select
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500"
          >
            <option value="">Välj orsak...</option>
            <option>AI-fel / felaktig flagga</option>
            <option>Misstänkt IBAN</option>
            <option>VAT mismatch</option>
            <option>Manuellt stickprov</option>
            <option>Annan orsak</option>
          </select>

          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Lägg till kommentar (valfritt)..."
            className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-emerald-500 focus:border-emerald-500 min-h-[80px]"
          />
        </div>

        {/* Footer */}
        <div className="mt-5 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 text-slate-700 text-sm rounded-lg hover:bg-gray-200 transition"
          >
            Avbryt
          </button>
          <button
            onClick={() => {
              console.log("Företag satt i granskning:", { client, reason, note });
              onClose();
            }}
            disabled={!reason}
            className={`px-4 py-2 text-sm rounded-lg transition ${
              reason
                ? "bg-yellow-500 text-white hover:bg-yellow-600"
                : "bg-gray-200 text-gray-400 cursor-not-allowed"
            }`}
          >
            Bekräfta
          </button>
        </div>
      </div>
    </div>
  );
}
