import React from "react";
import { BellAlertIcon, CheckCircleIcon, XCircleIcon } from "@heroicons/react/24/outline";

export default function BureauNotifications() {
  const notifications = [
    { type: "info", message: "Ny kund har anslutit: ACME AB", time: "2 minuter sedan" },
    { type: "warning", message: "En faktura har flaggats som misstänkt.", time: "1 timme sedan" },
    { type: "success", message: "AI-skanning slutförd för September.", time: "3 timmar sedan" },
  ];

  const iconMap = {
    info: BellAlertIcon,
    warning: XCircleIcon,
    success: CheckCircleIcon,
  };

  const colorMap = {
    info: "text-blue-600",
    warning: "text-amber-600",
    success: "text-emerald-600",
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl font-semibold text-slate-800 mb-2">Notifikationer</h1>
      <p className="text-slate-500 mb-8">
        Visa senaste händelser och systemmeddelanden.
      </p>

      <div className="bg-white border rounded-xl shadow-sm divide-y divide-slate-200">
        {notifications.map((n, i) => {
          const Icon = iconMap[n.type];
          return (
            <div key={i} className="flex items-center gap-3 p-4 hover:bg-slate-50 transition">
              <Icon className={`w-6 h-6 ${colorMap[n.type]}`} />
              <div>
                <p className="text-slate-800 text-sm font-medium">{n.message}</p>
                <p className="text-xs text-slate-400">{n.time}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
