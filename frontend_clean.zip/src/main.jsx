// src/main.jsx
import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom"; // 👈 IMPORTERA DETTA
import App from "./App.jsx";
import "./index.css";
import { Toaster } from "sonner";
import { AuthProvider } from "./context/AuthContext.jsx"; // ✅ added

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter> {/* 👈 WRAPPA HÄR */}
      <AuthProvider>
        <App />
        <Toaster position="top-right" richColors /> {/* ✅ toast notifications */}
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>
);
