// frontend/src/pages/FraudLogs.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  ShieldAlert,
  CheckCircle,
  Clock,
  RefreshCw,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

export default function FraudLogs() {
  const [logs, setLogs] = useState([]);
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);

  const API = import.meta.env.VITE_API_URL || "http://localhost:4000";

  // 🔄 Fetch logs
  async function fetchLogs(status) {
    try {
      setLoading(true);
      const res = await axios.get(
        status && status !== "all"
          ? `${API}/fraud-logs?status=${status}`
          : `${API}/fraud-logs`
      );
      setLogs(res.data);
    } catch (err) {
      console.error("Error fetching fraud logs:", err);
      toast.error("Kunde inte hämta loggar");
    } finally {
      setLoading(false);
    }
  }

  // 🟢 Mark log as resolved
  async function markStatus(id, status) {
    try {
      await axios.patch(`${API}/fraud-logs/${id}`, { status });
      setLogs((prev) =>
        prev.map((log) => (log.id === id ? { ...log, status } : log))
      );
    } catch (err) {
      console.error("Error updating fraud log:", err);
      toast.error("Kunde inte uppdatera status");
    }
  }

  // 💬 Feedback
  async function sendFeedback(log, correct) {
    try {
      await axios.post(`${API}/api/feedback`, {
        invoiceId: log.invoiceId,
        feedback: correct ? "correct" : "incorrect",
        aiDecision: log.severity,
      });
      toast.success("Tack för din feedback!");
      setExpanded(null);
    } catch {
      toast.error("Kunde inte skicka feedback");
    }
  }

  useEffect(() => {
    fetchLogs(filter);
  }, [filter]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64 text-slate-500 animate-pulse">
        ⏳ Laddar fraud-loggar…
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <ShieldAlert className="h-6 w-6 text-red-500" />
          Fraud Logs
        </h1>

        <div className="flex items-center gap-2">
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="border rounded-lg px-3 py-2 text-sm"
          >
            <option value="all">All</option>
            <option value="unreviewed">Unreviewed</option>
            <option value="resolved">Resolved</option>
          </select>

          <button
            onClick={() => fetchLogs(filter)}
            className="flex items-center gap-1 border border-slate-200 px-3 py-2 rounded-lg hover:bg-slate-50 transition text-sm"
          >
            <RefreshCw className="h-4 w-4" /> Refresh
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead className="bg-gray-100 text-gray-600 text-sm uppercase">
            <tr>
              <th className="py-3 px-4">ID</th>
              <th className="py-3 px-4">Supplier</th>
              <th className="py-3 px-4">Message</th>
              <th className="py-3 px-4">Type</th>
              <th className="py-3 px-4">Severity</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4">Date</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>

          <tbody>
            {logs.length === 0 ? (
              <tr>
                <td colSpan="8" className="text-center py-6 text-gray-500">
                  No fraud logs found.
                </td>
              </tr>
            ) : (
              logs.map((log) => (
                <React.Fragment key={log.id}>
                  <tr
                    onClick={() =>
                      setExpanded(expanded === log.id ? null : log.id)
                    }
                    className="border-t hover:bg-gray-50 transition cursor-pointer"
                  >
                    <td className="py-3 px-4 text-sm text-slate-600">
                      #{log.id}
                    </td>
                    <td className="py-3 px-4">{log.supplier || "—"}</td>
                    <td className="py-3 px-4">{log.message}</td>
                    <td className="py-3 px-4 text-sm text-slate-500">
                      {log.type}
                    </td>
                    <td
                      className={`py-3 px-4 font-medium ${
                        log.severity === "high"
                          ? "text-red-600"
                          : log.severity === "medium"
                          ? "text-orange-500"
                          : "text-green-600"
                      }`}
                    >
                      {log.severity}
                    </td>
                    <td>
                      <span
                        className={`px-3 py-1 text-xs font-semibold rounded-full ${
                          log.status === "resolved"
                            ? "bg-green-100 text-green-700"
                            : "bg-yellow-100 text-yellow-700"
                        }`}
                      >
                        {log.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-slate-500">
                      {new Date(log.createdAt).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right">
                      {expanded === log.id ? (
                        <ChevronUp className="h-4 w-4 text-slate-500" />
                      ) : (
                        <ChevronDown className="h-4 w-4 text-slate-500" />
                      )}
                    </td>
                  </tr>

                  {/* Expandable AI Details */}
                  <AnimatePresence>
                    {expanded === log.id && (
                      <motion.tr
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="bg-slate-50 border-t"
                      >
                        <td colSpan="8" className="p-4">
                          <div className="flex flex-col gap-3">
                            <div>
                              <p className="font-medium text-slate-700">
                                🤖 AI-förklaring
                              </p>
                              <p className="text-slate-600 text-sm mt-1">
                                {log.ai_reasoning ||
                                  "Ingen AI-förklaring tillgänglig."}
                              </p>
                            </div>

                            <div className="flex items-center gap-3">
                              <div className="flex-1 h-2 bg-slate-200 rounded-full overflow-hidden">
                                <div
                                  className={`h-full ${
                                    (log.ai_confidence || 0.8) > 0.8
                                      ? "bg-green-500"
                                      : (log.ai_confidence || 0.8) > 0.5
                                      ? "bg-yellow-500"
                                      : "bg-red-500"
                                  }`}
                                  style={{
                                    width: `${
                                      ((log.ai_confidence || 0.8) * 100).toFixed(0)
                                    }%`,
                                  }}
                                />
                              </div>
                              <span className="text-xs text-slate-500">
                                Confidence:{" "}
                                {((log.ai_confidence || 0.8) * 100).toFixed(0)}%
                              </span>
                            </div>

                            <div className="flex gap-3">
                              <button
                                onClick={() => sendFeedback(log, true)}
                                className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 text-sm flex items-center gap-1"
                              >
                                <CheckCircle className="h-4 w-4" /> AI hade rätt
                              </button>
                              <button
                                onClick={() => sendFeedback(log, false)}
                                className="px-3 py-1.5 rounded-lg bg-red-600 text-white hover:bg-red-700 text-sm flex items-center gap-1"
                              >
                                ✖ AI hade fel
                              </button>
                            </div>
                          </div>
                        </td>
                      </motion.tr>
                    )}
                  </AnimatePresence>
                </React.Fragment>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
