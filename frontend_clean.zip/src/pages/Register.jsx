import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

export default function Register() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    email: "",
    password: "",
    role: "",
    companyName: "",
    orgNumber: "",
    vatNumber: "",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const nextStep = () => setStep((s) => s + 1);
  const prevStep = () => setStep((s) => s - 1);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`${import.meta.env.VITE_API_URL}/api/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Registration failed");

      toast.success("Account created! Please verify your identity.");
      navigate("/verify-bankid");
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 to-white">
      <div className="bg-white/90 backdrop-blur-md shadow-xl rounded-2xl p-8 w-full max-w-md">
        <h2 className="text-3xl font-bold text-center text-gray-800 mb-6">
          {step === 1 ? "Create your Valiflow account" : "Company details"}
        </h2>

        <form onSubmit={step === 2 ? handleSubmit : (e) => e.preventDefault()} className="space-y-4">
          {step === 1 && (
            <>
              <input
                type="email"
                name="email"
                placeholder="Work email"
                value={form.email}
                onChange={handleChange}
                className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
              <input
                type="password"
                name="password"
                placeholder="Password"
                value={form.password}
                onChange={handleChange}
                className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
              <select
                name="role"
                value={form.role}
                onChange={handleChange}
                className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              >
                <option value="">Select your role</option>
                <option value="FINANCE_MANAGER">Finance Manager</option>
                <option value="ACCOUNTANT">Accountant</option>
                <option value="CEO">CEO / Founder</option>
                <option value="BOOKKEEPER">Bookkeeper</option>
              </select>

              <button
                type="button"
                onClick={nextStep}
                className="w-full bg-indigo-600 text-white py-3 rounded-lg font-medium hover:bg-indigo-700 transition"
              >
                Next →
              </button>
            </>
          )}

          {step === 2 && (
            <>
              <input
                type="text"
                name="companyName"
                placeholder="Company name"
                value={form.companyName}
                onChange={handleChange}
                className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
              <input
                type="text"
                name="orgNumber"
                placeholder="Organisation number (e.g. 556677-8899)"
                value={form.orgNumber}
                onChange={handleChange}
                className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <input
                type="text"
                name="vatNumber"
                placeholder="VAT number (e.g. SE556677889901)"
                value={form.vatNumber}
                onChange={handleChange}
                className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={prevStep}
                  className="w-1/2 border border-gray-300 py-3 rounded-lg hover:bg-gray-50"
                >
                  ← Back
                </button>
                <button
                  type="submit"
                  className="w-1/2 bg-indigo-600 text-white py-3 rounded-lg font-medium hover:bg-indigo-700 transition"
                >
                  Register
                </button>
              </div>
            </>
          )}
        </form>
      </div>
    </div>
  );
}
